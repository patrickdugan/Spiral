# AHR-01 · IBM Quantum pilot

**DONE** on ibm_marrakesh. IBM job ID **dc1ro6ds2omc738b1s8g**. Submitted on 2026-11-23 12:07:52 SGT and collected on 2026-11-23 12:08:39 SGT.

The prespecified square contrast at $t=1.6$ was **+0.48828** with a 95% Newcombe interval of **[+0.46483, +0.51103]**. The primary interval lies above zero. The broken-square interval includes zero.

| $t=1.6$ contrast | Exact | Compiled ideal | Calibrated Aer | IBM QPU | QPU 95% interval |
| --- | ---: | ---: | ---: | ---: | --- |
| Closed square, π vs. 0 | +0.50933 | +0.50131 | +0.49701 | +0.48828 | [+0.46483, +0.51103] |
| Broken square, π vs. 0 | 0.00000 | 0.00000 | +0.00122 | +0.01758 | [-0.00569, +0.04084] |

| Closed-square flux at $t=1.6$ | Exact $P_{00}$ | Compiled ideal | Calibrated Aer | QPU $P_{00}$ | QPU 95% Wilson interval |
| --- | ---: | ---: | ---: | ---: | --- |
| 0 | 0.03383 | 0.03228 | 0.03302 | 0.03613 | [0.02888, 0.04512] |
| π/2 | 0.20854 | 0.20318 | 0.20633 | 0.19629 | [0.17966, 0.21405] |
| π | 0.54316 | 0.53359 | 0.53003 | 0.52441 | [0.50276, 0.54598] |

The pilot returned **34,816 shots** across 15 square circuits and two tree controls. The physical layout was $x\mapsto 5$ and $y\mapsto 6$. The selected synthesis was second-order Suzuki–Trotter with eight repetitions. Its maximum absolute ideal $P_{00}$ error across the 17 cases was 0.00957. The calibration snapshot was 2026-11-23 11:49:18 SGT.

The verified Open Plan balance before submission was 600 s. The job used a 78 s QPU cap. IBM reported **11.000 s** of QPU use. The first post-run balance showed **589.000 s** remaining.

The counts test site-basis return probabilities. Entanglement results in this directory come from simulation. Sampling intervals account for shot noise, and the calibration-derived Aer model provides a comparison for device effects. Both tree flux arms used the same missing edge.

## Run files

- [Raw IBM counts and usage](pilot_counts.json) · [Submission record](pilot_job.json)
- [Return probabilities and intervals](return_probabilities.csv) · [Return-probability plot](return_probabilities.png) · [Flux contrasts](contrasts.json)
- [Live compilation and calibration manifest](manifest.json) · [Compiled circuit comparison](compilation.json) · [Pilot QPY](pilot.qpy)
- [Post-run Open Plan allocation](post_run_allocation.json)
