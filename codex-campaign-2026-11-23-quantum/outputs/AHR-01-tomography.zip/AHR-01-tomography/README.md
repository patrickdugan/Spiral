# AHR-01 · IBM entanglement tomography

**DONE** on ibm_marrakesh. IBM job ID **dc1rq9ls2omc738b1vbg**. Results collected on 2026-11-23 12:12:40 SGT. The preceding return-probability pilot was dc1ro6ds2omc738b1s8g.

At $t=0.8$, all nine local Pauli settings were measured at both fluxes. The fixed witness certified entanglement at the 95% level for flux π.

| Flux | Ideal concurrence | Calibrated Aer concurrence | QPU concurrence | QPU 95% bootstrap interval | QPU witness | Witness 95% upper bound |
| --- | ---: | ---: | ---: | --- | ---: | ---: |
| 0 | 0.00000 | 0.00778 | 0.02640 | [0.00906, 0.07013] | +0.01505 | +0.03682 |
| π | 0.77218 | 0.75836 | 0.74221 | [0.71585, 0.76239] | -0.17575 | -0.15062 |

IBM returned 36,864 shots across 18 circuits, with 2,048 shots per setting. The physical layout was $x\mapsto 5$ and $y\mapsto 6$ with calibration from 2026-11-23 11:49:18 SGT.

The verified free balance before submission was 589 s. The execution cap was 79 s. IBM reported **12 s** of QPU use. The post-run Open Plan balance was 577 s.

Measurement settings are written in logical $x,y$ order. Outcome strings and the reconstructed density matrices are in Qiskit $y,x$ order. Each density matrix comes from linear Pauli inversion and Frobenius projection onto positive, trace-one matrices. Wootters concurrence is reported with a 600-resample descriptive multinomial bootstrap interval. Near the separable boundary, finite shots and positivity projection can bias the concurrence estimate. [Wootters (1998)](https://doi.org/10.1103/PhysRevLett.80.2245)

The fixed ideal-state projector witness uses the largest squared Schmidt coefficient as the separable overlap bound. It is evaluated directly from the measured Pauli statistics. An upper one-sided 95% Hoeffding bound below zero certifies entanglement under independent sampling and the stated local Pauli measurement model.

- [Density matrices and entanglement analysis](entanglement.json) · [Raw IBM counts](tomography_counts.json)
- [Calibration manifest](manifest.json) · [Tomography QPY](tomography.qpy) · [Exact and Aer setting predictions](tomography_predictions.json)
- [Submission and resource record](tomography_job.json)
- [Post-run Open Plan allocation](post_tomography_allocation.json)
- [Final provider job-usage check](tomography_usage_check.json)
