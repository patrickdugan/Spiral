# AHR-02 · A three-prime cube

## Hamiltonian and flux choices

Encode $n=2^x3^y5^z$ with $x,y,z\in\{0,1\}$ on $q_0,q_1,q_2$. In little-endian basis order $|zyx\rangle$, the sites are $1,2,3,6,5,10,15,30$. The diagonal is $x\ln2+y\ln3+z\ln5$. For each cube edge that increases one exponent, set $H_{s+\hat i,s}=J_i e^{iA_i(s)}$ and its reverse to the complex conjugate. Start with $J_i=1$ and $|000\rangle$.

Write $F_{ij}(s)=A_i(s)+A_j(s+\hat i)-A_i(s+\hat j)-A_j(s)$ for the oriented flux of the $ij$-face based at $s$. One link assignment that changes several face fluxes is

$$
A_x=0,\qquad A_y(x)=\alpha x,\qquad A_z(x,y)=\beta x+\gamma y+\kappa xy.
$$

This gives $F_{xy}(z)=\alpha$, $F_{xz}(y)=\beta+\kappa y$ and $F_{yz}(x)=\gamma+\kappa x$. The oriented sum over the six cube faces is zero modulo $2\pi$, since each link occurs with opposite signs in its two adjacent faces. There are five independent cycles on the full graph, since it has 12 edges and 8 vertices. The four-parameter family above gives a practical first sweep. To use all five degrees of freedom, gauge-fix the seven links of a spanning tree to zero and assign independent phases to the five chords.

## First experiment

| Setting | $(\alpha,\beta,\gamma,\kappa)$ | Intended comparison |
| --- | --- | --- |
| Zero | $(0,0,0,0)$ | Three-factor zero-flux baseline |
| XY | $(\pi,0,0,0)$ | Closed XY plaquettes with $z$-motion present |
| XY and XZ | $(\pi,\pi/2,0,0)$ | Add a second plaquette orientation |
| Flux gradient | $(\pi,\pi/2,0,\pi/2)$ | Shift opposite XZ and YZ faces while enforcing the cube constraint |
| Gauge copy | Vertex rephasing of the flux-gradient links | Same fluxes and site probabilities with different edge phases |
| Tree pair | Zero and flux gradient on one common spanning tree | Remove every cycle while retaining phased tree links |

Use the AHR-01 time grid for design comparisons. On the ideal cube, compute every eigenspectrum, all eight site probabilities and the three single-qubit reduced states. Check Hermiticity, explicit Pauli ordering, loop phase products, the two opposite-face flux differences, the zero-flux tensor product, site-gauge probability invariance and disappearance of flux dependence in every spanning-tree transition. Benchmark a second-order product formula against exact noiseless evolution. Compile on a connected three-qubit physical patch, using the target's native gate costs, and report routing cost. Validate a controlled link decomposition against a dense three-qubit unitary on small instances before using either circuit family on hardware.

Select and freeze a held-out experimental time and the $P_{000}$ contrast between the flux-gradient setting and zero. Use the gauge-copy and tree groups to check circuit-dependent artifacts. Record the probabilities of all sites rather than a single count. For optional tomography, report reduced-pair concurrence or preregister a genuine tripartite witness with a verified biseparable bound. Single-qubit marginal mixing alone cannot distinguish tripartite entanglement from pairwise entanglement and mixtures on noisy hardware.

## Three separate controlled studies

1. **Arithmetic specificity.** Keep the graph, hopping, flux and initial state fixed. Compare the logarithmic detunings with generic additive detunings matched for mean site energy, spread and coupling scale. Include axis-permuted and site-scrambled energies as named controls, since they test different structure. Prespecify a statistic such as the area under the absolute flux-contrast curve, a held-out distributional distance or a fixed-time witness. Use a classical ensemble of controls and reserve a subset of parameter points for hardware comparison.
2. **Spectral resonance.** Scan a tunable detuning and a hopping independently at fixed flux settings. Use the spectral weights $w_k=|\langle E_k|000\rangle|^2$, since $P_{000}(t)=|\sum_k w_k e^{-iE_k t}|^2$ has frequencies from eigenvalue gaps and weights from their products. Prespecify a gap or avoided-crossing observable, time-window resolution and a held-out prediction of peak position. For a driven resonance test, add a weak periodic on-site perturbation and sweep drive frequency across predicted transition lines, with amplitude-matched off-resonance and zero-flux controls.
3. **Computational scaling.** Compare a family with $m$ primes and explicit exponent bounds at fixed observable precision. Track $d=\prod_i(L_i+1)$ for maximum exponents $L_i$, classical sparse propagation time and memory, compiled quantum two-qubit gate counts, and shots and mitigation cost. Benchmark classical product evolution and sparse or tensor-network methods where appropriate. Specify how link phases are computed and how their complexity scales. An encoding that stores site labels in $O(\log d)$ qubits by itself gives no runtime guarantee.
