# Mathematical validation

In Qiskit display order $(|00\rangle,|01\rangle,|10\rangle,|11\rangle)=(1,2,3,6)$, $x=q_0$ and $y=q_1$. The Hamiltonian is

~~~text
                 1          2               3         6
      1          0          J               J         0
      2          J          a               0         J exp(-iφ)
      3          J          0               b         J
      6          0          J exp(+iφ)      J         a+b
~~~

The ordered hopping product for $1\rightarrow2\rightarrow6\rightarrow3\rightarrow1$ is $J^4 e^{i\phi}$. The Qiskit Pauli expansion uses labels with $y$ on the left.

| Pauli | Coefficient |
| --- | --- |
| II | $(a+b)/2$ |
| IZ | $-a/2$ |
| ZI | $-b/2$ |
| IX | $J$ |
| XI | $J(1+\cos\phi)/2$ |
| XZ | $J(1-\cos\phi)/2$ |
| YI | $(J/2)\sin\phi$ |
| YZ | $-(J/2)\sin\phi$ |

For the pilot tree, subtract the hop $J|y=0\rangle\langle y=0|\otimes X_x$. This reduces the IX coefficient to $J/2$ and adds $-J/2$ on ZX, keeping the phased edge intact. The Qiskit and explicit matrices agree for the square and the chosen tree, including a non-real phase. [Qiskit bit order](https://quantum.cloud.ibm.com/docs/en/qiskit/bit-ordering)

1. **Zero flux.** With $\phi=0$, the matrix is $I_y\otimes h_x+h_y\otimes I_x$, where $h_x=\begin{pmatrix}0&J\\J&a\end{pmatrix}$ and $h_y$ has $b$ in place of $a$. The terms commute, so $U=e^{-ith_y}\otimes e^{-ith_x}$. The initial product state stays separable for all times.
2. **Short-time concurrence.** Each one-hop amplitude is $-iJt+O(t^2)$. The two paths reaching site 6 give $\psi_{11}=-J^2(1+e^{i\phi})t^2/2+O(t^3)$. Substitution in $2|\psi_{00}\psi_{11}-\psi_{01}\psi_{10}|$ yields $2J^2t^2|\sin(\phi/2)|+O(t^3)$.
3. **Return probability.** The first flux-sensitive contribution to $(H^k)_{00,00}$ is at $k=4$, when the two oriented loops contribute $2J^4\cos\phi$. Interference with the constant return amplitude doubles the amplitude coefficient, giving $J^4t^4(\cos\phi-1)/6$ for $P_{00}(\phi,t)-P_{00}(0,t)$. All odd powers of $t$ vanish because the return amplitude at $-t$ is the complex conjugate at $t$. The remainder is $O(t^6)$.
4. **Characteristic polynomial.** In the Leibniz sum, the two oriented four-cycles have odd permutation parity and contribute $-2J^4\cos\phi$. All other permutations contain only diagonal elements, backtracking transpositions or products of them. The polynomial changes by the constant $2J^4(1-\cos\phi)$.
5. **Tree control.** After cutting any edge, choose a root and assign each vertex the phase accumulated along the unique path from the root. A diagonal rephasing then maps $H(0)$ for that tree to $H(\phi)$. The corresponding evolution operators are related by the same conjugation. Their entries have identical magnitudes for every initial and final site.

The validator evaluates the determinant by an independent permutation expansion, computes return-series coefficients from matrix powers, compares full zero-flux unitaries, checks the concurrence coefficient and numerical limit, and tests all four tree cuts across all site transitions. It repeats phase-sensitive algebraic checks for an additional choice of $(a,b,J)$. The largest flux-dependent tree-probability residual in the reference run was $2.22\times10^{-15}$.
