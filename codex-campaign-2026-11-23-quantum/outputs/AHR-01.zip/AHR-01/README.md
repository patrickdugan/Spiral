# AHR-01 · Arithmetic Holonomy Rotor

Can a phase around the four-site multiplication square $1\rightarrow2\rightarrow6\rightarrow3\rightarrow1$ change the return probability and entangle the two exponent qubits? This package gives the exact reference, compiled circuits, Aer simulations, statistical analysis, and an Open Plan execution path.

**QPU decision · HOLD.** The local package passes the mathematical gate. The account probe found no IBM Cloud credential in the standard Qiskit sources, and the desktop search did not locate the key. Live free allocation and calibration remain unverified. The supplied research bundle and its script were not accessible in this chat or workspace. The equations and endpoint values in the request served as the specification for the independent validator.

| Deliverable | File |
| --- | --- |
| Numerical findings, error budget and QPU decision | [REPORT.md](REPORT.md) |
| Derivations and independent checks | [MATH.md](MATH.md), [ahr01/validate.py](ahr01/validate.py) |
| Return curves and all 17 pilot rows | [plot](results/return_probabilities.png), [CSV](results/return_probabilities.csv), [full site distributions](results/pilot_predictions.json) |
| Square and tree contrasts, including intervals | [contrasts.json](results/contrasts.json) |
| Entanglement estimates, density matrices, and tomography counts | [entanglement.json](results/entanglement.json), [tomography_predictions.json](results/tomography_predictions.json) |
| Circuits, calibration, checksums and comparison | [manifest.json](results/manifest.json), [compilation.json](results/compilation.json), [pilot QPY](results/pilot.qpy), [tomography QPY](results/tomography.qpy) |
| Hardware decision record and AHR-02 design | [qpu_decision.json](results/qpu_decision.json), [AHR-02.md](AHR-02.md) |

## Reproduce locally

Use Python 3.12 in the AHR-01 directory. Activate a virtual environment or invoke its Python directly.

```shell
python -m pip install -r requirements.txt
python -m ahr01 validate
python -m pytest -q
python -m ahr01 prepare --out runs/reference
```

The local command uses the IBM Runtime `FakeTorino` calibration snapshot. Aer computes exact statevector probabilities on the compiled ISA circuits and samples the calibration-derived noise model with 32,768 shots per circuit. The manifest captures the seeds, versions and selected pair. Data and numerical results should reproduce to floating-point precision under the pinned environment. File hashes identify a particular QPY serialization. Arithmetic labels correspond to $x=q_0$ and $y=q_1$. The bit strings display $y$ then $x$.

## Run on IBM Quantum

Supply the path to an existing IBM Cloud API key file in `--token-file`, or omit that option with an existing default Qiskit account or the `QISKIT_IBM_TOKEN` environment variable. Omit `--instance` if the account has one verified Open Plan instance. Supply `--backend` on `probe` and `prepare` to pin an available QPU. The default picks the least-busy operational QPU within the verified instance and ranks adjacent pairs by calibration.

```shell
python -m ahr01 probe --token-file PATH_TO_KEY
python -m ahr01 prepare --live --out runs/live-pilot --token-file PATH_TO_KEY
python -m ahr01 submit --run runs/live-pilot --confirm-free-qpu --token-file PATH_TO_KEY
python -m ahr01 collect --run runs/live-pilot --wait 45 --token-file PATH_TO_KEY
```

`probe` and `prepare` are read-only against IBM. `submit` uses IBM Runtime 0.52.1's client-side `SamplerV2` in job mode. It checks the live calibration and executable hash, reads the remaining free allocation again, sets a QPU-time cap, and writes a job checkpoint before submitting. If a submission times out, `collect` searches for the existing job by its tag. Repeat `collect` while the job is pending. Completion writes original counts, job ID, reported QPU usage, updated intervals and plots. IBM lists Open Plan availability and remaining usage in its documentation. [Plans](https://quantum.cloud.ibm.com/docs/en/ibm-quantum-platform/plans-overview) · [Remaining usage](https://quantum.cloud.ibm.com/docs/en/ibm-quantum-compute/monitor-job#view-remaining-usage) · [Client-side Sampler](https://quantum.cloud.ibm.com/docs/en/api/qiskit-ibm-runtime/executor-sampler-sampler)

After collecting the pilot, use the same `submit` and `collect` commands with `--kind tomography` if a fresh allocation check covers the 18 optional settings. If calibration has changed, prepare a new live suite and submit tomography with `--run runs/new-calibration --after-pilot runs/live-pilot`. The tomography checkpoint links to the original pilot job.
