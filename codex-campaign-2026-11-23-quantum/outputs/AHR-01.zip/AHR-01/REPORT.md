# AHR-01 results and resource report

**HOLD for IBM QPU execution.** The independent validation and archived-target simulations support running the pilot once an Open Plan account and its remaining allocation can be checked. The local account probe found no credential. Live physical calibration, queue and free allocation are unknown. Hardware observations and usage are unavailable.

## Primary and control results

The closed square uses $\phi=0,\pi/2,\pi$ at all five prespecified times. Both broken-square circuits use $t=1.6$, with the $1\leftrightarrow2$ edge removed and the phased edge retained. The table gives the $t=1.6$ endpoint. The noisy intervals describe repeated sampling of the archived Aer model.

| Circuit or contrast | Exact | Compiled Aer ideal | Aer noise model | Noisy 95% interval |
| --- | ---: | ---: | ---: | --- |
| Square $P_{00}(0)$ | 0.033830 | 0.032283 | 0.035614 | [0.033661, 0.037676] |
| Square $P_{00}(\pi/2)$ | 0.208541 | 0.203181 | 0.208496 | [0.204132, 0.212929] |
| Square $P_{00}(\pi)$ | 0.543163 | 0.533592 | 0.523804 | [0.518394, 0.529208] |
| **Square $\Delta P=P_{00}(\pi)-P_{00}(0)$** | **+0.509333** | **+0.501309** | **+0.488190** | **[+0.482400, +0.493936]** |
| Tree $P_{00}(0)$ | 0.171231 | 0.167720 | 0.170563 | [0.166529, 0.174674] |
| Tree $P_{00}(\pi)$ | 0.171231 | 0.167720 | 0.170593 | [0.166559, 0.174705] |
| Tree $\Delta P$ | 0 | 0 | +0.000031 | [−0.005729, +0.005790] |

The early-time square contrast is negative, as expected from the fourth-order coefficient. It is positive by $t=1.2$ on the prespecified grid. All five times appear in the [return plot](results/return_probabilities.png) and [table](results/return_probabilities.csv). Use the $t=1.6$ square $\pi-0$ contrast as the primary inference. The remaining times, the intermediate flux and the tree contrast are secondary. The square arms are paired by time and layout. Shots from distinct circuits are separate binomial samples. Use 95% Wilson intervals for individual probabilities and Newcombe method 10 for arm differences. [Newcombe (1998)](https://doi.org/10.1002/%28SICI%291097-0258%2819980430%2917%3A8%3C873%3A%3AAID-SIM779%3E3.0.CO%3B2-I)

## Synthesis and error budget

The reference is IBM Runtime's archived Torino target, with calibration dated 2025-02-26 UTC. The low-error adjacent pair is $q_0\mapsto92$, $q_1\mapsto99$. Its CZ error is 0.00318 and its readout errors are 0.00903 and 0.00952. The transpiler used optimization level 3, seed 314159, a fixed layout and disabled routing.

| Evolution implementation | Depth summed over 17 circuits | Max compiled depth | Total native 2Q gates | Worst ideal $P_{00}$ error | Meets 0.015 |
| --- | ---: | ---: | ---: | ---: | :---: |
| Exact full $4\times4$ unitary | 231 | 20 | 26 | $3.2\times10^{-15}$ | Yes |
| Second-order Suzuki–Trotter, 2 repetitions | 227 | 20 | 25 | 0.171550 | No |
| Second-order Suzuki–Trotter, 4 repetitions | 230 | 20 | 26 | 0.039293 | No |
| **Second-order Suzuki–Trotter, 8 repetitions** | **230** | **20** | **26** | **0.009571** | **Yes** |

One circuit method is selected for the whole pilot to keep the comparison consistent across flux and control arms. Eligible methods are ranked by total compiled depth, then max depth and total native 2Q gates. Full two-qubit block resynthesis at optimization level 3 explains why increasing the repetition count scarcely alters device depth. At the primary endpoint, the zero-flux circuit compiles to depth 6 with no CZ gates. The $\pi$ circuit compiles to depth 16 with two CZ gates. Both tree circuits have depth 20 and three CZ gates.

| Contribution at $t=1.6$ | Effect on square contrast |
| --- | ---: |
| Approximation and ideal compilation, compiled minus exact | −0.00802 |
| Archived noise model, noisy minus compiled including Monte Carlo error | −0.01312 |
| Projected 95% statistical half-width with 2,048 shots per arm at the exact probabilities | about 0.023 |

The different gate counts make gate exposure, readout, relaxation and drift relevant to a hardware contrast. The noise model approximates calibration-derived gate and readout errors and relaxation. Its sampling intervals quantify finite simulated counts. Coherent calibration errors, crosstalk, changes in device state and successive-shot dependence can contribute additional hardware error. Use measured counts, live calibrated Aer results and the tree pair together when interpreting a hardware contrast. A tree interval overlapping zero supplies a consistency check. Demonstrating practical equivalence would require a separately prespecified margin.

## Entanglement at $t=0.8$

For each flux, sample the nine settings $XX,XY,XZ,YX,YY,YZ,ZX,ZY,ZZ$, in $x,y$ order. The state estimate comes from Pauli linear inversion followed by Frobenius projection onto positive trace-one matrices. Report Wootters mixed-state concurrence and a 600-resample per-setting multinomial bootstrap percentile interval. Near the separability boundary, projection and the nonnegative concurrence floor can bias the point estimate and descriptive bootstrap. [Wootters (1998)](https://doi.org/10.1103/PhysRevLett.80.2245)

The certification statistic uses a fixed witness $W=\lambda_{\max}I-|\psi_{\rm exact}\rangle\langle\psi_{\rm exact}|$, where $\lambda_{\max}$ is the largest squared Schmidt coefficient of the ideal target. Its overlap bound holds for every separable mixed state by convexity. Estimate $W$ directly from the linear Pauli expectations and use an upper one-sided 95% Hoeffding bound. A negative upper bound certifies entanglement under independent sampling and valid Pauli measurement axes. Basis and readout systematics require separate assessment on a QPU.

| Flux | Ideal concurrence | Aer reconstructed concurrence | Aer descriptive 95% interval | Witness estimate | Witness upper 95% bound |
| --- | ---: | ---: | --- | ---: | ---: |
| $0$ | 0 | 0.00069 | [0.00000, 0.01200] | +0.01836 | +0.02380 |
| $\pi$ | 0.77218 | 0.71152 | [0.70460, 0.71912] | −0.14983 | −0.14355 |

The $\pi$ noise-model simulation passes the witness criterion at 32,768 shots per setting. Hardware sampling is planned at 2,048 shots per setting and requires a fresh calculation of the witness bound. Primary return counts alone do not establish entanglement.

## Resource gate

| Workload | Circuits × shots | Total shots | Modeled pulses, measurement and delays | Free time reserved |
| --- | ---: | ---: | ---: | ---: |
| Primary pilot including 2 tree controls | 17 × 2,048 | 34,816 | 17.53 s | 78 s |
| Optional follow-up tomography | 18 × 2,048 | 36,864 | 18.56 s | 79 s |

The planning model adds the serial instruction durations, a 500 μs allowance per shot for reset and delays, and a 60 s reserve per job. Recompute it against live calibration. IBM reports standard QPU usage in time or resource units, with one RU equivalent to 60 QPU seconds. Use the actual remaining account allocation at submission. The client sets the full reserved amount as the QPU execution cap. IBM Open Plan documentation limits dry-run access to other plans, so the shipped plan uses a local estimate and records actual usage when the hardware job returns. [IBM workload usage](https://quantum.cloud.ibm.com/docs/en/ibm-quantum-compute/estimate-job-run-time) · [Execution cap](https://quantum.cloud.ibm.com/docs/en/ibm-quantum-compute/max-execution-time) · [IBM plans](https://quantum.cloud.ibm.com/docs/en/ibm-quantum-platform/plans-overview)

## Scientific scope

The simulation demonstrates the effect of controlled circulation phase on a four-site tight-binding system with logarithmic on-site detunings. The prime labels assign a concrete arithmetic interpretation to the sites. The short-time loop coefficient and characteristic-polynomial shift apply for arbitrary $a,b$; they arise from the graph and its phases. AHR-01 does not establish arithmetic-specific enhancement, a spectral resonance or a computational advantage. The [AHR-02 design](AHR-02.md) separates those questions. Related synthetic-flux experiments provide physical context. [Single-plaquette flux insertion](https://arxiv.org/abs/2105.02070) · [Photonic Aharonov–Bohm cages](https://arxiv.org/abs/1805.03564)
