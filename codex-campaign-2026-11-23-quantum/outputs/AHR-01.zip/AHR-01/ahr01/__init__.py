"""Arithmetic Holonomy Rotor experiment."""
