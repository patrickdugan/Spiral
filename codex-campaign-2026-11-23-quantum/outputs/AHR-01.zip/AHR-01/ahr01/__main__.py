"""CLI entry points. Local preparation is the default path."""

import argparse
import json
import logging
from pathlib import Path

from .validate import validate


def main(argv=None):
    parser = argparse.ArgumentParser(prog="python -m ahr01")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("validate", help="run the exact and Qiskit Pauli-ordering checks")
    probe = commands.add_parser("probe", help="read the actual free allocation and backend status")
    prepare_parser = commands.add_parser("prepare", help="generate simulations, QPY and manifest")
    prepare_parser.add_argument("--out", type=Path, required=True, help="new or empty output folder")
    prepare_parser.add_argument("--live", action="store_true", help="use fresh Open Plan calibration")
    submit_parser = commands.add_parser("submit", help="submit one prepared Open Plan workload")
    submit_parser.add_argument("--run", type=Path, required=True)
    submit_parser.add_argument("--kind", choices=("pilot", "tomography"), default="pilot")
    submit_parser.add_argument("--confirm-free-qpu", action="store_true", required=True)
    submit_parser.add_argument("--after-pilot", type=Path, help="collected pilot in another calibration block")
    collect_parser = commands.add_parser("collect", help="retrieve an existing job without resubmission")
    collect_parser.add_argument("--run", type=Path, required=True)
    collect_parser.add_argument("--kind", choices=("pilot", "tomography"), default="pilot")
    collect_parser.add_argument("--wait", type=int, choices=range(1, 61), metavar="1-60")
    for command in (probe, prepare_parser, submit_parser, collect_parser):
        command.add_argument("--token-file", type=Path, help="path to existing key text or IBM key JSON")
        command.add_argument("--instance", help="existing Open Plan instance name or CRN")
    for command in (probe, prepare_parser):
        command.add_argument("--backend", help="operational IBM hardware name; auto-select if omitted")
    args = parser.parse_args(argv)
    if args.command == "validate":
        from .validate import validate_qiskit

        result = validate()
        validate_qiskit()
        result["checks"]["qiskit_sparse_pauli_little_endian"] = "pass"
        print(json.dumps(result, indent=2))
        return 0

    from .experiment import prepare
    from .hardware import (
        Hold,
        allocation,
        collect,
        open_service,
        select_backend,
        submit,
    )

    live = args.command != "prepare" or args.live
    if args.command == "prepare" and args.out.exists() and any(args.out.iterdir()):
        parser.error("--out must be a new or empty folder")
    if not live and (args.backend or args.token_file or args.instance):
        parser.error("a hardware backend, instance or credential requires --live")
    if args.command == "submit" and args.after_pilot is not None and args.kind != "tomography":
        parser.error("--after-pilot is for the tomography follow-up")
    # Provider debug messages can include account identifiers. Report a sanitized error on failure.
    logging.getLogger("qiskit_ibm_runtime").setLevel(logging.CRITICAL)
    logging.getLogger("ibm_cloud_sdk_core").setLevel(logging.CRITICAL)
    try:
        if live:
            service = open_service(args.token_file, args.instance)
        if args.command == "probe":
            result = allocation(service)
            backend = select_backend(service, args.backend)
            result.update(backend=backend.name, pending_jobs=backend.status().pending_jobs)
        elif args.command == "prepare":
            account = None
            if live:
                account = allocation(service)
                backend = select_backend(service, args.backend)
            else:
                from qiskit_ibm_runtime.fake_provider import FakeTorino

                backend = FakeTorino()
            manifest = prepare(backend, args.out, live_account=account)
            result = {
                "output": str(args.out.resolve()), "target_type": manifest["target_type"],
                "backend": backend.name, "selected": manifest["selection"]["pilot"],
                "resources": manifest["resource_estimates"],
            }
            if account:
                result["free_qpu_seconds"] = account["remaining_qpu_seconds"]
        elif args.command == "submit":
            result = submit(
                service, args.run, args.kind, authorized=args.confirm_free_qpu,
                after_pilot=args.after_pilot,
            )
        else:
            result = collect(service, args.run, args.kind, wait_seconds=args.wait)
    except Hold as exc:
        print(f"HOLD — {exc}")
        return 2
    except Exception as exc:
        if not live:
            raise
        print(f"HOLD — {args.command} failed ({type(exc).__name__}). Check IBM access and the run directory.")
        return 2
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
