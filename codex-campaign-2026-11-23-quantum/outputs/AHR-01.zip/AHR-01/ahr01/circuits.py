"""Logical evolution, physical layout selection and ISA compilation."""

from collections import Counter
from itertools import product
from math import isfinite

import numpy as np
from qiskit import ClassicalRegister, QuantumCircuit
from qiskit.circuit.library import PauliEvolutionGate
from qiskit.quantum_info import SparsePauliOp
from qiskit.synthesis import SuzukiTrotter
from qiskit.transpiler import generate_preset_pass_manager
from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel

from .model import TREE_EDGE, matrix, pauli_coefficients, unitary

METHODS = ("exact", "strang_2", "strang_4", "strang_8")
ERROR_LIMIT = 0.015
TRANSPILER_SEED = 314159
SIMULATOR_SEED = 271828
SETTINGS = tuple("".join(setting) for setting in product("XYZ", repeat=2))


def evolution(point, method):
    circuit = QuantumCircuit(2, name=point.id.replace(".", "p"))
    if method == "exact":
        h = matrix(point.phi, removed=TREE_EDGE if point.tree else None)
        circuit.unitary(unitary(h, point.time), range(2), label="exp(-iHt)")
    else:
        if method not in METHODS:
            raise ValueError(f"unknown method {method}")
        terms = pauli_coefficients(point.phi, tree=point.tree)
        operator = SparsePauliOp.from_list([
            (label, value) for label, value in terms.items() if abs(value) > 1e-15
        ])
        steps = int(method.split("_")[1])
        synthesis = SuzukiTrotter(order=2, reps=steps, preserve_order=True)
        circuit.append(PauliEvolutionGate(operator, time=point.time, synthesis=synthesis), range(2))
    return circuit


def measure(circuit, setting="ZZ"):
    """A setting is written x then y. The register is displayed as y then x."""
    if setting not in SETTINGS:
        raise ValueError("expected one Pauli axis for x, followed by one for y")
    measured = circuit.copy()
    measured.add_register(ClassicalRegister(2, "out"))
    for qubit, axis in enumerate(setting):
        if axis == "Y":
            measured.sdg(qubit)
        if axis in ("X", "Y"):
            measured.h(qubit)
    measured.measure([0, 1], [0, 1])
    return measured


def _valid_error(calibration):
    return (
        calibration is not None and calibration.error is not None
        and isfinite(calibration.error) and 0 <= calibration.error < 1
    )


def pick_layout(backend):
    """Rank adjacent pairs by three native two-qubit gates and two readouts."""
    target = backend.target
    candidates = []
    for operation in ("cx", "cz", "ecr"):
        if operation not in target:
            continue
        for pair, calibration in target[operation].items():
            if pair is None or not _valid_error(calibration):
                continue
            readout = [target["measure"].get((qubit,)) for qubit in pair]
            if not all(_valid_error(item) for item in readout):
                continue
            qubits = [target.qubit_properties[qubit] for qubit in pair]
            coherence = min(value.t2 or 0 for value in qubits)
            score = 3 * calibration.error + sum(item.error for item in readout)
            candidates.append((score, -coherence, pair, operation, calibration))
    if not candidates:
        raise ValueError("no adjacent pair with usable native gate and readout calibrations")
    score, _, pair, operation, gate = min(candidates, key=lambda x: x[:4])
    properties = backend.properties()
    calibration = {
        "backend": backend.name,
        "backend_version": backend.backend_version,
        "calibration_id": getattr(backend, "calibration_id", None),
        "calibration_timestamp": properties.last_update_date.isoformat() if properties else None,
        "logical_to_physical": dict(zip(("x_q0", "y_q1"), pair, strict=True)),
        "pair_score": score,
        "native_pair_gate": {
            "operation": operation, "qargs": pair, "error": gate.error, "duration_s": gate.duration
        },
        "qubits": [],
        "instruction_properties": [],
    }
    for qubit in pair:
        values = target.qubit_properties[qubit]
        calibration["qubits"].append({
            "physical": qubit, "t1_s": values.t1, "t2_s": values.t2,
            "frequency_hz": values.frequency,
            "readout_error": target["measure"][(qubit,)].error,
        })
    for operation in sorted(target.operation_names):
        for qargs, item in target[operation].items():
            if item is not None and qargs and set(qargs).issubset(pair):
                calibration["instruction_properties"].append({
                    "operation": operation, "qargs": qargs,
                    "duration_s": item.duration, "error": item.error,
                })
    return pair, calibration


def compile_circuits(backend, pair, logical):
    manager = generate_preset_pass_manager(
        backend=backend, optimization_level=3, seed_transpiler=TRANSPILER_SEED,
        initial_layout=list(pair), routing_method="none", approximation_degree=1.0,
    )
    circuits = manager.run(logical, num_processes=1)
    for compiled in circuits:
        for instruction in compiled.data:
            qargs = tuple(compiled.find_bit(bit).index for bit in instruction.qubits)
            if not set(qargs).issubset(pair):
                raise ValueError("compilation escaped the calibrated physical pair")
            if not backend.target.instruction_supported(
                operation_name=instruction.operation.name, qargs=qargs
            ):
                raise ValueError("the compiled circuit contains a non-ISA instruction")
        if measurement_qubits(compiled) != tuple(pair):
            raise ValueError("measurement output does not match the pinned x/y layout")
    return circuits


def measurement_qubits(circuit):
    qubits = {}
    for item in circuit.data:
        if item.operation.name == "measure":
            qubits[circuit.find_bit(item.clbits[0]).index] = circuit.find_bit(item.qubits[0]).index
    return qubits[0], qubits[1]


def circuit_metrics(circuit, target):
    counts = Counter(item.operation.name for item in circuit.data if item.operation.num_qubits == 2)
    duration = 0.0
    missing = set()
    for item in circuit.data:
        qargs = tuple(circuit.find_bit(bit).index for bit in item.qubits)
        values = target[item.operation.name].get(qargs)
        if values is None or values.duration is None:
            if item.operation.name != "rz":  # virtual frame change
                missing.add(item.operation.name)
        else:
            duration += values.duration
    return {
        "depth": circuit.depth(),
        "two_qubit_gates": sum(counts.values()),
        "two_qubit_operations": dict(counts),
        "logical_to_physical": list(measurement_qubits(circuit)),
        "serial_gate_measure_duration_s": duration,
        "missing_timing": sorted(missing),
    }


def aer_probabilities(circuits):
    bare = []
    for circuit in circuits:
        pair = measurement_qubits(circuit)
        copy = circuit.remove_final_measurements(inplace=False)
        copy.save_probabilities(list(pair))
        bare.append(copy)
    result = AerSimulator(method="statevector", max_parallel_threads=2).run(
        bare, shots=1, seed_simulator=SIMULATOR_SEED
    ).result()
    if not result.success:
        raise RuntimeError(f"Aer noiseless simulation failed: {result.status}")
    return [np.asarray(result.data(index)["probabilities"]) for index in range(len(circuits))]


def aer_noisy_counts(circuits, backend, shots):
    model = NoiseModel.from_backend(backend)
    if not model.noise_instructions:
        raise ValueError("backend did not produce an Aer noise model")
    simulator = AerSimulator(
        method="density_matrix", noise_model=model, max_parallel_threads=2, enable_truncation=True
    )
    result = simulator.run(circuits, shots=shots, seed_simulator=SIMULATOR_SEED).result()
    if not result.success:
        raise RuntimeError(f"Aer noisy simulation failed: {result.status}")
    return [result.get_counts(index) for index in range(len(circuits))]
