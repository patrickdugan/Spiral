"""Build, simulate and archive the pilot and optional tomography workload."""

import csv
import hashlib
import json
import platform
from dataclasses import asdict
from datetime import UTC, datetime
from importlib import metadata

import numpy as np
from qiskit import qpy

from .circuits import (
    ERROR_LIMIT,
    METHODS,
    SETTINGS,
    SIMULATOR_SEED,
    TRANSPILER_SEED,
    aer_noisy_counts,
    aer_probabilities,
    circuit_metrics,
    compile_circuits,
    evolution,
    measure,
    pick_layout,
)
from .model import (
    FLUXES,
    TIMES,
    TREE_EDGE,
    A,
    B,
    J,
    Point,
    pilot_points,
    probabilities,
    pure_concurrence,
    state,
)
from .statistics import BOOTSTRAP_SEED, binomial, difference, tomography
from .validate import validate, validate_qiskit

PILOT_SHOTS = 2048
NOISE_SHOTS = 32768
BOOTSTRAP_DRAWS = 600
PACKAGES = ("numpy", "scipy", "qiskit", "qiskit-aer", "qiskit-ibm-runtime", "matplotlib", "pytest")


def timestamp():
    return datetime.now(UTC).isoformat(timespec="seconds")


def write_json(path, data):
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temp.replace(path)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def resource_estimate(entries, shots):
    # Conservative planning assumptions, not provider estimates or guaranteed charges.
    reset_s = 0.0005
    reserve_s = 60
    missing = sorted({name for entry in entries for name in entry["missing_timing"]})
    modeled_s = shots * sum(reset_s + entry["serial_gate_measure_duration_s"] for entry in entries)
    return {
        "circuit_count": len(entries), "shots_per_circuit": shots,
        "total_shots": len(entries) * shots,
        "reset_and_delay_allowance_s_per_shot": reset_s,
        "modeled_pulse_reset_delay_seconds": modeled_s,
        "fixed_overhead_reserve_seconds": reserve_s,
        "required_remaining_free_seconds": int(np.ceil(reserve_s + modeled_s)),
        "unknown_nonvirtual_instruction_durations": missing,
    }


def point_prediction(point):
    vector = state(point.phi, point.time, removed=TREE_EDGE if point.tree else None)
    return {
        **asdict(point),
        "exact_site_probabilities": probabilities(vector).tolist(),
        "exact_concurrence": pure_concurrence(vector),
    }


def _tomo_points():
    return tuple(Point(f"tomo_{label}_t0.8", label, phi, 0.8) for label, phi in (FLUXES[0], FLUXES[2]))


def prepare(backend, output, *, live_account=None):
    checks = validate()
    validate_qiskit()
    checks["checks"]["qiskit_sparse_pauli_little_endian"] = "pass"
    pair, calibration = pick_layout(backend)
    points = tuple(pilot_points())
    predictions = [point_prediction(point) for point in points]
    suites = {}
    summary = {}
    comparison = []
    for method in METHODS:
        circuits = compile_circuits(backend, pair, [measure(evolution(p, method)) for p in points])
        suites[method] = circuits
        compiled = [circuit_metrics(c, backend.target) for c in circuits]
        ideal = aer_probabilities(circuits)
        for prediction, stats, p in zip(predictions, compiled, ideal, strict=True):
            comparison.append({
                "id": prediction["id"], "method": method, "p00_aer_ideal": float(p[0]),
                "p00_exact": prediction["exact_site_probabilities"][0],
                "absolute_p00_error": abs(float(p[0]) - prediction["exact_site_probabilities"][0]),
                **stats,
            })
        max_error = max(row["absolute_p00_error"] for row in comparison if row["method"] == method)
        summary[method] = {
            "total_depth": sum(row["depth"] for row in compiled),
            "max_depth": max(row["depth"] for row in compiled),
            "total_two_qubit_gates": sum(row["two_qubit_gates"] for row in compiled),
            "max_p00_error": max_error, "eligible": max_error <= ERROR_LIMIT,
        }

    eligible = [method for method in METHODS if summary[method]["eligible"]]
    if not eligible:
        raise RuntimeError("no implementation met the ideal P00 tolerance")
    selected = min(eligible, key=lambda name: (
        summary[name]["total_depth"], summary[name]["max_depth"], summary[name]["total_two_qubit_gates"]
    ))
    pilot = suites[selected]
    controls = [row for row in comparison if row["method"] == selected]
    for row, compiled, noisy in zip(
        predictions, controls, aer_noisy_counts(pilot, backend, NOISE_SHOTS), strict=True
    ):
        row["aer_ideal_p00"] = compiled["p00_aer_ideal"]
        row["aer_noisy_counts"] = noisy
        row["aer_noisy"] = binomial(noisy)
        row["aer_noisy_minus_ideal"] = row["aer_noisy"]["p00"] - row["aer_ideal_p00"]

    tomo_cases = [
        (point, setting) for point in _tomo_points() for setting in SETTINGS
    ]
    tomo = compile_circuits(backend, pair, [
        measure(evolution(point, "exact"), setting) for point, setting in tomo_cases
    ])
    tomo_metrics = [circuit_metrics(c, backend.target) for c in tomo]
    tomo_records = [
        {
            **asdict(point), "setting_x_then_y": setting,
            "aer_ideal_site_probabilities_after_basis_rotation": ideal.tolist(),
            "aer_noisy_counts": noisy,
            "compiled": metrics,
        }
        for (point, setting), ideal, noisy, metrics in zip(
            tomo_cases, aer_probabilities(tomo), aer_noisy_counts(tomo, backend, NOISE_SHOTS),
            tomo_metrics, strict=True
        )
    ]

    output.mkdir(parents=True, exist_ok=True)
    files = {}
    for tag, circuits in (("pilot", pilot), ("tomography", tomo)):
        path = output / f"{tag}.qpy"
        with path.open("wb") as stream:
            qpy.dump(circuits, stream)
        files[tag] = {"file": path.name, "sha256": digest(path)}

    manifest = {
        "experiment": "AHR-01", "schema": 1, "prepared_utc": timestamp(),
        "model": {
            "hbar": 1, "J": J, "a": A, "b": B, "sites_in_display_order": [1, 2, 3, 6],
            "x": "q0", "y": "q1", "classical_register": "out", "tree_removed_site_link": [1, 2],
            "times": TIMES, "fluxes": dict(FLUXES),
        },
        "validation": checks,
        "target_type": "live" if live_account else "archived_snapshot",
        "free_account_check_at_prepare": live_account,
        "calibration": calibration,
        "seeds": {"transpiler": TRANSPILER_SEED, "aer": SIMULATOR_SEED, "bootstrap": BOOTSTRAP_SEED},
        "optimization_level": 3, "routing": "none", "package_versions": {
            name: metadata.version(name) for name in PACKAGES
        },
        "python": platform.python_version(), "platform": platform.platform(),
        "selection": {
            "absolute_p00_error_limit": ERROR_LIMIT,
            "criterion": "minimum total depth over 17 circuits, then max depth, then total two-qubit gates",
            "methods": summary, "pilot": selected, "tomography": "exact",
        },
        "sampling": {"hardware_shots": PILOT_SHOTS, "aer_noise_shots": NOISE_SHOTS,
                     "bootstrap_replicates": BOOTSTRAP_DRAWS},
        "resource_estimates": {
            "pilot": resource_estimate(controls, PILOT_SHOTS),
            "tomography": resource_estimate(tomo_metrics, PILOT_SHOTS),
        },
        "hardware_enabled_by_default": False,
        "qpy": files,
        "ordered_circuits": {
            "pilot": [point.id for point in points],
            "tomography": [f"{point.id}_{setting}" for point, setting in tomo_cases],
        },
    }
    write_json(output / "manifest.json", manifest)
    write_json(output / "compilation.json", comparison)
    write_json(output / "pilot_predictions.json", predictions)
    write_json(output / "tomography_predictions.json", tomo_records)
    analyze(output)
    return manifest


def _contrasts(rows):
    grouped = {(row["tree"], row["time"], row["label"]): row for row in rows}
    result = []
    for tree, time in [(False, t) for t in TIMES] + [(True, TIMES[-1])]:
        zero = grouped[tree, time, "0"]
        for label in (("pi",) if tree else ("pi", "half")):
            other = grouped[tree, time, label]
            row = {
                "tree": tree, "time": time, "phi_vs_zero": label,
                "prespecified_primary": (not tree and label == "pi" and time == TIMES[-1]),
                "exact_delta": other["exact_site_probabilities"][0] - zero["exact_site_probabilities"][0],
                "aer_ideal_delta": other["aer_ideal_p00"] - zero["aer_ideal_p00"],
                "aer_noisy": difference(other["aer_noisy"], zero["aer_noisy"]),
            }
            if "hardware" in other and "hardware" in zero:
                row["hardware"] = difference(other["hardware"], zero["hardware"])
                row["hardware_minus_aer_noisy"] = row["hardware"]["delta"] - row["aer_noisy"]["delta"]
            result.append(row)
    return result


def _write_pilot_csv(output, rows):
    fields = ["id", "tree", "time", "phi_radians", "exact_p00", "aer_ideal_p00", "aer_noisy_p00",
              "aer_noisy_low", "aer_noisy_high", "hardware_p00", "hardware_low", "hardware_high"]
    with (output / "return_probabilities.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(fields)
        for row in rows:
            noisy = row["aer_noisy"]
            hardware = row.get("hardware") or {"p00": None, "wilson_95": [None, None]}
            writer.writerow([
                row["id"], row["tree"], row["time"], row["phi"], row["exact_site_probabilities"][0],
                row["aer_ideal_p00"], noisy["p00"], *noisy["wilson_95"], hardware["p00"],
                *hardware["wilson_95"],
            ])


def analyze(output):
    from .plot import plot_results

    rows = read_json(output / "pilot_predictions.json")
    hardware_path = output / "pilot_counts.json"
    if hardware_path.exists():
        hardware = read_json(hardware_path)["counts"]
        for row in rows:
            row["hardware"] = binomial(hardware[row["id"]])
            row["hardware_minus_exact"] = row["hardware"]["p00"] - row["exact_site_probabilities"][0]
            row["hardware_minus_aer_ideal"] = row["hardware"]["p00"] - row["aer_ideal_p00"]
            row["hardware_minus_aer_noisy"] = row["hardware"]["p00"] - row["aer_noisy"]["p00"]
        write_json(output / "pilot_observations.json", rows)
    _write_pilot_csv(output, rows)
    contrasts = _contrasts(rows)
    write_json(output / "contrasts.json", contrasts)
    plot_results(output, rows, contrasts)

    tomo_rows = read_json(output / "tomography_predictions.json")
    hardware_path = output / "tomography_counts.json"
    hardware = read_json(hardware_path)["counts"] if hardware_path.exists() else None
    analyzed = {}
    for point in _tomo_points():
        vector = state(point.phi, point.time)
        cases = [row for row in tomo_rows if row["id"] == point.id]
        analyzed[point.id] = {
            "exact_pure_concurrence": pure_concurrence(vector),
            "aer_noisy": tomography({
                row["setting_x_then_y"]: row["aer_noisy_counts"] for row in cases
            }, vector, replicates=BOOTSTRAP_DRAWS),
        }
        if hardware is not None:
            analyzed[point.id]["hardware"] = tomography({
                setting: hardware[f"{point.id}_{setting}"] for setting in SETTINGS
            }, vector, replicates=BOOTSTRAP_DRAWS)
    write_json(output / "entanglement.json", analyzed)
