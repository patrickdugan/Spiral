"""Explicitly authorized, Open-Plan-only job-mode execution and collection."""

import hashlib
import json
import math
import os
from uuid import uuid4

from qiskit import qpy
from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2

from .experiment import analyze, digest, read_json, timestamp, write_json


class Hold(RuntimeError):
    """A required hardware preflight condition was not met."""


def _token(token_file):
    if token_file:
        content = token_file.read_text(encoding="utf-8-sig").strip()
        if content.startswith("{"):
            fields = json.loads(content)
            content = fields.get("apikey") or fields.get("api_key") or fields.get("token")
        if not isinstance(content, str) or not content or any(c.isspace() for c in content):
            raise Hold("credential file must contain an IBM Cloud API key or IBM key JSON")
        return content
    for variable in ("QISKIT_IBM_TOKEN", "IBM_QUANTUM_API_KEY"):
        value = os.getenv(variable, "").strip()
        if value:
            return value
    for channel in ("ibm_quantum_platform", "ibm_cloud"):
        options = QiskitRuntimeService.saved_accounts(default=True, channel=channel)
        if len(options) == 1:
            return next(iter(options.values()))["token"]
    raise Hold("no IBM Cloud credential available in the environment or default Qiskit account")


def _free(instance):
    return str(instance.get("plan", "")).casefold() == "open" and (
        str(instance.get("pricing_type", "free")).casefold() == "free"
    )


def _hash_instance(crn):
    return hashlib.sha256(crn.encode("utf-8")).hexdigest()


def open_service(token_file=None, instance_selector=None):
    token = _token(token_file)
    discovery = QiskitRuntimeService(
        channel="ibm_quantum_platform", token=token, instance="auto", plans_preference=["open"]
    )
    instances = [row for row in discovery.instances() if _free(row)]
    if instance_selector:
        instances = [
            row for row in instances if instance_selector in (row["name"], row["crn"])
        ]
    if not instances:
        raise Hold("IBM account has no matching verified Open Plan instance")
    if len(instances) != 1:
        raise Hold("more than one Open Plan instance is available; use --instance with its name")
    crn = instances[0]["crn"]
    service = QiskitRuntimeService(channel="ibm_quantum_platform", token=token, instance=crn)
    _assert_open(service)
    return service


def _assert_open(service):
    crn = service.active_instance()
    if not crn or not any(row["crn"] == crn and _free(row) for row in service.instances()):
        raise Hold("active IBM instance is not verified as Open Plan")
    return crn


def _nonnegative_number(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def allocation(service):
    crn = _assert_open(service)
    usage = service.usage()
    candidates = []
    seconds = usage.get("usage_remaining_seconds")
    units = usage.get("usage_remaining_ru")
    if _nonnegative_number(seconds):
        candidates.append(seconds)
    if _nonnegative_number(units):
        candidates.append(60 * units)  # IBM standard QPU workload: 1 RU = 60 QPU seconds.
    if not candidates:
        raise Hold("IBM did not report remaining seconds or resource units")
    remaining = 0 if usage.get("usage_limit_reached") else min(candidates)
    return {
        "plan": "open", "instance_sha256": _hash_instance(crn), "checked_utc": timestamp(),
        "remaining_qpu_seconds": remaining,
        "provider_usage": {
            key: value for key, value in usage.items()
            if key in {
                "usage_limit_seconds", "usage_allocation_seconds", "usage_consumed_seconds",
                "usage_remaining_seconds", "usage_limit_ru", "usage_allocation_ru",
                "usage_consumed_ru", "usage_remaining_ru", "usage_limit_reached",
            }
        },
    }


def select_backend(service, backend_name=None, calibration_id=None):
    crn = _assert_open(service)
    if backend_name:
        backend = service.backend(backend_name, instance=crn, use_fractional_gates=False,
                                  calibration_id=calibration_id)
    else:
        backend = service.least_busy(instance=crn, operational=True, simulator=False, min_num_qubits=2)
    if not backend.status().operational or backend.configuration().simulator:
        raise Hold("selected IBM device is not an operational QPU")
    return backend


def _load_live_manifest(service, path):
    manifest = read_json(path / "manifest.json")
    if manifest["target_type"] != "live":
        raise Hold("prepare fresh ISA circuits against a live Open Plan backend before submission")
    if manifest["free_account_check_at_prepare"]["instance_sha256"] != _hash_instance(_assert_open(service)):
        raise Hold("the active Open Plan instance does not match the prepared workload")
    return manifest


def submit(service, path, kind, *, authorized=False, after_pilot=None):
    if not authorized:
        raise Hold("hardware submission requires --confirm-free-qpu")
    manifest = _load_live_manifest(service, path)
    pilot_job_id = None
    if kind == "tomography":
        pilot_path = after_pilot or path
        if not (pilot_path / "pilot_counts.json").is_file():
            raise Hold("collect the pilot before submitting optional tomography")
        _load_live_manifest(service, pilot_path)
        pilot_job_id = read_json(pilot_path / "pilot_counts.json")["job_id"]
    checkpoint = path / f"{kind}_job.json"
    if checkpoint.exists():
        raise Hold("a submission checkpoint exists; use collect to recover the job without resubmitting")
    calibration = manifest["calibration"]
    backend = select_backend(service, calibration["backend"])
    properties = backend.properties()
    if not properties or properties.last_update_date.isoformat() != calibration["calibration_timestamp"]:
        raise Hold("live calibration has changed; prepare the workload again")
    if getattr(backend, "calibration_id", None) != calibration["calibration_id"]:
        raise Hold("live calibration ID has changed; prepare the workload again")

    entry = manifest["qpy"][kind]
    qpy_path = path / entry["file"]
    if digest(qpy_path) != entry["sha256"]:
        raise Hold("prepared circuits failed their integrity check")
    with qpy_path.open("rb") as stream:
        circuits = qpy.load(stream)
    ids = manifest["ordered_circuits"][kind]
    resource = manifest["resource_estimates"][kind]
    shots = resource["shots_per_circuit"]
    if len(circuits) != len(ids) or not 1 <= shots <= 2048:
        raise Hold("prepared circuit count or shot count does not match the pilot protocol")
    if resource["unknown_nonvirtual_instruction_durations"]:
        raise Hold("pulse timing is incomplete for the prepared circuits")
    budget = resource["required_remaining_free_seconds"]
    checked = allocation(service)
    if checked["remaining_qpu_seconds"] < budget:
        raise Hold(f"insufficient free allocation: {checked['remaining_qpu_seconds']:.2f}s available, "
                   f"{budget}s reserved")
    tag = f"ahr01-{kind}-{uuid4().hex[:16]}"
    sampler = SamplerV2(mode=backend, options={
        "max_execution_time": budget,
        "environment": {"job_tags": [tag]},
        "twirling": {"enable_gates": False, "enable_measure": False},
        "dynamical_decoupling": {"enable": False},
    })
    record = {
        "job_id": None, "job_tag": tag, "kind": kind, "backend": backend.name,
        "attempt_started_utc": timestamp(), "free_account_check": checked,
        "sampler": "client-side SamplerV2/Executor", "shots_per_circuit": shots,
        "max_execution_time_s": budget, "qpy_sha256": entry["sha256"],
        "preceding_pilot_job_id": pilot_job_id,
    }
    # Exclusive creation prevents duplicate submissions, including after an ambiguous timeout.
    with checkpoint.open("x", encoding="utf-8") as stream:
        json.dump(record, stream, indent=2)
    job = sampler.run(circuits, shots=shots)
    record["job_id"] = job.job_id()
    write_json(checkpoint, record)
    return record


def collect(service, path, kind, wait_seconds=None):
    manifest = _load_live_manifest(service, path)
    checkpoint = path / f"{kind}_job.json"
    record = read_json(checkpoint)
    if record["qpy_sha256"] != manifest["qpy"][kind]["sha256"]:
        raise Hold("the prepared workload and submission checkpoint do not match")
    if record["job_id"] is None:
        matches = service.jobs(job_tags=[record["job_tag"]], instance=_assert_open(service), limit=2)
        if len(matches) != 1:
            raise Hold("submission outcome remains unconfirmed; check the job tag in IBM Workloads")
        record["job_id"] = matches[0].job_id()
        write_json(checkpoint, record)
    job = service.job(record["job_id"])
    status = job.status()
    if wait_seconds and not job.in_final_state():
        from qiskit_ibm_runtime.exceptions import RuntimeJobTimeoutError

        try:
            job.wait_for_final_state(timeout=wait_seconds)
        except RuntimeJobTimeoutError:
            pass
        status = job.status()
    status_report = {"job_id": record["job_id"], "status": status, "backend": record["backend"]}
    if status != "DONE":
        return status_report
    ids = manifest["ordered_circuits"][kind]
    counts = {
        case: result.data.out.get_counts() for case, result in zip(ids, job.result(), strict=True)
    }
    if any(sum(counter.values()) != record["shots_per_circuit"] for counter in counts.values()):
        raise Hold("returned shot count differs from the submitted workload")
    usage = job.usage()
    write_json(path / f"{kind}_counts.json", {
        **record, **status_report, "retrieved_utc": timestamp(), "quantum_seconds": usage,
        "counts": counts,
    })
    analyze(path)
    return {**status_report, "quantum_seconds": usage}
