"""Exact model in little-endian order (|00>, |01>, |10>, |11>) = (1, 2, 3, 6)."""

from dataclasses import dataclass
from math import log, pi

import numpy as np

A, B, J = log(2), log(3), 1.0
TIMES = (0.4, 0.8, 1.0, 1.2, 1.6)
FLUXES = (("0", 0.0), ("half", pi / 2), ("pi", pi))
MATRICES = {
    "I": np.eye(2, dtype=complex),
    "X": np.array([[0, 1], [1, 0]], dtype=complex),
    "Y": np.array([[0, -1j], [1j, 0]], dtype=complex),
    "Z": np.diag([1, -1]).astype(complex),
}
EDGES = ((0, 1), (0, 2), (1, 3), (2, 3))
TREE_EDGE = (0, 1)


@dataclass(frozen=True)
class Point:
    id: str
    label: str
    phi: float
    time: float
    tree: bool = False


def pilot_points():
    for time in TIMES:
        for label, phi in FLUXES:
            yield Point(f"square_{label}_t{time:.1f}", label, phi, time)
    for label, phi in (FLUXES[0], FLUXES[2]):
        yield Point(f"tree_{label}_t1.6", label, phi, 1.6, tree=True)


def matrix(phi, *, a=A, b=B, j=J, removed=None):
    link = j * np.exp(1j * phi)
    result = np.array([
        [0, j, j, 0],
        [j, a, 0, link.conjugate()],
        [j, 0, b, j],
        [0, link, j, a + b],
    ], dtype=complex)
    if removed is not None:
        if removed not in EDGES:
            raise ValueError("removed must be a square edge in ascending index order")
        row, col = removed
        result[row, col] = result[col, row] = 0
    return result


def pauli_coefficients(phi, *, a=A, b=B, j=J, tree=False):
    """Left character acts on y=q1. The pilot tree cuts 1↔2."""
    cos, sin = np.cos(phi), np.sin(phi)
    return {
        "II": (a + b) / 2,
        "IZ": -a / 2,
        "ZI": -b / 2,
        "IX": j / 2 if tree else j,
        "ZX": -j / 2 if tree else 0.0,
        "XI": j * (1 + cos) / 2,
        "XZ": j * (1 - cos) / 2,
        "YI": j * sin / 2,
        "YZ": -j * sin / 2,
    }


def tensor(label):
    return np.kron(MATRICES[label[0]], MATRICES[label[1]])


def unitary(hamiltonian, time):
    energies, vectors = np.linalg.eigh(hamiltonian)
    return (vectors * np.exp(-1j * energies * time)) @ vectors.conj().T


def state(phi, time, *, removed=None):
    return unitary(matrix(phi, removed=removed), time)[:, 0]


def probabilities(vector):
    return np.abs(vector) ** 2


def pure_concurrence(vector):
    return float(2 * abs(vector[0] * vector[3] - vector[1] * vector[2]))
