"""Publication-oriented plots for the pilot, with source data in adjacent files."""

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from .model import FLUXES, TREE_EDGE, probabilities, state

COLORS = {"0": "#28649A", "half": "#73539F", "pi": "#A14125"}
LABELS = {"0": r"$0$", "half": r"$\pi/2$", "pi": r"$\pi$"}


def _errorbars(axis, times, values, *, key, interval, color, marker, label=None):
    centers = np.array([row[key] for row in values])
    bounds = np.array([row[interval] for row in values]).T
    axis.errorbar(times, centers, yerr=np.maximum(0, (centers - bounds[0], bounds[1] - centers)),
                  fmt=marker, color=color, markersize=4.5, capsize=2, label=label, zorder=3)


def plot_results(output, rows, contrasts):
    grid = np.linspace(0, 1.6, 201)
    fig, (returns, delta, tree) = plt.subplots(
        1, 3, figsize=(11.5, 3.8), gridspec_kw={"width_ratios": [1.3, 1.2, 1.0]},
        layout="constrained",
    )
    hardware = "hardware" in rows[0]
    for label, phi in FLUXES:
        color = COLORS[label]
        values = [row for row in rows if not row["tree"] and row["label"] == label]
        times = [row["time"] for row in values]
        p = [probabilities(state(phi, t))[0] for t in grid]
        returns.plot(grid, p, color=color, label=f"Flux {LABELS[label]}")
        returns.scatter(times, [row["aer_ideal_p00"] for row in values], color=color,
                        marker="+", s=31, zorder=2)
        _errorbars(returns, times, [row["aer_noisy"] for row in values],
                   key="p00", interval="wilson_95", color=color, marker="o")
        if hardware:
            _errorbars(returns, times, [row["hardware"] for row in values],
                       key="p00", interval="wilson_95", color=color, marker="s")

        if label == "0":
            continue
        reference = [probabilities(state(0, t))[0] for t in grid]
        delta.plot(grid, np.array(p) - reference, color=color)
        paired = [row for row in contrasts if not row["tree"] and row["phi_vs_zero"] == label]
        delta.scatter(times, [row["aer_ideal_delta"] for row in paired], color=color,
                      marker="+", s=31, zorder=2)
        _errorbars(delta, times, [row["aer_noisy"] for row in paired],
                   key="delta", interval="newcombe_95", color=color, marker="o")
        if hardware:
            _errorbars(delta, times, [row["hardware"] for row in paired],
                       key="delta", interval="newcombe_95", color=color, marker="s")

    exact_tree = [probabilities(state(0, t, removed=TREE_EDGE))[0] for t in grid]
    tree.plot(grid, exact_tree, color="#394750", label="Exact, both fluxes")
    for row in (entry for entry in rows if entry["tree"]):
        color = COLORS[row["label"]]
        tree.scatter([row["time"]], [row["aer_ideal_p00"]], color=color, marker="+", s=31, zorder=2)
        _errorbars(tree, [row["time"]], [row["aer_noisy"]], key="p00", interval="wilson_95",
                   color=color, marker="o")
        if hardware:
            _errorbars(tree, [row["time"]], [row["hardware"]], key="p00", interval="wilson_95",
                       color=color, marker="s")
    returns.legend(loc="upper right", fontsize=8, frameon=False)
    tree.legend(loc="upper right", fontsize=8, frameon=False)
    delta.axhline(0, color="#737b84", linewidth=0.8)
    for axis, title, ylabel in zip(
        (returns, delta, tree), ("Closed square", "Flux contrast", "Broken square"),
        (r"Return probability $P_{00}$", r"$P_{00}(\phi)-P_{00}(0)$", r"Return probability $P_{00}$"),
        strict=True
    ):
        axis.set(title=title, xlabel=r"Evolution time $t$ ($\hbar=J=1$)", ylabel=ylabel,
                 xlim=(-0.04, 1.68), xticks=[0, 0.4, 0.8, 1.2, 1.6])
        axis.spines[["top", "right"]].set_visible(False)
        axis.grid(axis="y", color="#e7e9eb", linewidth=0.7)
        axis.set_axisbelow(True)
    returns.set_ylim(-0.04, 1.04)
    tree.set_ylim(-0.04, 1.04)
    subtitle = "Lines: exact   ·   +: Aer ideal   ·   ●: Aer noise model"
    if hardware:
        subtitle += "   ·   ■: QPU"
    fig.suptitle(f"AHR-01 return probability\n{subtitle}", fontsize=12)
    fig.savefig(output / "return_probabilities.png", dpi=210)
    plt.close(fig)
