"""Binomial endpoints and two-qubit Pauli tomography."""

from math import log, sqrt
from statistics import NormalDist

import numpy as np

from .model import tensor

STATES = ("00", "01", "10", "11")
SIGNS_X = np.array([1, -1, 1, -1])
SIGNS_Y = np.array([1, 1, -1, -1])
PARITY = SIGNS_X * SIGNS_Y
BOOTSTRAP_SEED = 161803


def wilson(k, n, confidence=0.95):
    if n <= 0 or not 0 <= k <= n:
        raise ValueError("expected a nonempty binomial sample")
    z = NormalDist().inv_cdf((1 + confidence) / 2)
    p = k / n
    center = (p + z**2 / (2 * n)) / (1 + z**2 / n)
    half_width = z * sqrt(p * (1 - p) / n + z**2 / (4 * n**2)) / (1 + z**2 / n)
    return [max(0.0, center - half_width), min(1.0, center + half_width)]


def binomial(counts):
    k, n = int(counts.get("00", 0)), int(sum(counts.values()))
    return {"zero_counts": k, "shots": n, "p00": k / n, "wilson_95": wilson(k, n)}


def difference(positive, reference):
    """Newcombe method 10 for independent shots in matched circuit conditions."""
    x, y = positive["p00"], reference["p00"]
    xl, xu = positive["wilson_95"]
    yl, yu = reference["wilson_95"]
    delta = x - y
    return {
        "delta": delta,
        "newcombe_95": [
            max(-1, delta - sqrt((x - xl)**2 + (yu - y)**2)),
            min(1, delta + sqrt((xu - x)**2 + (y - yl)**2)),
        ],
    }


def pauli_coefficients_by_setting(operator, setting):
    x, y = setting
    return np.array([
        np.trace(operator @ tensor(label)).real / 4 for label in (f"I{x}", f"{y}I", f"{y}{x}")
    ])


def linear_inversion(samples):
    """Uniformly average each marginal over the other party's three settings."""
    rho = tensor("II")
    for (x, y), p in samples.items():
        rho += (p @ SIGNS_X) * tensor(f"I{x}") / 3
        rho += (p @ SIGNS_Y) * tensor(f"{y}I") / 3
        rho += (p @ PARITY) * tensor(f"{y}{x}")
    return rho / 4


def project_density(matrix):
    """Frobenius projection onto positive, trace-one matrices."""
    values, vectors = np.linalg.eigh(matrix)
    descending = values[::-1]
    offsets = (np.cumsum(descending) - 1) / np.arange(1, 5)
    threshold = offsets[np.flatnonzero(descending > offsets)[-1]]
    return (vectors * np.maximum(values - threshold, 0)) @ vectors.conj().T


def mixed_concurrence(rho):
    values, vectors = np.linalg.eigh(rho)
    root = (vectors * np.sqrt(np.maximum(0, values))) @ vectors.conj().T
    yy = tensor("YY")
    product = root @ yy @ rho.conj() @ yy @ root
    values = np.sqrt(np.maximum(0, np.linalg.eigvalsh(product)))
    return float(np.clip(values[-1] - sum(values[:-1]), 0, 1))


def probabilities_by_setting(counts_by_setting):
    result = {}
    for setting, counts in counts_by_setting.items():
        values = np.array([counts.get(outcome, 0) for outcome in STATES], dtype=int)
        result[setting] = values / values.sum()
    return result


def fixed_witness(target, samples, shots):
    """Linear projector witness with a one-sided, distribution-free 95% bound."""
    if shots <= 0:
        raise ValueError("witness requires a positive common shot count")
    singular_values = np.linalg.svd(target.reshape(2, 2), compute_uv=False)
    overlap_bound = float(singular_values[0]**2)
    witness = overlap_bound * tensor("II") - np.outer(target, target.conj())
    value = np.trace(witness).real / 4
    variance_bound = 0.0
    for setting, p in samples.items():
        x, y, both = pauli_coefficients_by_setting(witness, setting)
        scores = x * SIGNS_X / 3 + y * SIGNS_Y / 3 + both * PARITY
        value += p @ scores
        variance_bound += float(np.ptp(scores)**2 / shots)
    upper = float(value + sqrt(variance_bound * log(20) / 2))
    return {
        "max_separable_target_overlap": overlap_bound,
        "witness": float(value),
        "witness_upper_95_hoeffding": upper,
        "certifies_entanglement_at_95": upper < 0,
    }


def tomography(counts_by_setting, target, *, replicates=600):
    expected = {x + y for x in "XYZ" for y in "XYZ"}
    if set(counts_by_setting) != expected:
        raise ValueError("tomography requires all nine x/y Pauli settings")
    shots_by_setting = {sum(counts.values()) for counts in counts_by_setting.values()}
    if len(shots_by_setting) != 1 or min(shots_by_setting) <= 0:
        raise ValueError("all nine settings require the same positive shot count")
    shots = shots_by_setting.pop()
    samples = probabilities_by_setting(counts_by_setting)
    linear = linear_inversion(samples)
    rho = project_density(linear)
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    draws = [
        mixed_concurrence(project_density(linear_inversion({
            setting: rng.multinomial(shots, p) / shots for setting, p in samples.items()
        })))
        for _ in range(replicates)
    ]
    return {
        "shots_per_setting": shots,
        "mixed_concurrence": mixed_concurrence(rho),
        "concurrence_bootstrap_95_descriptive": np.quantile(draws, [0.025, 0.975]).tolist(),
        "linear_density_min_eigenvalue": float(np.linalg.eigvalsh(linear)[0]),
        "density_matrix_real": rho.real.tolist(),
        "density_matrix_imag": rho.imag.tolist(),
        **fixed_witness(target, samples, shots),
    }
