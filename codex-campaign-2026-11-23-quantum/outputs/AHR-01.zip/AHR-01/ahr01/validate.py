"""Independent algebraic/numerical gates for the Hamiltonian and experiment."""

from itertools import permutations
from math import factorial, pi

import numpy as np

from .model import (
    EDGES,
    TIMES,
    A,
    B,
    J,
    matrix,
    pauli_coefficients,
    probabilities,
    pure_concurrence,
    state,
    tensor,
    unitary,
)

ATOL = 2e-12
PHASES = (0.0, pi / 2, pi, -0.71, 2.29)


def determinant_coefficients(hamiltonian):
    """Leibniz expansion with ascending polynomial coefficients."""
    coefficients = np.zeros(5, dtype=complex)
    for order in permutations(range(4)):
        inversions = sum(order[i] > order[j] for i in range(4) for j in range(i + 1, 4))
        product = np.array([(-1) ** inversions], dtype=complex)
        for row, col in enumerate(order):
            factor = [-hamiltonian[row, col], 1] if row == col else [-hamiltonian[row, col]]
            product = np.convolve(product, factor)
        coefficients[:len(product)] += product
    return coefficients


def return_series(hamiltonian):
    amplitude = np.array([
        (-1j) ** order * np.linalg.matrix_power(hamiltonian, order)[0, 0] / factorial(order)
        for order in range(6)
    ])
    return np.convolve(amplitude, amplitude.conj())[:6]


def validate():
    local_x = np.array([[0, J], [J, A]])
    local_y = np.array([[0, J], [J, B]])
    for time in (*TIMES, 0.02, 3.1):
        product = np.kron(unitary(local_y, time), unitary(local_x, time))
        np.testing.assert_allclose(unitary(matrix(0), time), product, atol=ATOL, rtol=0)
        assert pure_concurrence(product[:, 0]) < ATOL

    max_tree_delta = 0.0
    for a, b, j in ((A, B, J), (0.28, 1.81, 0.73)):
        zero = matrix(0, a=a, b=b, j=j)
        for phi in PHASES:
            h = matrix(phi, a=a, b=b, j=j)
            for removal in (None, EDGES[0]):
                terms = pauli_coefficients(phi, a=a, b=b, j=j, tree=removal is not None)
                expanded = sum(coefficient * tensor(label) for label, coefficient in terms.items())
                np.testing.assert_allclose(
                    expanded, matrix(phi, a=a, b=b, j=j, removed=removal), atol=ATOL, rtol=0
                )
            second_order = -np.linalg.matrix_power(h, 2)[3, 0] / 2 + h[1, 0] * h[2, 0]
            np.testing.assert_allclose(
                2 * abs(second_order), 2 * j**2 * abs(np.sin(phi / 2)), atol=ATOL, rtol=0
            )
            if phi:
                time = 1e-4
                scaled = pure_concurrence(unitary(h, time)[:, 0]) / time**2
                np.testing.assert_allclose(scaled, 2 * abs(second_order), atol=2e-4, rtol=0)
            delta = return_series(h) - return_series(zero)
            expected = [0, 0, 0, 0, j**4 * (np.cos(phi) - 1) / 6, 0]
            np.testing.assert_allclose(delta, expected, atol=ATOL, rtol=0)
            characteristic_delta = determinant_coefficients(h) - determinant_coefficients(zero)
            expected = [2 * j**4 * (1 - np.cos(phi)), 0, 0, 0, 0]
            np.testing.assert_allclose(characteristic_delta, expected, atol=ATOL, rtol=0)
            for edge in EDGES:
                tree = matrix(phi, a=a, b=b, j=j, removed=edge)
                reference = matrix(0, a=a, b=b, j=j, removed=edge)
                for time in TIMES:
                    actual = probabilities(unitary(tree, time))
                    target = probabilities(unitary(reference, time))
                    max_tree_delta = max(max_tree_delta, float(np.max(abs(actual - target))))
                    np.testing.assert_allclose(actual, target, atol=ATOL, rtol=0)

    p0, ppi = (float(probabilities(state(phi, 1.6))[0]) for phi in (0, pi))
    cpi = pure_concurrence(state(pi, 0.8))
    np.testing.assert_allclose([p0, ppi, cpi], [0.033830, 0.543163, 0.77218], atol=5e-6, rtol=0)
    return {
        "checks": {
            "zero_flux_full_unitary_factorization": "pass",
            "short_time_concurrence_coefficient": "pass",
            "return_series_through_order_five": "pass",
            "characteristic_polynomial_all_coefficients": "pass",
            "all_four_edge_removals_all_site_transitions": "pass",
            "little_endian_numpy_pauli_expansion": "pass",
            "prespecified_endpoints": "pass",
        },
        "max_tree_probability_deviation": max_tree_delta,
        "p00_zero_t1_6": p0,
        "p00_pi_t1_6": ppi,
        "delta_p_t1_6": ppi - p0,
        "concurrence_pi_t0_8": cpi,
    }


def validate_qiskit():
    from qiskit.quantum_info import SparsePauliOp

    for phi in PHASES:
        for tree in (False, True):
            terms = pauli_coefficients(phi, tree=tree)
            expanded = SparsePauliOp.from_list(list(terms.items())).to_matrix()
            reference = matrix(phi, removed=EDGES[0] if tree else None)
            np.testing.assert_allclose(expanded, reference, atol=ATOL, rtol=0)


if __name__ == "__main__":
    import json

    print(json.dumps(validate(), indent=2))
