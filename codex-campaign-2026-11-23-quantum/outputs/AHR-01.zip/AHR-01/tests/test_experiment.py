from math import pi
from types import SimpleNamespace

import numpy as np
import pytest
from ahr01.circuits import (
    SETTINGS,
    aer_probabilities,
    compile_circuits,
    evolution,
    measure,
    pick_layout,
)
from ahr01.hardware import Hold, allocation, submit
from ahr01.model import (
    TREE_EDGE,
    Point,
    matrix,
    pilot_points,
    pure_concurrence,
    state,
    unitary,
)
from ahr01.statistics import (
    binomial,
    difference,
    linear_inversion,
    mixed_concurrence,
    wilson,
)
from ahr01.validate import validate, validate_qiskit
from qiskit import QuantumCircuit
from qiskit.quantum_info import Operator, Statevector
from qiskit_ibm_runtime import SamplerV2
from qiskit_ibm_runtime.executor_sampler import Sampler
from qiskit_ibm_runtime.fake_provider import FakeTorino


def test_validation_and_ordering():
    result = validate()
    validate_qiskit()
    assert all(status == "pass" for status in result["checks"].values())


@pytest.mark.parametrize("tree", [False, True])
def test_exact_full_operator(tree):
    point = Point("test", "half", pi / 2, 0.8, tree=tree)
    expected = unitary(matrix(point.phi, removed=TREE_EDGE if tree else None), point.time)
    np.testing.assert_allclose(Operator(evolution(point, "exact")).data, expected, atol=1e-12)


def test_suzuki_strang_second_order_convergence():
    point = Point("test", "half", pi / 2, 0.8)
    expected = unitary(matrix(point.phi), point.time)
    errors = [
        np.linalg.norm(Operator(evolution(point, f"strang_{r}").decompose()).data - expected)
        for r in (2, 4, 8)
    ]
    assert 3.5 < errors[0] / errors[1] < 4.5
    assert 3.5 < errors[1] / errors[2] < 4.5


def test_pilot_shape():
    points = tuple(pilot_points())
    assert len(points) == len({point.id for point in points}) == 17
    assert sum(point.tree for point in points) == 2


def test_aer_layout_and_client_sampler_register_order():
    backend = FakeTorino()
    pair, _ = pick_layout(backend)
    circuit = QuantumCircuit(2)
    circuit.x(0)
    [compiled] = compile_circuits(backend, pair, [measure(circuit)])
    [probability] = aer_probabilities([compiled])
    np.testing.assert_allclose(probability, [0, 1, 0, 0], atol=1e-12)
    assert SamplerV2 is Sampler  # Runtime >=0.52 defaults to the client implementation.
    [result] = SamplerV2(mode=backend).run([compiled], shots=128).result()
    assert result.data.out.get_counts().get("01", 0) > 100


@pytest.mark.parametrize("phi", [0, pi / 2, pi])
def test_tomography_pauli_basis_and_mixed_concurrence(phi):
    point = Point("tomo", "test", phi, 0.8)
    samples = {
        setting: Statevector.from_instruction(
            measure(evolution(point, "exact"), setting).remove_final_measurements(inplace=False)
        ).probabilities()
        for setting in SETTINGS
    }
    vector = state(phi, 0.8)
    rho = linear_inversion(samples)
    np.testing.assert_allclose(rho, np.outer(vector, vector.conj()), atol=3e-12)
    assert abs(mixed_concurrence(rho) - pure_concurrence(vector)) < 2e-7
    assert mixed_concurrence(np.eye(4) / 4) == 0


def test_binomial_endpoints():
    assert wilson(0, 2048)[0] == 0
    assert wilson(2048, 2048)[1] == 1
    reference = binomial({"00": 69, "01": 1979})
    result = difference(binomial({"00": 1112, "11": 936}), reference)
    assert result["newcombe_95"][0] < result["delta"] < result["newcombe_95"][1]
    assert result["newcombe_95"][0] > 0.48


def _service(plan, usage):
    return SimpleNamespace(
        active_instance=lambda: "test-crn",
        instances=lambda: [{"plan": plan, "crn": "test-crn"}],
        usage=lambda: usage,
    )


def test_gate_requires_open_plan_and_actual_allocation():
    assert allocation(_service("open", {"usage_remaining_ru": 1.5}))["remaining_qpu_seconds"] == 90
    assert allocation(_service("open", {
        "usage_remaining_seconds": 120, "usage_remaining_ru": 1.0
    }))["remaining_qpu_seconds"] == 60
    with pytest.raises(Hold, match="not verified"):
        allocation(_service("pay-as-you-go", {"usage_remaining_seconds": 600}))
    with pytest.raises(Hold, match="did not report"):
        allocation(_service("open", {}))


def test_gate_requires_explicit_authorization(tmp_path):
    with pytest.raises(Hold, match="confirm-free-qpu"):
        submit(None, tmp_path, "pilot")
