# AHR-02 · Matched gauge-copy follow-up

The original AHR-02 run measured a gauge-copy return shift of $+0.03369$ at $t=1.5$, even though the two cube Hamiltonians predict the same distribution over all eight sites. This follow-up compares independently synthesized circuits with a matched implementation.

- [Results and interpretation](REPORT.md)
- [Contrast figure](results/matched_contrasts.png) · [All eight site probabilities](results/site_probabilities.csv)
- [Calibration, gates and resource manifest](results/manifest.json) · [Legacy and matched simulation data](results/simulation.json)
- [Raw IBM counts](results/pilot_counts.json) · [Pooled and block-level analysis](results/observations.json)

## Matched implementation

The modeled output is $|\psi\rangle=e^{-iHt}|000\rangle$. The gauge copy has output $D|\psi\rangle$ up to global phase, with $D_{ss}=e^{i\chi(s)}$. State preparation starts with nonnegative magnitude amplitudes synthesized with uniformly controlled $R_y$ rotations. A fixed diagonal scaffold applies the complex phases using the seven nontrivial binary parity terms. The parity scaffold uses eight adjacent controlled-NOTs and restores the basis mapping. The native gate sequence uses SX, virtual $R_z$, and CZ. At the end, logical $x,y,z$ are measured in the three tagged classical bits. This construction reproduces the full complex output states for the fixed $|000\rangle$ input. Its circuit scope is state preparation for this measurement. [Uniformly controlled rotations](https://arxiv.org/abs/quant-ph/0407010)

The gradient and its gauge copy share the complete magnitude preparation instruction for instruction. They differ only in the seven final virtual phase angles. All four arms share the same ordered list of native operation names and physical qubit arguments. The gradient repeat has the same native parameters as the gradient. The legacy implementation independently synthesizes each full cube unitary, as in the original pilot, and is rerun in simulation against the same calibrated target as the matched implementation.

## Comparisons

Four position-balanced blocks contain the gradient, gauge copy, XY + XZ, and the instruction-identical gradient repeat. The IBM job sends 2,048 shots per circuit. The order in the manifest is the submitted order. The analysis records each block and pools 8,192 shots per arm.

- The gauge endpoint is the gauge copy minus gradient in $P_{000}$. The follow-up uses a practical equivalence margin of ±0.02. A two-sided 95% interval entirely inside that margin meets the criterion.
- The incremental phase endpoint is gradient minus XY + XZ in the fixed site mass inherited from AHR-02. Its outcome set is $000$, $010$, $011$, $100$, $101$, and $110$. The exact contrast is approximately $+0.08047$. The return contrast is also reported.
- The identical repeat diagnostic compares the repeated gradient with the original gradient in $P_{000}$.

The results use marginal 95% Newcombe intervals based on separate binomial samples. Correlated device error and calibration drift can affect hardware outcomes. The calibrated Aer comparisons approximate a subset of these effects.

## Reproduce

Use Python 3.12. The ZIP includes the reusable AHR-01 and AHR-02 modules. In the source checkout, add the adjacent AHR-01 and AHR-02 directories to the import path. On PowerShell, run the following from the follow-up directory.

~~~powershell
$env:PYTHONPATH = @((Resolve-Path ../AHR-01).Path, (Resolve-Path ../AHR-02).Path) -join ';'
~~~

~~~shell
python -m pip install -r requirements.txt
python -m ahr02_gauge validate
python -m pytest -q
python -m ahr02_gauge prepare --out runs/archived
~~~

Supply a local IBM key file path or use an existing default Qiskit account. Live preparation verifies the Open Plan account, calibrates the circuit comparison, then simulates it. Submission checks the available free allocation again, verifies the live ISA calibration and the QPY digest, and caps the job. The local simulation command consumes zero QPU time. [IBM client-side Sampler](https://quantum.cloud.ibm.com/docs/en/api/qiskit-ibm-runtime/executor-sampler-sampler) · [IBM execution limits](https://quantum.cloud.ibm.com/docs/en/ibm-quantum-compute/max-execution-time)

~~~shell
python -m ahr02_gauge prepare --live --out runs/live --token-file PATH_TO_KEY
python -m ahr02_gauge submit --run runs/live --confirm-free-qpu --token-file PATH_TO_KEY
python -m ahr02_gauge collect --run runs/live --wait 45 --token-file PATH_TO_KEY
~~~
