# AHR-02 · Matched gauge-copy rerun

The matched rerun completed on **ibm_kingston**, IBM job **dc1t47ds2omc738b3gfg**, and was collected 2026-11-23 13:42:26 SGT. The independently synthesized original pilot was dc1spods2omc738b34u0.

At $t=1.5$, the matched gauge-copy return shift was **+0.01624** with 95% interval **[+0.00282, +0.02965]**. The interval extends outside the ±0.02 practical-equivalence margin. The original hardware point estimate was +0.03369. The matched site-mass contrast for gradient versus XY + XZ was **+0.07312**, with 95% interval **[+0.05940, +0.08680]**.

| Contrast | Exact | Legacy Aer | Matched Aer | Original IBM | Matched IBM | Matched IBM 95% interval |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| Gauge copy − gradient, return | 0.00000 | +0.00958 | +0.00256 | +0.03369 | +0.01624 | [+0.00282, +0.02965] |
| Gradient − XY + XZ, fixed site mass | +0.08047 | +0.06830 | +0.07512 | +0.02051 | +0.07312 | [+0.05940, +0.08680] |
| Gradient − XY + XZ, return | +0.00015 | +0.00056 | +0.00209 | -0.01367 | +0.00073 | [-0.01254, +0.01400] |
| Identical gradient repeat − gradient, return | 0.00000 | — | -0.00111 | — | -0.00671 | [-0.01993, +0.00650] |

The gauge interval excludes zero even with the matched gate skeleton and identical magnitude preparation. The identical-gradient control interval includes zero. The fixed-site gradient interval contains the exact redistribution prediction, and the gradient return interval includes zero. The fixed outcomes were 000, 010, 011, 100, 101, and 110.

The same three physical qubits were available for the original and matched runs. The matched state preparation changes the logical readout mapping relative to the legacy circuits and uses a later calibration. These cross-run differences leave the mechanism of the original shift unresolved. The terminal virtual phases were the only intentional parameter changes within the matched gauge pair.

## Circuit and simulation verification

All 6 matched-design checks passed. The largest absolute ideal compiled site error was 2.44e-15 for the matched implementation and 5.19e-12 for the recompiled legacy implementation.

| Circuit | Depth | Native CZ gates | Logical $x,y,z$ readout physical qubits |
| --- | ---: | ---: | --- |
| Legacy gradient | 125 | 31 | 38, 49, 48 |
| Legacy gauge_copy | 126 | 31 | 38, 49, 48 |
| Legacy xy_xz | 124 | 30 | 38, 49, 48 |
| Each matched arm | 112 | 16 | 49, 48, 38 |

Live rerun calibration was 2026-11-23 13:25:57 SGT. The original pilot calibration was 2026-11-23 12:51:40 SGT. Both simulations here use the rerun calibration and 65,536 shots per arm for the noise model. Ideal simulation also verifies the complex output of each state-preparation circuit up to global phase.

## Allocation and block results

Four blocks of four circuits returned 32,768 shots in total. The open allocation before the job was 567 s, with a 77 s job cap. IBM recorded **11 s** of QPU use, leaving **556 s**. The matched estimates pool repeated arms across the four position-balanced submission blocks. The repeated-gradient shots form a separate diagnostic.

| Block | Gauge return | Incremental gradient site mass | Identical-repeat return |
| --- | ---: | ---: | ---: |
| 1 | +0.00781 | +0.08203 | -0.01270 |
| 2 | +0.01514 | +0.08398 | -0.00879 |
| 3 | +0.01807 | +0.05469 | +0.01123 |
| 4 | +0.02393 | +0.07178 | -0.01660 |

- [Matched contrast figure](results/matched_contrasts.png) · [All site probabilities](results/site_probabilities.csv)
- [Raw IBM counts](results/pilot_counts.json) · [Calibration and circuit manifest](results/manifest.json)
- [Full simulation comparison](results/simulation.json) · [Block and pooled contrasts](results/observations.json)
