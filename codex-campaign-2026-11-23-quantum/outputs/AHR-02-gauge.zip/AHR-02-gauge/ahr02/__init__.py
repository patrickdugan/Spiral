"""Three-prime arithmetic holonomy experiment."""
