"""CLI entry points for validation, simulation, and opt-in IBM execution."""

import argparse
import json
import logging
from pathlib import Path

from ahr01.hardware import Hold, allocation, open_service, select_backend

from .experiment import prepare
from .hardware import collect, submit
from .validate import validate


def main(argv=None):
    parser = argparse.ArgumentParser(prog="python -m ahr02")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("validate")
    probe = commands.add_parser("probe")
    prep = commands.add_parser("prepare")
    prep.add_argument("--out", type=Path, required=True)
    prep.add_argument("--live", action="store_true")
    send = commands.add_parser("submit")
    send.add_argument("--run", type=Path, required=True)
    send.add_argument("--confirm-free-qpu", action="store_true", required=True)
    fetch = commands.add_parser("collect")
    fetch.add_argument("--run", type=Path, required=True)
    fetch.add_argument("--wait", type=int, choices=range(1, 61), metavar="1-60")
    for command in (probe, prep, send, fetch):
        command.add_argument("--token-file", type=Path)
        command.add_argument("--instance")
    for command in (probe, prep):
        command.add_argument("--backend")
    args = parser.parse_args(argv)
    logging.getLogger("qiskit_ibm_runtime").setLevel(logging.CRITICAL)
    logging.getLogger("ibm_cloud_sdk_core").setLevel(logging.CRITICAL)
    try:
        if args.command == "validate":
            result = validate()
        elif args.command == "prepare" and not args.live:
            from qiskit_ibm_runtime.fake_provider import FakeMarrakesh

            if args.backend or args.token_file or args.instance:
                parser.error("--live is required for an IBM instance, backend or credential")
            if args.out.exists() and any(args.out.iterdir()):
                parser.error("--out must be new or empty")
            result = prepare(FakeMarrakesh(), args.out)
        else:
            service = open_service(args.token_file, args.instance)
            if args.command == "probe":
                backend = select_backend(service, args.backend)
                result = {**allocation(service), "backend": backend.name}
            elif args.command == "prepare":
                if args.out.exists() and any(args.out.iterdir()):
                    parser.error("--out must be new or empty")
                quota = allocation(service)
                result = prepare(select_backend(service, args.backend), args.out, quota=quota)
            elif args.command == "submit":
                result = submit(service, args.run, authorized=args.confirm_free_qpu)
            else:
                result = collect(service, args.run, args.wait)
    except Hold as exc:
        print(f"HOLD — {exc}")
        return 2
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
