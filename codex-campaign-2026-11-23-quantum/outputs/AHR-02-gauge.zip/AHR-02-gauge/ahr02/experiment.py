"""Simulate, compile and analyze the AHR-02 preregistered pilot."""

import csv
import platform
from dataclasses import asdict
from importlib.metadata import version

import numpy as np
from ahr01.circuits import aer_noisy_counts
from ahr01.experiment import digest, read_json, resource_estimate, timestamp, write_json
from ahr01.statistics import difference, wilson
from qiskit import qpy

from .circuits import (
    METHODS,
    NOISE_SEED,
    SEED,
    compile_pilot,
    ideal_probabilities,
    select_patch,
)
from .model import (
    DESIGN_TIMES,
    DETUNINGS,
    PRIMARY_TIME,
    PRIMES,
    SETTINGS,
    SITES,
    TREE,
    Point,
    exact_record,
    expected_face_phases,
    hamiltonian,
    pilot,
)
from .validate import validate

SHOTS = 2048
SIM_SHOTS = 32768
RETURN_TOLERANCE = 0.015
SITE_TOLERANCE = 0.025
OUTCOMES = tuple(f"{i:03b}" for i in range(8))
CONTRASTS = (
    ("primary_gradient_minus_zero", "gradient", "zero"),
    ("intermediate_xy_minus_zero", "xy", "zero"),
    ("intermediate_xy_xz_minus_xy", "xy_xz", "xy"),
    ("gradient_minus_xy_xz", "gradient", "xy_xz"),
    ("gauge_copy_minus_gradient", "gauge_copy", "gradient"),
    ("tree_gradient_minus_tree_zero", "tree_gradient", "tree_zero"),
)


def sample_summary(counts):
    if not set(counts).issubset(OUTCOMES):
        raise ValueError("expected three-bit computational outcomes")
    n = sum(counts.values())
    probabilities = [counts.get(outcome, 0) / n for outcome in OUTCOMES]
    return {
        "shots": n, "p00": probabilities[0], "site_probabilities": probabilities,
        "wilson_95": wilson(counts.get("000", 0), n),
    }


def gradient_outcomes():
    a = exact_record(Point("gradient", PRIMARY_TIME))["site_probabilities"]
    b = exact_record(Point("xy_xz", PRIMARY_TIME))["site_probabilities"]
    return [i for i, (left, right) in enumerate(zip(a, b, strict=True)) if left - right > 1e-12]


def _mass_summary(counts, indices):
    hit = sum(counts.get(OUTCOMES[i], 0) for i in indices)
    shots = sum(counts.values())
    return {"p00": hit / shots, "wilson_95": wilson(hit, shots)}


def exact_grid():
    spectra = {}
    for name, setting in SETTINGS.items():
        values, vectors = np.linalg.eigh(hamiltonian(setting))
        record = {"eigenvalues": values.tolist(), "initial_state_spectral_weights": (abs(vectors[0])**2).tolist()}
        if not setting.tree:
            record["oriented_face_phases_radians"] = expected_face_phases(setting)
        spectra[name] = record
    return {
        "sites_in_bitstring_order": SITES,
        "design_times": DESIGN_TIMES,
        "fixed_primary_time": PRIMARY_TIME,
        "spectra": spectra,
        "grid": [exact_record(Point(name, time)) for time in (*DESIGN_TIMES, PRIMARY_TIME) for name in SETTINGS],
    }


def prepare(backend, out, *, quota=None):
    validation = validate()
    grid = exact_grid()
    points = pilot()
    predictions = [exact_record(point) for point in points]
    suite = {}
    comparisons = {}
    summary = {}
    patch, target, calibration = select_patch(backend)
    for method in METHODS:
        results = compile_pilot(backend, patch, target, points, method)
        compiled = [circuit for circuit, _ in results]
        suite[method] = compiled
        conditions = []
        for row, (unused_circuit, routing), p in zip(
            predictions, results, ideal_probabilities(compiled), strict=True,
        ):
            errors = abs(p - np.asarray(row["site_probabilities"]))
            conditions.append({
                "id": row["id"], **routing,
                "site_probabilities": p.tolist(),
                "absolute_return_error": float(errors[0]),
                "max_absolute_site_error": float(max(errors)),
            })
        comparisons[method] = conditions
        return_error = max(row["absolute_return_error"] for row in conditions)
        site_error = max(row["max_absolute_site_error"] for row in conditions)
        summary[method] = {
            "total_depth": sum(row["depth"] for row in conditions),
            "max_depth": max(row["depth"] for row in conditions),
            "total_two_qubit_gates": sum(row["two_qubit_gates"] for row in conditions),
            "routing_swaps_before_translation": sum(row["routing_swaps_before_translation"] for row in conditions),
            "max_absolute_return_error": return_error, "max_absolute_site_error": site_error,
            "eligible": return_error <= RETURN_TOLERANCE and site_error <= SITE_TOLERANCE,
        }
        print(f"{method}: {summary[method]}", flush=True)

    eligible = [method for method in METHODS if summary[method]["eligible"]]
    if not eligible:
        raise RuntimeError("No synthesis met the ideal return and all-site error thresholds")
    selected = min(eligible, key=lambda method: tuple(summary[method][key] for key in (
        "total_depth", "max_depth", "total_two_qubit_gates",
    )))
    compiled = suite[selected]
    noisy = aer_noisy_counts(compiled, backend, SIM_SHOTS)
    for row, candidate, counts in zip(predictions, comparisons[selected], noisy, strict=True):
        row["aer_ideal_site_probabilities"] = candidate["site_probabilities"]
        row["aer_noisy_counts"] = counts
        row["aer_noisy"] = sample_summary(counts)

    out.mkdir(parents=True, exist_ok=True)
    file = out / "pilot.qpy"
    with file.open("wb") as stream:
        qpy.dump(compiled, stream)
    manifest = {
        "experiment": "AHR-02", "schema": 1, "prepared_utc": timestamp(),
        "target_type": "live" if quota else "archived_snapshot",
        "free_account_check_at_prepare": quota, "validation": validation, "calibration": calibration,
        "model": {
            "primes": PRIMES, "detunings": DETUNINGS.tolist(), "hbar": 1, "J_xyz": [1, 1, 1],
            "basis_order": dict(zip(OUTCOMES, SITES, strict=True)),
            "settings": {name: asdict(setting) for name, setting in SETTINGS.items()},
            "tree_edges_by_site": [[SITES[s], SITES[s+(1 << axis)]] for axis, s in sorted(TREE)],
            "primary": {"time": PRIMARY_TIME, "positive": "gradient", "reference": "zero",
                        "observable": "P000"},
            "secondary_gradient_mass": {
                "time": PRIMARY_TIME, "positive": "gradient", "reference": "xy_xz",
                "outcomes": [OUTCOMES[i] for i in gradient_outcomes()],
                "rule": "fixed exact-model sites with positive gradient-minus-xy_xz probability",
            },
        },
        "package_versions": {name: version(name) for name in (
            "qiskit", "qiskit-aer", "qiskit-ibm-runtime", "numpy", "scipy", "matplotlib",
        )},
        "python": platform.python_version(),
        "transpiler": {"seed": SEED, "optimization_level": 3, "routing": "sabre_within_patch"},
        "simulator_seed": NOISE_SEED, "simulator_shots_per_circuit": SIM_SHOTS,
        "selection": {"selected": selected, "return_tolerance": RETURN_TOLERANCE,
                      "site_tolerance": SITE_TOLERANCE, "methods": summary},
        "resource_estimate": resource_estimate(comparisons[selected], SHOTS),
        "ordered_circuits": [point.id for point in points],
        "qpy": {"file": file.name, "sha256": digest(file)},
    }
    write_json(out / "manifest.json", manifest)
    write_json(out / "exact_grid.json", grid)
    write_json(out / "compilation.json", comparisons)
    write_json(out / "pilot_predictions.json", predictions)
    analyze(out)
    return manifest


def analyze(out):
    from .plot import plot

    rows = read_json(out / "pilot_predictions.json")
    raw = out / "pilot_counts.json"
    if raw.exists():
        counts = read_json(raw)["counts"]
        for row in rows:
            row["hardware"] = sample_summary(counts[row["id"]])
        write_json(out / "pilot_observations.json", rows)
    primary = {row["setting"]: row for row in rows if row["time"] == PRIMARY_TIME}
    contrasts = {}
    for key, positive, reference in CONTRASTS:
        a, b = primary[positive], primary[reference]
        item = {
            "time": PRIMARY_TIME, "positive": positive, "reference": reference,
            "exact": a["site_probabilities"][0] - b["site_probabilities"][0],
            "aer_ideal": a["aer_ideal_site_probabilities"][0] - b["aer_ideal_site_probabilities"][0],
            "aer_noisy": difference(a["aer_noisy"], b["aer_noisy"]),
            "exact_all_site_differences": (
                np.asarray(a["site_probabilities"]) - b["site_probabilities"]
            ).tolist(),
        }
        if raw.exists():
            item["hardware"] = difference(a["hardware"], b["hardware"])
            item["hardware_all_site_differences"] = (
                np.asarray(a["hardware"]["site_probabilities"]) - b["hardware"]["site_probabilities"]
            ).tolist()
        contrasts[key] = item
    indices = gradient_outcomes()
    a, b = primary["gradient"], primary["xy_xz"]
    item = {
        "time": PRIMARY_TIME, "positive": "gradient", "reference": "xy_xz",
        "outcomes": [OUTCOMES[i] for i in indices],
        "sites": [SITES[i] for i in indices],
        "exact": sum(a["site_probabilities"][i] - b["site_probabilities"][i] for i in indices),
        "aer_ideal": sum(
            a["aer_ideal_site_probabilities"][i] - b["aer_ideal_site_probabilities"][i] for i in indices
        ),
        "aer_noisy": difference(
            _mass_summary(a["aer_noisy_counts"], indices), _mass_summary(b["aer_noisy_counts"], indices),
        ),
    }
    if raw.exists():
        item["hardware"] = difference(
            _mass_summary(counts[a["id"]], indices), _mass_summary(counts[b["id"]], indices),
        )
    contrasts["secondary_gradient_fixed_site_mass"] = item
    write_json(out / "contrasts.json", contrasts)
    with (out / "site_probabilities.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "case", "time", "outcome", "site", "exact", "aer_ideal", "aer_noisy", "hardware",
            "hardware_wilson_low", "hardware_wilson_high",
        ])
        for row in rows:
            for i, outcome in enumerate(OUTCOMES):
                measured = counts[row["id"]].get(outcome, 0) if raw.exists() else None
                n = row["hardware"]["shots"] if raw.exists() else None
                writer.writerow([
                    row["id"], row["time"], outcome, SITES[i], row["site_probabilities"][i],
                    row["aer_ideal_site_probabilities"][i], row["aer_noisy"]["site_probabilities"][i],
                    measured / n if n else None, *(wilson(measured, n) if n else (None, None)),
                ])
    plot(out, rows, contrasts)
