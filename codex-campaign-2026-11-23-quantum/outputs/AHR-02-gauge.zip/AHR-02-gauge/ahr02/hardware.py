"""Free Open Plan submission, checkpoint recovery, and count collection."""

import json
from uuid import uuid4

from ahr01.experiment import digest, read_json, timestamp, write_json
from ahr01.hardware import Hold, allocation, select_backend
from qiskit import qpy
from qiskit_ibm_runtime import SamplerV2
from qiskit_ibm_runtime.exceptions import RuntimeJobTimeoutError

from .experiment import OUTCOMES, analyze


def _load(out, quota):
    manifest = read_json(out / "manifest.json")
    if manifest["target_type"] != "live":
        raise Hold("a live calibration and preparation are required")
    if manifest["free_account_check_at_prepare"]["instance_sha256"] != quota["instance_sha256"]:
        raise Hold("the active Open Plan instance does not match the live preparation")
    return manifest


def submit(service, out, *, authorized=False):
    if not authorized:
        raise Hold("hardware submission requires --confirm-free-qpu")
    checkpoint = out / "pilot_job.json"
    if checkpoint.exists():
        raise Hold("a submission checkpoint exists; collect the existing job")
    quota = allocation(service)
    manifest = _load(out, quota)
    estimate = manifest["resource_estimate"]
    if not all(value == "pass" for value in manifest["validation"]["checks"].values()):
        raise Hold("the mathematical validation gate did not pass")
    if not manifest["selection"]["methods"][manifest["selection"]["selected"]]["eligible"]:
        raise Hold("the selected suite did not meet ideal-simulation tolerances")
    budget = estimate["required_remaining_free_seconds"]
    if estimate["unknown_nonvirtual_instruction_durations"] or quota["remaining_qpu_seconds"] < budget:
        raise Hold(f"required budget is {budget}s; verified free balance is {quota['remaining_qpu_seconds']}s")
    calibration = manifest["calibration"]
    backend = select_backend(service, calibration["backend"])
    properties = backend.properties()
    if not properties or properties.last_update_date.isoformat() != calibration["calibration_timestamp"]:
        raise Hold("live calibration changed; prepare a fresh suite")
    if getattr(backend, "calibration_id", None) != calibration["calibration_id"]:
        raise Hold("live calibration ID changed; prepare a fresh suite")

    entry = manifest["qpy"]
    path = out / entry["file"]
    if digest(path) != entry["sha256"]:
        raise Hold("the prepared QPY digest does not match")
    with path.open("rb") as stream:
        circuits = qpy.load(stream)
    shots = estimate["shots_per_circuit"]
    if len(circuits) != len(manifest["ordered_circuits"]) or not 1 <= shots <= 2048:
        raise Hold("the prepared circuit count or shot count does not match")
    if [c.metadata["case_id"] for c in circuits] != manifest["ordered_circuits"]:
        raise Hold("ordered circuit identifiers do not match")
    tag = f"ahr02-pilot-{uuid4().hex[:16]}"
    sampler = SamplerV2(mode=backend, options={
        "max_execution_time": budget,
        "environment": {"job_tags": [tag]},
        "twirling": {"enable_gates": False, "enable_measure": False},
        "dynamical_decoupling": {"enable": False},
    })
    record = {
        "job_id": None, "job_tag": tag, "backend": backend.name,
        "submitted_utc": timestamp(), "max_execution_time_s": budget, "shots_per_circuit": shots,
        "qpy_sha256": entry["sha256"], "free_account_check": quota, "sampler": "client-side SamplerV2/Executor",
    }
    with checkpoint.open("x", encoding="utf-8") as stream:
        json.dump(record, stream, indent=2)
    job = sampler.run(circuits, shots=shots)
    record["job_id"] = job.job_id()
    write_json(checkpoint, record)
    return record


def collect(service, out, wait_seconds=None):
    quota = allocation(service)
    manifest = _load(out, quota)
    checkpoint = out / "pilot_job.json"
    record = read_json(checkpoint)
    if record["qpy_sha256"] != manifest["qpy"]["sha256"]:
        raise Hold("the job checkpoint does not match the live preparation")
    if record["job_id"] is None:
        matches = service.jobs(
            job_tags=[record["job_tag"]], instance=service.active_instance(), limit=2,
        )
        if len(matches) != 1:
            raise Hold("submission outcome unconfirmed; look up the tag in IBM Workloads")
        record["job_id"] = matches[0].job_id()
        write_json(checkpoint, record)
    job = service.job(record["job_id"])
    if wait_seconds and not job.in_final_state():
        try:
            job.wait_for_final_state(timeout=wait_seconds)
        except RuntimeJobTimeoutError:
            pass
    status = job.status()
    report = {"job_id": job.job_id(), "backend": record["backend"], "status": status}
    if status != "DONE":
        return report
    raw = out / "pilot_counts.json"
    if raw.exists():
        archive = read_json(raw)
        counts = archive["counts"]
        retrieved = archive["retrieved_utc"]
    else:
        counts = {
            key: result.data.out.get_counts()
            for key, result in zip(manifest["ordered_circuits"], job.result(), strict=True)
        }
        retrieved = timestamp()
    if set(counts) != set(manifest["ordered_circuits"]) or any(
        not set(counter).issubset(OUTCOMES) or sum(counter.values()) != record["shots_per_circuit"]
        for counter in counts.values()
    ):
        raise Hold("returned shot counts or three-bit outcomes differ from the submitted workload")
    usage = job.usage()
    write_json(raw, {**record, **report, "quantum_seconds": usage, "retrieved_utc": retrieved, "counts": counts})
    write_json(out / "post_run_allocation.json", allocation(service))
    analyze(out)
    return {**report, "quantum_seconds": usage}
