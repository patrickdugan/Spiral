"""Eight-site magnetic cube in little-endian (z y x) order."""

from dataclasses import dataclass
from itertools import combinations
from math import pi

import numpy as np

PRIMES = (2, 3, 5)
SITES = (1, 2, 3, 6, 5, 10, 15, 30)
DETUNINGS = np.log(PRIMES)
DESIGN_TIMES = (0.4, 0.8, 1.0, 1.2, 1.6)
PRIMARY_TIME = 1.5
PILOT_TIMES = (0.8, 1.2, PRIMARY_TIME)
AXES = "xyz"
EDGES = tuple((axis, s) for axis in range(3) for s in range(8) if not s & (1 << axis))
TREE = frozenset({(0, 0), (0, 2), (0, 4), (0, 6), (1, 1), (1, 5), (2, 3)})


@dataclass(frozen=True)
class Setting:
    id: str
    flux: tuple[float, float, float, float]
    gauge_copy: bool = False
    tree: bool = False


SETTINGS = {
    setting.id: setting
    for setting in (
        Setting("zero", (0, 0, 0, 0)),
        Setting("xy", (pi, 0, 0, 0)),
        Setting("xy_xz", (pi, pi / 2, 0, 0)),
        Setting("gradient", (pi, pi / 2, 0, pi / 2)),
        Setting("gauge_copy", (pi, pi / 2, 0, pi / 2), gauge_copy=True),
        Setting("tree_zero", (0, 0, 0, 0), tree=True),
        Setting("tree_gradient", (pi, pi / 2, 0, pi / 2), tree=True),
    )
}


@dataclass(frozen=True)
class Point:
    setting: str
    time: float

    @property
    def id(self):
        return f"{self.setting}_t{self.time:.1f}"


def pilot():
    return (
        [Point(name, time) for time in PILOT_TIMES for name in tuple(SETTINGS)[:4]]
        + [Point(name, PRIMARY_TIME) for name in tuple(SETTINGS)[4:]]
    )


def bits(site):
    return tuple((site >> axis) & 1 for axis in range(3))


def chi(site):
    x, y, z = bits(site)
    return 0.37*x - 0.28*y + 0.23*z + 0.31*x*y - 0.17*x*z + 0.29*y*z + 0.19*x*y*z


def links(setting):
    alpha, beta, gamma, kappa = setting.flux
    result = {}
    for axis, source in EDGES:
        if setting.tree and (axis, source) not in TREE:
            continue
        x, y, _ = bits(source)
        phase = (0, alpha*x, beta*x + gamma*y + kappa*x*y)[axis]
        if setting.gauge_copy:
            phase += chi(source + (1 << axis)) - chi(source)
        result[axis, source] = complex(np.exp(1j * phase))
    return result


def hamiltonian(setting):
    h = np.diag([np.dot(DETUNINGS, bits(s)) for s in range(8)]).astype(complex)
    for (axis, source), value in links(setting).items():
        target = source + (1 << axis)
        h[target, source] = value
        h[source, target] = value.conjugate()
    return h


def unitary(h, time):
    values, vectors = np.linalg.eigh(h)
    return (vectors * np.exp(-1j * time * values)) @ vectors.conj().T


def exact(point):
    return unitary(hamiltonian(SETTINGS[point.setting]), point.time)[:, 0]


def face_products(edges):
    faces = {}
    for first, second in combinations(range(3), 2):
        fixed = 3 - first - second
        for layer in range(2):
            root = layer << fixed
            along_first = edges[first, root] * edges[second, root + (1 << first)]
            along_second = edges[second, root] * edges[first, root + (1 << second)]
            faces[f"{AXES[first]}{AXES[second]}_{AXES[fixed]}{layer}"] = (
                along_first * along_second.conjugate()
            )
    return faces


def expected_face_phases(setting):
    alpha, beta, gamma, kappa = setting.flux
    return dict(zip(
        ("xy_z0", "xy_z1", "xz_y0", "xz_y1", "yz_x0", "yz_x1"),
        (alpha, alpha, beta, beta+kappa, gamma, gamma+kappa), strict=True,
    ))


def tree_vertex_phases(edges):
    neighbors = {s: [] for s in range(8)}
    for (axis, src), value in edges.items():
        dst = src + (1 << axis)
        neighbors[src].append((dst, value))
        neighbors[dst].append((src, value.conjugate()))
    values = {0: 1 + 0j}
    queue = [0]
    for src in queue:
        for dst, link in neighbors[src]:
            if dst not in values:
                values[dst] = values[src] * link
                queue.append(dst)
    if len(values) != 8 or len(edges) != 7:
        raise ValueError("the specified edge set is not a spanning tree")
    return np.array([values[s] for s in range(8)])


def exact_record(point):
    vector = exact(point)
    reduced = {}
    for axis, label in enumerate(AXES):
        index = [s for s in range(8) if not s & (1 << axis)]
        amplitudes = np.stack([vector[index], vector[np.asarray(index) + (1 << axis)]])
        density = amplitudes @ amplitudes.conj().T
        reduced[label] = {"real": density.real.tolist(), "imag": density.imag.tolist()}
    return {
        "id": point.id, "setting": point.setting, "time": point.time,
        "site_probabilities": (abs(vector)**2).tolist(), "single_qubit_reduced_states": reduced,
    }
