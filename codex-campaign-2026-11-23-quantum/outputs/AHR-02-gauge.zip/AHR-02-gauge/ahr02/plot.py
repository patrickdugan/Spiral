"""Return probabilities and paired controls for the cube pilot."""

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from .model import PRIMARY_TIME, Point, exact

COLORS = {"zero": "#285d88", "xy": "#647d36", "xy_xz": "#79539f", "gradient": "#ac4826"}
LABELS = {"zero": "Zero", "xy": "XY", "xy_xz": "XY + XZ", "gradient": "Flux gradient"}


def plot(out, rows, contrasts):
    fig, (curves, pairs) = plt.subplots(
        1, 2, figsize=(10.5, 4), gridspec_kw={"width_ratios": [1.25, 1]}, layout="constrained",
    )
    times = np.linspace(0, 1.6, 161)
    for case, color in COLORS.items():
        curves.plot(times, [abs(exact(Point(case, t))[0])**2 for t in times], color=color,
                    label=LABELS[case])
        for row in (entry for entry in rows if entry["setting"] == case):
            curves.scatter(row["time"], row["aer_noisy"]["p00"], color=color, marker="o", s=22)
            if "hardware" in row:
                p = row["hardware"]["p00"]
                low, high = row["hardware"]["wilson_95"]
                curves.errorbar(row["time"], p, yerr=[[p-low], [high-p]], fmt="s", color=color,
                                capsize=2, markersize=4)
    curves.axvline(PRIMARY_TIME, color="#a3a7a8", linewidth=0.8, linestyle=":")
    curves.set(title="Cube return probabilities", xlabel=r"Time ($\hbar=J=1$)", ylabel=r"$P_{000}$",
               ylim=(-0.025, 1.035))
    curves.legend(frameon=False, fontsize=9)
    keys = ("primary_gradient_minus_zero", "gauge_copy_minus_gradient", "tree_gradient_minus_tree_zero")
    sources = (
        ("exact", "Exact", "#2b3a42", "D", -0.18),
        ("aer_ideal", "Aer ideal", "#7049a3", "+", -0.06),
        ("aer_noisy", "Aer noise", "#346b98", "o", 0.06),
        ("hardware", "IBM QPU", "#ac4826", "s", 0.18),
    )
    for key, label, color, marker, offset in sources:
        for i, name in enumerate(keys):
            row = contrasts[name]
            if key not in row:
                continue
            value = row[key]
            options = {"fmt": marker, "color": color, "markersize": 5, "label": label if i == 0 else None}
            if isinstance(value, dict):
                p = value["delta"]
                low, high = value["newcombe_95"]
                pairs.errorbar(p, i + offset, xerr=[[p-low], [high-p]], capsize=2, **options)
            else:
                pairs.errorbar(value, i + offset, **options)
    pairs.axvline(0, color="#737b84", linewidth=0.8)
    pairs.set(title=r"Paired contrasts at $t=1.5$", xlabel=r"Difference in $P_{000}$",
              yticks=[0, 1, 2], yticklabels=["Gradient − zero", "Gauge copy − original", "Tree flux − zero"])
    pairs.set_ylim(2.55, -0.55)
    pairs.legend(loc="lower right", frameon=False, fontsize=8)
    for axis in (curves, pairs):
        axis.spines[["top", "right"]].set_visible(False)
        axis.grid(axis="y", color="#e9ebee", linewidth=0.7)
        axis.set_axisbelow(True)
    fig.savefig(out / "return_probabilities.png", dpi=200)
    plt.close(fig)
