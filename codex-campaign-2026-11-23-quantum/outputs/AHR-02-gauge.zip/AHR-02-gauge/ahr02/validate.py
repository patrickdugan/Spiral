"""Independent numerical gates for the multi-plaquette experiment."""

from itertools import pairwise, product

import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import Operator, SparsePauliOp

from .circuits import direction_gate, logical
from .model import (
    DESIGN_TIMES,
    DETUNINGS,
    EDGES,
    PRIMARY_TIME,
    SETTINGS,
    TREE,
    Point,
    chi,
    expected_face_phases,
    face_products,
    hamiltonian,
    links,
    tree_vertex_phases,
    unitary,
)

ATOL = 5e-12


def projector_paulis(setting):
    terms = [("III", sum(DETUNINGS) / 2)]
    for axis, value in enumerate(DETUNINGS):
        pauli = ["I"] * 3
        pauli[2-axis] = "Z"
        terms.append(("".join(pauli), -value / 2))
    for (axis, source), value in links(setting).items():
        controls = [i for i in range(3) if i != axis]
        for flags in product((0, 1), repeat=2):
            base = ["I"] * 3
            coeff = 0.25
            for control, flag in zip(controls, flags, strict=True):
                if flag:
                    base[2-control] = "Z"
                    coeff *= (-1)**((source >> control) & 1)
            for letter, component in (("X", value.real), ("Y", value.imag)):
                base[2-axis] = letter
                terms.append(("".join(base), coeff * component))
    return SparsePauliOp.from_list(terms).simplify(atol=1e-14)


def validate():
    assert len(EDGES) - 8 + 1 == 5 and len(TREE) == 7
    zero = hamiltonian(SETTINGS["zero"])
    gradient = hamiltonian(SETTINGS["gradient"])
    tree_zero = hamiltonian(SETTINGS["tree_zero"])
    gauge = np.diag(np.exp(1j * np.array([chi(s) for s in range(8)])))
    tree_links = links(SETTINGS["tree_gradient"])
    tree_gauge = np.diag(tree_vertex_phases(tree_links))
    assert any(abs(link - 1) > ATOL for link in tree_links.values())
    np.testing.assert_allclose(
        hamiltonian(SETTINGS["gauge_copy"]), gauge @ gradient @ gauge.conj().T, atol=ATOL, rtol=0,
    )
    np.testing.assert_allclose(
        hamiltonian(SETTINGS["tree_gradient"]), tree_gauge @ tree_zero @ tree_gauge.conj().T,
        atol=ATOL, rtol=0,
    )
    max_gauge_delta = 0.0
    max_tree_delta = 0.0
    for time in (*DESIGN_TIMES, PRIMARY_TIME):
        locals_xyz = [unitary(np.array([[0, 1], [1, e]]), time) for e in DETUNINGS]
        independent = np.kron(np.kron(locals_xyz[2], locals_xyz[1]), locals_xyz[0])
        np.testing.assert_allclose(unitary(zero, time), independent, atol=ATOL, rtol=0)
        for reference, alternative in (("gradient", "gauge_copy"), ("tree_zero", "tree_gradient")):
            origin, copy = (
                abs(unitary(hamiltonian(SETTINGS[case]), time))**2
                for case in (reference, alternative)
            )
            residual = float(np.max(abs(origin - copy)))
            if reference == "gradient":
                max_gauge_delta = max(max_gauge_delta, residual)
            else:
                max_tree_delta = max(max_tree_delta, residual)
            np.testing.assert_allclose(origin, copy, atol=ATOL, rtol=0)

    for setting in SETTINGS.values():
        h = hamiltonian(setting)
        np.testing.assert_allclose(h, h.conj().T, atol=ATOL, rtol=0)
        np.testing.assert_allclose(projector_paulis(setting).to_matrix(), h, atol=ATOL, rtol=0)
        base = Point(setting.id, 0.83)
        np.testing.assert_allclose(
            Operator(logical(base, "exact")).data, unitary(h, base.time), atol=ATOL, rtol=0,
        )
        edges = links(setting)
        for axis in range(3):
            offaxis = np.zeros_like(h)
            for source in range(8):
                other = source ^ (1 << axis)
                offaxis[other, source] = h[other, source]
            gate, args = direction_gate(edges, axis, 0.33)
            circuit = QuantumCircuit(3)
            circuit.append(gate, args)
            np.testing.assert_allclose(
                Operator(circuit).data, unitary(offaxis, 0.33), atol=ATOL, rtol=0,
            )
        if not setting.tree:
            products = face_products(edges)
            for face, phase in expected_face_phases(setting).items():
                np.testing.assert_allclose(products[face], np.exp(1j * phase), atol=ATOL, rtol=0)
            boundary = (
                products["xy_z1"] * products["xy_z0"].conjugate()
                * products["yz_x1"] * products["yz_x0"].conjugate()
                * products["xz_y0"] * products["xz_y1"].conjugate()
            )
            np.testing.assert_allclose(boundary, 1, atol=ATOL, rtol=0)
            observed = (np.linalg.matrix_power(h, 4)[0, 0] - np.linalg.matrix_power(zero, 4)[0, 0]) / 12
            expected = sum(products[key].real - 1 for key in ("xy_z0", "xz_y0", "yz_x0")) / 6
            np.testing.assert_allclose(observed, expected, atol=ATOL, rtol=0)

    test_point = Point("gradient", 0.8)
    exact_cube = unitary(gradient, test_point.time)
    errors = [
        float(np.linalg.norm(Operator(logical(test_point, f"strang_{steps}")).data - exact_cube))
        for steps in (2, 4, 8)
    ]
    ratios = [first / second for first, second in pairwise(errors)]
    assert all(3.5 < ratio < 4.5 for ratio in ratios)
    return {
        "checks": dict.fromkeys((
            "hermiticity", "independent_little_endian_pauli_projectors",
            "all_six_face_holonomies", "oriented_cube_boundary_identity",
            "five_cycle_ranks", "corner_return_t4_coefficient",
            "zero_flux_full_operator_factorization",
            "gauge_copy_full_operator_and_all_site_probabilities",
            "tree_full_operator_and_all_site_probabilities",
            "exact_synthesis_full_operator", "controlled_links_full_operator",
            "strang_second_order_convergence",
        ), "pass"),
        "max_gauge_copy_probability_residual": max_gauge_delta,
        "max_tree_probability_residual": max_tree_delta,
        "gradient_strang_error_ratios_at_t0_8": ratios,
    }
