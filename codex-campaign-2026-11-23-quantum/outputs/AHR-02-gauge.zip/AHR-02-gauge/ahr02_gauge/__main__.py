"""Local validation and opt-in IBM CLI for the gauge follow-up."""

import argparse
import json
import logging
from pathlib import Path

from ahr01.hardware import Hold, allocation, open_service, select_backend
from ahr02.hardware import submit

from .experiment import prepare
from .hardware import collect
from .matched import validate_matched


def main(argv=None):
    parser = argparse.ArgumentParser(prog="python -m ahr02_gauge")
    commands = parser.add_subparsers(dest="action", required=True)
    commands.add_parser("validate")
    prep = commands.add_parser("prepare")
    prep.add_argument("--out", type=Path, required=True)
    prep.add_argument("--baseline", type=Path)
    prep.add_argument("--live", action="store_true")
    prep.add_argument("--backend", default="ibm_kingston")
    send = commands.add_parser("submit")
    send.add_argument("--run", type=Path, required=True)
    send.add_argument("--confirm-free-qpu", action="store_true", required=True)
    fetch = commands.add_parser("collect")
    fetch.add_argument("--run", type=Path, required=True)
    fetch.add_argument("--wait", type=int, choices=range(1, 61), metavar="1-60")
    for command in (prep, send, fetch):
        command.add_argument("--token-file", type=Path)
        command.add_argument("--instance")
    args = parser.parse_args(argv)
    logging.getLogger("qiskit_ibm_runtime").setLevel(logging.CRITICAL)
    logging.getLogger("ibm_cloud_sdk_core").setLevel(logging.CRITICAL)
    try:
        if args.action == "validate":
            result = validate_matched()
        elif args.action == "prepare":
            if args.out.exists() and any(args.out.iterdir()):
                parser.error("--out must be new or empty")
            quota = None
            if args.live:
                service = open_service(args.token_file, args.instance)
                quota = allocation(service)
                backend = select_backend(service, args.backend)
            else:
                from qiskit_ibm_runtime.fake_provider import FakeKingston

                backend = FakeKingston()
            result = prepare(backend, args.out, quota=quota, baseline=args.baseline)
        elif args.action == "submit":
            service = open_service(args.token_file, args.instance)
            result = submit(service, args.run, authorized=args.confirm_free_qpu)
        else:
            service = open_service(args.token_file, args.instance)
            result = collect(service, args.run, args.wait)
    except Hold as exc:
        print(f"HOLD — {exc}")
        return 2
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
