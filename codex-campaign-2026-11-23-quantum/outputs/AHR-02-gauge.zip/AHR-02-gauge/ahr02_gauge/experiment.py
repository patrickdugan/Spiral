"""Simulate the legacy and matched circuits, then analyze the balanced rerun."""

import csv
from collections import Counter
from importlib.metadata import version
from pathlib import Path

import numpy as np
from ahr01.circuits import aer_noisy_counts
from ahr01.experiment import digest, read_json, resource_estimate, timestamp, write_json
from ahr01.statistics import difference, wilson
from ahr02.circuits import (
    compile_pilot,
    ideal_probabilities,
    measurements,
    select_patch,
)
from ahr02.experiment import OUTCOMES, gradient_outcomes
from ahr02.model import PRIMARY_TIME, SITES, Point, exact
from qiskit import qpy

from .matched import (
    ARMS,
    BLOCK_ORDERS,
    circuit_for,
    instruction_key,
    signature,
    validate_matched,
)

SHOTS = 2048
SIM_SHOTS = 65536
EQUIVALENCE_MARGIN = 0.02
MASS = [OUTCOMES[i] for i in gradient_outcomes()]
CONTRASTS = {
    "gauge_return": ("gauge_copy", "gradient", ["000"]),
    "incremental_gradient_mass": ("gradient", "xy_xz", MASS),
    "incremental_gradient_return": ("gradient", "xy_xz", ["000"]),
    "identical_repeat_return": ("gradient_repeat", "gradient", ["000"]),
}


def _count_summary(counts, selection):
    successes = sum(counts.get(outcome, 0) for outcome in selection)
    shots = sum(counts.values())
    return {"p00": successes / shots, "wilson_95": wilson(successes, shots)}


def all_contrasts(counts):
    return {
        key: difference(_count_summary(counts[positive], outcomes), _count_summary(counts[reference], outcomes))
        for key, (positive, reference, outcomes) in CONTRASTS.items()
        if positive in counts and reference in counts
    }


def _ideal_differences(probabilities):
    return {
        key: float(sum(probabilities[a][int(outcome, 2)] - probabilities[b][int(outcome, 2)]
                       for outcome in outcomes))
        for key, (a, b, outcomes) in CONTRASTS.items() if a in probabilities and b in probabilities
    }


def circuit_metrics(circuit, backend, patch):
    duration = 0.0
    missing = set()
    counts = Counter()
    for name, qargs, _ in instruction_key(circuit):
        if not set(qargs).issubset(patch) or not backend.target.instruction_supported(
            operation_name=name, qargs=qargs,
        ):
            raise ValueError(f"{name} on {qargs} is outside the calibrated ISA patch")
        counts[name] += 1
        prop = backend.target[name].get(qargs)
        if prop is not None and prop.duration is not None:
            duration += prop.duration
        elif name != "rz":
            missing.add(name)
    if measurements(circuit) != (patch[1], patch[2], patch[0]):
        raise ValueError("native state preparation measured the wrong logical wires")
    return {
        "id": circuit.metadata["case_id"], "arm": circuit.metadata["arm"], "block": circuit.metadata["block"],
        "depth": circuit.depth(), "native_counts": dict(counts), "serial_gate_measure_duration_s": duration,
        "missing_timing": sorted(missing), "skeleton_sha256": signature(circuit),
        "physical_measurement_xyz": measurements(circuit),
    }


def _simulation(circuits, arms, backend, targets):
    ideal = dict(zip(arms, ideal_probabilities(circuits), strict=True))
    error = float(max(np.max(abs(targets[arm]-p)) for arm, p in ideal.items()))
    if error > 1e-8:
        raise ValueError(f"compiled ideal site distribution failed the 1e-8 gate ({error})")
    counts = dict(zip(arms, aer_noisy_counts(circuits, backend, SIM_SHOTS), strict=True))
    return {
        "max_absolute_site_error": error, "ideal": {arm: p.tolist() for arm, p in ideal.items()},
        "noisy_counts": counts, "ideal_contrasts": _ideal_differences(ideal),
        "noisy_contrasts": all_contrasts(counts),
    }


def prepare(backend, out, *, quota=None, baseline=None):
    checks = validate_matched()
    patch, reduced, calibration = select_patch(backend)
    if "cz" not in backend.target:
        raise ValueError("the matched native scaffold requires an adjacent CZ target")
    allowed = {where for where in backend.target["cz"] if where and set(where).issubset(patch)}
    circuits = [
        circuit_for(arm, patch, backend.num_qubits, allowed, block=number)[0]
        for number, order in enumerate(BLOCK_ORDERS, 1) for arm in order
    ]
    metrics = [circuit_metrics(circuit, backend, patch) for circuit in circuits]
    if len({row["skeleton_sha256"] for row in metrics}) != 1:
        raise ValueError("hardware circuits do not share one ordered native skeleton")
    representatives = {arm: next(c for c in circuits if c.metadata["arm"] == arm) for arm in ARMS}
    if instruction_key(representatives["gradient"], parameters=True) != instruction_key(
        representatives["gradient_repeat"], parameters=True,
    ):
        raise ValueError("gradient repeat is not instruction-identical")
    targets = {arm: abs(exact(Point(arm if arm != "gradient_repeat" else "gradient", PRIMARY_TIME)))**2
               for arm in ARMS}
    matched = _simulation(list(representatives.values()), ARMS, backend, targets)
    basis_arms = ARMS[:3]
    legacy = compile_pilot(backend, patch, reduced, [Point(arm, PRIMARY_TIME) for arm in basis_arms], "exact")
    legacy_circuits = [circuit for circuit, _ in legacy]
    old = _simulation(legacy_circuits, basis_arms, backend, targets)
    old["metrics"] = {
        arm: {**row, "skeleton_sha256": signature(circuit)}
        for arm, (circuit, row) in zip(basis_arms, legacy, strict=True)
    }
    out.mkdir(parents=True, exist_ok=True)
    qpy_path = out / "pilot.qpy"
    with qpy_path.open("wb") as stream:
        qpy.dump(circuits, stream)
    manifests = {
        "experiment": "AHR-02-gauge", "schema": 1, "prepared_utc": timestamp(),
        "target_type": "live" if quota else "archived_snapshot", "free_account_check_at_prepare": quota,
        "calibration": calibration, "validation": checks,
        "matched_wiring": {
            "initial_physical_xyz": (patch[2], patch[1], patch[0]),
            "final_measurement_physical_xyz": metrics[0]["physical_measurement_xyz"],
        },
        "selection": {"selected": "matched_complex_state", "methods": {"matched_complex_state": {
            "max_absolute_site_error": matched["max_absolute_site_error"], "eligible": True,
        }}},
        "resource_estimate": resource_estimate(metrics, SHOTS),
        "ordered_circuits": [c.metadata["case_id"] for c in circuits],
        "qpy": {"file": qpy_path.name, "sha256": digest(qpy_path)},
        "native_skeleton_sha256": metrics[0]["skeleton_sha256"],
        "block_orders": BLOCK_ORDERS, "time": PRIMARY_TIME, "fixed_mass_outcomes": MASS,
        "equivalence_margin": EQUIVALENCE_MARGIN, "simulation_shots_per_arm": SIM_SHOTS,
        "packages": {package: version(package) for package in ("qiskit", "qiskit-aer", "qiskit-ibm-runtime", "numpy")},
    }
    comparisons = {
        "mathematical": _ideal_differences(targets), "matched": matched,
        "legacy_recompiled": old, "matched_circuit_metrics": metrics,
    }
    if baseline:
        old_counts = read_json(baseline / "pilot_counts.json")
        previous = read_json(baseline / "contrasts.json")
        assert previous["secondary_gradient_fixed_site_mass"]["outcomes"] == MASS
        comparisons["previous_hardware"] = {
            "job_id": old_counts["job_id"], "backend": old_counts["backend"],
            "calibration": read_json(baseline / "manifest.json")["calibration"],
            "gauge_return": previous["gauge_copy_minus_gradient"]["hardware"],
            "incremental_gradient_mass": previous["secondary_gradient_fixed_site_mass"]["hardware"],
            "incremental_gradient_return": previous["gradient_minus_xy_xz"]["hardware"],
        }
    write_json(out / "manifest.json", manifests)
    write_json(out / "simulation.json", comparisons)
    analyze(out)
    return manifests


def analyze(out: Path):
    simulation = read_json(out / "simulation.json")
    count_file = out / "pilot_counts.json"
    if not count_file.exists():
        return
    raw = read_json(count_file)["counts"]
    by_block = {
        str(block): {arm: raw[f"{arm}_b{block}"] for arm in ARMS}
        for block in range(1, len(BLOCK_ORDERS) + 1)
    }
    aggregate = {arm: Counter() for arm in ARMS}
    for rows in by_block.values():
        for arm, counts in rows.items():
            aggregate[arm].update(counts)
    pooled = all_contrasts(aggregate)
    lo, hi = pooled["gauge_return"]["newcombe_95"]
    write_json(out / "observations.json", {
        "exact_contrasts": simulation["mathematical"], "pooled_counts": aggregate,
        "pooled_contrasts": pooled, "per_block_contrasts": {
            block: all_contrasts(rows) for block, rows in by_block.items()
        },
        "gauge_return_equivalence_margin": EQUIVALENCE_MARGIN,
        "gauge_return_interval_inside_margin": -EQUIVALENCE_MARGIN <= lo and hi <= EQUIVALENCE_MARGIN,
    })
    with (out / "site_probabilities.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["arm", "outcome", "site", "ideal", "matched_aer", "qpu", "qpu_low", "qpu_high"])
        for arm, counts in aggregate.items():
            model = simulation["matched"]
            noisy_total = sum(model["noisy_counts"][arm].values())
            for i, outcome in enumerate(OUTCOMES):
                summary = _count_summary(counts, [outcome])
                writer.writerow([
                    arm, outcome, SITES[i], model["ideal"][arm][i],
                    model["noisy_counts"][arm].get(outcome, 0) / noisy_total,
                    summary["p00"], *summary["wilson_95"],
                ])
    from .plot import plot

    plot(out, simulation, pooled, EQUIVALENCE_MARGIN)
