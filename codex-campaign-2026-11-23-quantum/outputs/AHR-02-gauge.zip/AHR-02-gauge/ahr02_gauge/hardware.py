"""Collect the follow-up counts with the shared Open Plan safeguards."""

from ahr01.experiment import read_json, timestamp, write_json
from ahr01.hardware import Hold, allocation
from ahr02.experiment import OUTCOMES
from ahr02.hardware import _load
from qiskit_ibm_runtime.exceptions import RuntimeJobTimeoutError

from .experiment import analyze


def collect(service, out, wait_seconds=None):
    manifest = _load(out, allocation(service))
    checkpoint = out / "pilot_job.json"
    submitted = read_json(checkpoint)
    if manifest["qpy"]["sha256"] != submitted["qpy_sha256"]:
        raise Hold("the submitted gauge workload and manifest digests differ")
    if not submitted["job_id"]:
        matches = service.jobs(job_tags=[submitted["job_tag"]], instance=service.active_instance(), limit=2)
        if len(matches) != 1:
            raise Hold("the submitted workload has no verified job ID; locate its existing tag")
        submitted["job_id"] = matches[0].job_id()
        write_json(checkpoint, submitted)
    job = service.job(submitted["job_id"])
    if wait_seconds and not job.in_final_state():
        try:
            job.wait_for_final_state(timeout=wait_seconds)
        except RuntimeJobTimeoutError:
            pass
    report = {"job_id": job.job_id(), "backend": submitted["backend"], "status": job.status()}
    if report["status"] != "DONE":
        return report
    record = out / "pilot_counts.json"
    if record.exists():
        archived = read_json(record)
        counts = archived["counts"]
        retrieved = archived["retrieved_utc"]
    else:
        counts = {key: item.data.out.get_counts()
                  for key, item in zip(manifest["ordered_circuits"], job.result(), strict=True)}
        retrieved = timestamp()
    if set(counts) != set(manifest["ordered_circuits"]) or any(
        not set(counter).issubset(OUTCOMES) or sum(counter.values()) != submitted["shots_per_circuit"]
        for counter in counts.values()
    ):
        raise Hold("returned counts do not match the workload")
    usage = job.usage()
    write_json(record, {
        **submitted, **report, "quantum_seconds": usage, "retrieved_utc": retrieved, "counts": counts,
    })
    write_json(out / "post_run_allocation.json", allocation(service))
    analyze(out)
    return {**report, "quantum_seconds": usage}
