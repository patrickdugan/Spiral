"""Fixed native state preparation for the original |000> experiment."""

import json
from collections import deque
from hashlib import sha256
from math import pi

import numpy as np
from ahr02.model import PRIMARY_TIME, Point, chi, exact
from qiskit import ClassicalRegister, QuantumCircuit
from qiskit.quantum_info import Statevector

ARMS = ("gradient", "gauge_copy", "xy_xz", "gradient_repeat")
BLOCK_ORDERS = (
    ("gradient", "gauge_copy", "gradient_repeat", "xy_xz"),
    ("gauge_copy", "xy_xz", "gradient", "gradient_repeat"),
    ("xy_xz", "gradient_repeat", "gauge_copy", "gradient"),
    ("gradient_repeat", "gradient", "xy_xz", "gauge_copy"),
)
INITIAL_PARITIES = (4, 1, 2)  # final compact wires carry logical z, x, y
NEIGHBOR_CX = ((0, 1), (1, 0), (1, 2), (2, 1))


def parity_schedule():
    """Visit all seven binary parities with nearest-neighbor CX and undo the wire transform."""
    initial_seen = sum(1 << mask for mask in INITIAL_PARITIES)
    start = (INITIAL_PARITIES, initial_seen)
    seen = {start}
    queue = deque([(start, ())])
    while queue:
        (parities, visited), path = queue.popleft()
        if parities == INITIAL_PARITIES and visited == 254:
            return path
        for control, target in NEIGHBOR_CX:
            masks = list(parities)
            masks[target] ^= masks[control]
            move = (tuple(masks), visited | (1 << masks[target]))
            if move not in seen:
                seen.add(move)
                queue.append((move, (*path, (control, target))))
    raise RuntimeError("no reversible nearest-neighbor parity schedule")


def _angle(value):
    return float((value + pi) % (2 * pi) - pi)


def _hadamard(circuit, qubit):
    circuit.rz(pi/2, qubit)
    circuit.sx(qubit)
    circuit.rz(pi/2, qubit)


def _cx(circuit, control, target, allowed):
    _hadamard(circuit, target)
    edge = (control, target) if (control, target) in allowed else (target, control)
    if edge not in allowed:
        raise ValueError("fixed template found no required adjacent CZ")
    circuit.cz(*edge)
    _hadamard(circuit, target)


def _ry(circuit, theta, qubit):
    circuit.sx(qubit)
    circuit.rz(_angle(theta + pi), qubit)
    circuit.sx(qubit)
    circuit.rz(pi, qubit)


def _multiplexed_ry(circuit, angles, target, controls, allowed):
    count = len(angles)
    codes = [i ^ (i >> 1) for i in range(count)]
    for i, gray in enumerate(codes):
        theta = sum(angle * (-1)**((mask & gray).bit_count()) for mask, angle in enumerate(angles)) / count
        _ry(circuit, theta, target)
        if controls:
            changed = gray ^ codes[(i + 1) % count]
            _cx(circuit, controls[changed.bit_length()-1], target, allowed)


def _split_angles(weights):
    pairs = np.asarray(weights).reshape(-1, 2)
    return np.arctan2(np.sqrt(pairs[:, 1]), np.sqrt(pairs[:, 0])) * 2


def _amplitudes(arm):
    if arm == "gauge_copy":
        reference = exact(Point("gradient", PRIMARY_TIME))
        vector = reference * np.exp(1j * np.array([chi(site) for site in range(8)]))
        return abs(reference)**2, np.angle(vector)
    model = "gradient" if arm == "gradient_repeat" else arm
    vector = exact(Point(model, PRIMARY_TIME))
    return abs(vector)**2, np.angle(vector)


def _diagonal(circuit, phases, patch, allowed):
    coefficients = {
        mask: sum(phase * (-1)**((s & mask).bit_count()) for s, phase in enumerate(phases)) / 8
        for mask in range(1, 8)
    }
    masks = list(INITIAL_PARITIES)
    emitted = set()

    def rotate(index):
        if masks[index] not in emitted:
            circuit.rz(_angle(-2 * coefficients[masks[index]]), patch[index])
            emitted.add(masks[index])

    for index in range(3):
        rotate(index)
    for control, target in parity_schedule():
        _cx(circuit, patch[control], patch[target], allowed)
        masks[target] ^= masks[control]
        rotate(target)
    if tuple(masks) != INITIAL_PARITIES or len(emitted) != 7:
        raise RuntimeError("the phase scaffold did not cover all parities and return to identity")


def circuit_for(arm, patch, width, allowed, *, block=None):
    z, old_y, old_x = patch
    # The two-CX move acts while old_x is still in |0>.
    x, y = old_y, old_x
    weights, phases = _amplitudes(arm)
    circuit = QuantumCircuit(width, name=arm if block is None else f"{arm}_b{block}")
    circuit.metadata = {"case_id": circuit.name, "arm": arm, "block": block or 0}
    _multiplexed_ry(circuit, _split_angles(weights.reshape(2, 4).sum(axis=1)), z, [], allowed)
    _multiplexed_ry(circuit, _split_angles(weights.reshape(4, 2).sum(axis=1)), old_y, [z], allowed)
    _cx(circuit, old_y, old_x, allowed)
    _cx(circuit, old_x, old_y, allowed)
    _multiplexed_ry(circuit, _split_angles(weights), x, [y, z], allowed)
    phase_start = len(circuit.data)
    _diagonal(circuit, phases, patch, allowed)
    if block is not None:
        circuit.add_register(ClassicalRegister(3, "out"))
        circuit.measure([x, y, z], [0, 1, 2])
    return circuit, phase_start


def instruction_key(circuit, *, parameters=False):
    return tuple(
        (item.operation.name, tuple(circuit.find_bit(bit).index for bit in item.qubits),
         tuple(float(value) for value in item.operation.params) if parameters else ())
        for item in circuit.data
    )


def signature(circuit):
    encoded = json.dumps(instruction_key(circuit), separators=(",", ":")).encode()
    return sha256(encoded).hexdigest()


def validate_matched():
    patch = (0, 1, 2)
    allowed = set(NEIGHBOR_CX)
    circuits = {}
    for arm in ARMS:
        circuit, phase_start = circuit_for(arm, patch, 3, allowed)
        physical_order = Statevector.from_instruction(circuit).data
        permutations = [(((logical >> 2) & 1) | ((logical & 1) << 1) | (logical & 2) << 1)
                        for logical in range(8)]
        actual = Statevector(physical_order[permutations])
        setting = "gradient" if arm == "gradient_repeat" else arm
        if not actual.equiv(Statevector(exact(Point(setting, PRIMARY_TIME))), atol=1e-10):
            raise AssertionError(f"{arm} does not reproduce the full complex target state")
        circuits[arm] = instruction_key(circuit, parameters=True)
    reference, gauge = circuits["gradient"], circuits["gauge_copy"]
    assert reference == circuits["gradient_repeat"]
    assert reference[:phase_start] == gauge[:phase_start]
    differences = [i for i, (left, right) in enumerate(zip(reference, gauge, strict=True)) if left != right]
    assert differences and all(i >= phase_start and reference[i][0] == "rz" for i in differences)
    assert all(tuple(gate[:2] for gate in arm) == tuple(gate[:2] for gate in reference)
               for arm in circuits.values())
    assert all(sorted(block) == sorted(ARMS) for block in BLOCK_ORDERS)
    assert all({row[slot] for row in BLOCK_ORDERS} == set(ARMS) for slot in range(4))
    return {
        "checks": dict.fromkeys((
            "all_complex_states_from_000", "native_skeleton_identical", "gauge_amplitude_prefix_identical",
            "gauge_changes_only_final_virtual_z_angles", "null_native_instructions_identical",
            "four_position_balanced_blocks",
        ), "pass"),
        "parity_network_cx": len(parity_schedule()), "gauge_virtual_angle_differences": len(differences),
        "amplitude_prefix_instructions": phase_start,
    }
