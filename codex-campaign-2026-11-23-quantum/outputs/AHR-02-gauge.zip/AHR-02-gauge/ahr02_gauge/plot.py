"""Compare the original circuit results and the matched rerun."""

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def plot(out, simulation, observed, margin):
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8), layout="constrained")
    for axis, key, title in zip(
        axes, ("gauge_return", "incremental_gradient_mass"),
        ("Gauge-copy return shift", "Incremental gradient site-mass shift"), strict=True,
    ):
        points = [
            ("Legacy Aer", simulation["legacy_recompiled"]["noisy_contrasts"][key], "#78689b"),
            ("Matched Aer", simulation["matched"]["noisy_contrasts"][key], "#34728d"),
        ]
        if "previous_hardware" in simulation:
            points.append(("Original IBM pilot", simulation["previous_hardware"][key], "#88673c"))
        points.append(("Matched IBM rerun", observed[key], "#a74425"))
        if key == "gauge_return":
            axis.axvspan(-margin, margin, alpha=0.10, color="#227257", label=f"±{margin:.2f} gauge margin")
            points.append(("Identical IBM repeat", observed["identical_repeat_return"], "#64745d"))
        for index, (_, value, color) in enumerate(points):
            center = value["delta"]
            low, high = value["newcombe_95"]
            axis.errorbar(center, index, xerr=[[center-low], [high-center]], fmt="o", color=color,
                          markersize=5, capsize=3)
        ideal = simulation["mathematical"][key]
        axis.axvline(ideal, color="#232a33", linestyle="--", linewidth=0.9, label="Ideal prediction")
        if abs(ideal) > 1e-10:
            axis.axvline(0, color="#969a9f", linewidth=0.8)
        axis.set(title=title, yticks=range(len(points)), yticklabels=[row[0] for row in points],
                 xlabel="Probability difference with 95% interval")
        axis.set_ylim(len(points)-0.5, -0.5)
        axis.spines[["top", "right"]].set_visible(False)
        axis.grid(axis="x", alpha=0.25)
        axis.legend(loc="lower right", frameon=False, fontsize=8)
    fig.savefig(out / "matched_contrasts.png", dpi=200)
    plt.close(fig)
