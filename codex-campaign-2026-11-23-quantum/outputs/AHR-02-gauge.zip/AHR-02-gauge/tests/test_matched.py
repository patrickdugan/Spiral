import numpy as np
from ahr02.circuits import measurements
from ahr02_gauge.experiment import MASS, all_contrasts
from ahr02_gauge.matched import (
    ARMS,
    NEIGHBOR_CX,
    circuit_for,
    instruction_key,
    validate_matched,
)


def test_complex_states_and_fixed_skeleton():
    assert all(status == "pass" for status in validate_matched()["checks"].values())


def test_measurements_and_identity_repeat():
    patch = (3, 4, 5)
    links = {(patch[a], patch[b]) for a, b in NEIGHBOR_CX}
    circuits = {arm: circuit_for(arm, patch, 7, links, block=1)[0] for arm in ARMS}
    assert all(measurements(circuit) == (4, 5, 3) for circuit in circuits.values())
    assert instruction_key(circuits["gradient"], parameters=True) == instruction_key(
        circuits["gradient_repeat"], parameters=True,
    )


def test_frozen_outcomes_and_contrasts():
    assert MASS == ["000", "010", "011", "100", "101", "110"]
    counts = {
        "gradient": {"000": 4, "010": 2, "111": 4},
        "gradient_repeat": {"000": 4, "010": 2, "111": 4},
        "gauge_copy": {"000": 5, "010": 1, "111": 4},
        "xy_xz": {"000": 4, "111": 6},
    }
    contrasts = all_contrasts(counts)
    np.testing.assert_allclose(
        [contrasts[key]["delta"] for key in ("gauge_return", "incremental_gradient_mass", "identical_repeat_return")],
        [0.1, 0.2, 0.0], atol=1e-14,
    )
