# AHR-02 · Interleaved gauge comparison

The earlier AHR-02 pilots measured a positive gauge-copy shift with independently synthesized full-unitary circuits and with matched state preparation. Those jobs used different calibrations and logical readout maps. This run places both gauge pairs in one IBM workload on physical qubits 38, 49 and 48 and enforces a single readout map.

- [Results and interpretation](REPORT.md)
- [Simulation and hardware contrasts](results/interleaved_contrasts.png) · [Pooled and block estimates](results/observations.json)
- [Calibration and submitted order](results/manifest.json) · [IBM chunk timing and job calibration](results/execution_evidence.json)
- [Raw IBM counts](results/pilot_counts.json) · [Aer ideal and calibrated noise simulation](results/simulation.json)

## Design

The four arms at $t=1.5$ are the legacy gradient, legacy gauge copy, matched gradient, and matched gauge copy. The legacy arms use independent synthesis of the full time-evolution operators. The matched arms prepare the exact complex target states from $|000\rangle$ on a common native skeleton. They have identical magnitude-preparation instructions and differ only in the terminal virtual $R_z$ angles. All four ideal site distributions are checked after assigning the common readout.

The legacy gradient's final logical readout defines the common map. The legacy gauge copy receives an adjacent-SWAP alignment when its routing gives a different final mapping. For the matched pair, the magnitude and phase tables are permuted to that map before gate synthesis. This preserves the matched native skeleton without adding swaps. The final circuit measurements in every arm use the same physical qubits for each of the output bits $x,y,z$.

Eight blocks each contain all four arms at 2,048 shots per circuit. Legacy and matched circuits alternate inside each block, and each arm occupies each position twice across the job. The manifest records the submission order. The execution evidence records IBM's reported chunk membership and timestamps. Those records resolve execution at the chunk level. [IBM Sampler metadata](https://quantum.cloud.ibm.com/docs/en/ibm-quantum-compute/sampler-input-output)

Within each family, the gauge shift is $P_{000}(\mathrm{copy})-P_{000}(\mathrm{gradient})$. The primary comparison subtracts the legacy gauge shift from the matched gauge shift. The pooled 95% interval for this interaction uses the independent-binomial Wald variance across the four arms. The block-based Student interval treats each block's four-arm contrast as one observation. The paired gauge shifts use Newcombe intervals. The matched gauge interval is also checked against the inherited ±0.02 equivalence margin. All intervals are marginal.

## Reproduce

Use Python 3.12 with the pinned requirements. The ZIP includes the AHR-01, AHR-02 and gauge-follow-up Python modules. In the source checkout, add the adjacent directories to the import path. On PowerShell, run the following from this directory.

~~~powershell
$env:PYTHONPATH = @((Resolve-Path ../AHR-01).Path, (Resolve-Path ../AHR-02).Path, (Resolve-Path ../AHR-02-gauge).Path) -join ';'
~~~

~~~shell
python -m pip install -r requirements.txt
python -m ahr02_interleaved validate
python -m pytest -q
python -m ahr02_interleaved prepare --out runs/archived
~~~

For the live job, pass a local IBM key path or use a previously saved default Qiskit account. Preparation uses one live calibration for both circuit families and simulates them before submission. The submit command refreshes the free balance, checks that the calibration still matches and applies the QPU execution cap. Collection records the backend properties at job start and checks the historical calibration at the last published chunk. [IBM workload usage](https://quantum.cloud.ibm.com/docs/en/ibm-quantum-compute/estimate-job-run-time)

~~~shell
python -m ahr02_interleaved prepare --live --out runs/live --token-file PATH_TO_KEY
python -m ahr02_interleaved submit --run runs/live --confirm-free-qpu --token-file PATH_TO_KEY
python -m ahr02_interleaved collect --run runs/live --wait 45 --token-file PATH_TO_KEY
~~~
