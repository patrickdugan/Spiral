# AHR-02 · Interleaved legacy and matched gauge pairs

IBM job **dc1tdfds2omc738b3qo0** completed on **ibm_kingston**. Results were collected at 2026-11-23 14:02:09 SGT. Both pairs used physical qubits 38, 49 and 48, with logical $x,y,z$ read out on 38, 49 and 48 respectively. IBM returned the same calibration snapshot used for simulation at job start and at the last chunk, dated 2026-11-23 13:42:06 SGT.

Under these shared conditions, the matched gauge shift was **-0.01892** relative to the legacy shift, with 95% interval **[-0.03245, -0.00539]**. The block-based 95% interval was **[-0.03139, -0.00646]**.

| Contrast at $t=1.5$ | Ideal | Calibrated Aer | Aer 95% interval | IBM QPU | IBM 95% interval |
| --- | ---: | ---: | --- | ---: | --- |
| Legacy gauge copy − gradient | 0.00000 | +0.00952 | [+0.00479, +0.01425] | +0.01770 | [+0.00822, +0.02717] |
| Matched gauge copy − gradient | 0.00000 | +0.00002 | [-0.00477, +0.00480] | -0.00122 | [-0.01088, +0.00844] |
| Matched gauge shift − legacy gauge shift | 0.00000 | -0.00951 | [-0.01624, -0.00277] | -0.01892 | [-0.03245, -0.00539] |

The matched gauge interval includes zero and meets the ±0.02 equivalence criterion. The legacy gauge interval lies above zero. The same-job comparison isolates the circuit implementation as a factor under the shared patch, readout and calibration. The families differ in synthesis, gate count and state-preparation scope, so the microscopic mechanism of the residual legacy shift remains unresolved.

## Circuit and execution evidence

The ideal Aer simulations agree with the full eight-outcome reference for every circuit. The worst absolute site error was 7.39e-14. Each calibrated-noise estimate used 65,536 shots per arm.

| Arm | Depth | CZ gates | Readout-alignment SWAPs | Hardware $P_{000}$ |
| --- | ---: | ---: | ---: | ---: |
| legacy gradient | 125 | 31 | 0 | 0.24933 |
| legacy copy | 126 | 31 | 0 | 0.26703 |
| matched gradient | 112 | 16 | 0 | 0.27490 |
| matched copy | 112 | 16 | 0 | 0.27368 |

The single submitted job used 8 position-balanced four-circuit blocks and 2,048 shots per circuit. IBM returned all 32 PUB identifiers in the submitted sequence within 1 execution chunk. The published timestamps are at chunk resolution. The archived QPY and execution evidence provide the circuit order and IBM's chunk record. [IBM Sampler metadata](https://quantum.cloud.ibm.com/docs/en/ibm-quantum-compute/sampler-input-output)

IBM recorded **20 s** of QPU use. The verified Open Plan balance was 556 s before submission and **536 s** after the job. The execution cap was 94 s.

- [Contrast figure](results/interleaved_contrasts.png) · [Block and pooled estimates](results/observations.json)
- [Raw counts](results/pilot_counts.json) · [Cloud execution evidence](results/execution_evidence.json)
- [Simulation data](results/simulation.json) · [Reproducibility manifest](results/manifest.json) · [Pilot circuits](results/pilot.qpy)
