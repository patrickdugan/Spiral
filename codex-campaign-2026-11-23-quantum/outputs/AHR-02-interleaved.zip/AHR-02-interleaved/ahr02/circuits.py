"""Exact and directional Suzuki–Trotter synthesis on a three-qubit patch."""

from collections import Counter
from itertools import combinations
from math import isfinite

import numpy as np
from qiskit import ClassicalRegister, QuantumCircuit, QuantumRegister
from qiskit.circuit.library import UCGate
from qiskit.transpiler import Target, generate_preset_pass_manager
from qiskit_aer import AerSimulator

from .model import DETUNINGS, SETTINGS, hamiltonian, links, unitary

METHODS = ("exact", "strang_2", "strang_4", "strang_8")
SEED = 314159
NOISE_SEED = 271828


def direction_gate(edges, axis, time):
    """Four 2x2 blocks indexed by the two control bits in ascending qubit order."""
    controls = [q for q in range(3) if q != axis]
    blocks = []
    for mask in range(4):
        source = sum(((mask >> i) & 1) << q for i, q in enumerate(controls))
        link = edges.get((axis, source))
        if link is None:
            blocks.append(np.eye(2, dtype=complex))
        else:
            diagonal = np.cos(time)
            offdiag = -1j * np.sin(time)
            blocks.append(np.array([
                [diagonal, offdiag * link.conjugate()],
                [offdiag * link, diagonal],
            ]))
    return UCGate(blocks, up_to_diagonal=False), [axis, *controls]


def logical(point, method):
    setting = SETTINGS[point.setting]
    h = hamiltonian(setting)
    circuit = QuantumCircuit(3, name=point.id.replace(".", "p"))
    circuit.metadata = {"case_id": point.id, "synthesis": method}
    if method == "exact":
        if point.setting in {"zero", "xy"}:
            start = 2 if point.setting == "xy" else 0
            if start == 2:
                circuit.unitary(unitary(h[:4, :4], point.time), [0, 1])
            for axis in range(start, 3):
                local = np.array([[0, 1], [1, DETUNINGS[axis]]])
                circuit.unitary(unitary(local, point.time), [axis])
        else:
            circuit.unitary(unitary(h, point.time), range(3))
        return circuit
    if method not in METHODS:
        raise ValueError(f"unknown synthesis method {method}")
    repetitions = int(method.rsplit("_", 1)[1])
    dt = point.time / repetitions
    edges = links(setting)
    sequence = *(direction_gate(edges, q, dt/2) for q in range(2)), direction_gate(edges, 2, dt)
    for step in range(repetitions + 1):
        duration = dt/2 if step in (0, repetitions) else dt
        for axis, energy in enumerate(DETUNINGS):
            circuit.p(-duration * energy, axis)
        if step != repetitions:
            for gate, qargs in (*sequence, *reversed(sequence[:2])):
                circuit.append(gate, qargs)
    return circuit


def _valid(entry):
    return entry is not None and entry.error is not None and isfinite(entry.error) and 0 <= entry.error < 1


def select_patch(backend, *, preferred=None):
    target = backend.target
    gate_edges = {}
    for name in ("cz", "cx", "ecr"):
        if name not in target:
            continue
        for qargs, item in target[name].items():
            if qargs and _valid(item):
                edge = tuple(sorted(qargs))
                gate_edges[edge] = min(gate_edges.get(edge, 1.0), item.error)
    neighbors = {q: [] for q in range(backend.num_qubits)}
    for left, right in gate_edges:
        neighbors[left].append(right)
        neighbors[right].append(left)
    candidates = []
    for middle, adjacent in neighbors.items():
        for left, right in combinations(sorted(adjacent), 2):
            patch = (left, middle, right)
            readout = [target["measure"].get((q,)) for q in patch]
            if not all(_valid(item) for item in readout):
                continue
            edge_cost = sum(gate_edges[tuple(sorted((end, middle)))] for end in (left, right))
            score = 12 * edge_cost + sum(item.error for item in readout)
            candidates.append((score, patch))
    if preferred is not None:
        preferred = tuple(preferred)
        candidates = [(score, preferred) for score, patch in candidates
                      if preferred in (patch, patch[::-1])]
    if not candidates:
        raise ValueError("backend has no calibrated connected three-qubit patch")
    score, patch = min(candidates)
    properties = backend.properties()
    calibration = {
        "backend": backend.name, "backend_version": backend.backend_version,
        "calibration_id": getattr(backend, "calibration_id", None),
        "calibration_timestamp": properties.last_update_date.isoformat() if properties else None,
        "logical_to_initial_physical": dict(zip("xyz", patch, strict=True)),
        "score_12_per_native_edge_plus_readout": score,
        "qubits": [], "instructions": [],
    }
    for qubit in patch:
        prop = target.qubit_properties[qubit]
        calibration["qubits"].append({
            "physical": qubit, "t1_s": prop.t1, "t2_s": prop.t2,
            "readout_error": target["measure"][(qubit,)].error,
        })
    reduced = Target(num_qubits=3, dt=target.dt)
    for name in ("id", "rz", "sx", "x", "cz", "cx", "ecr", "measure"):
        if name not in target:
            continue
        local = {}
        for qargs, prop in target[name].items():
            if qargs and set(qargs).issubset(patch):
                local[tuple(patch.index(q) for q in qargs)] = prop
                if prop is not None:
                    calibration["instructions"].append({
                        "gate": name, "physical": qargs, "error": prop.error, "duration_s": prop.duration,
                    })
        if local:
            reduced.add_instruction(target.operation_from_name(name), local, name=name)
    return patch, reduced, calibration


def measurements(circuit):
    result = {}
    for item in circuit.data:
        if item.operation.name == "measure":
            result[circuit.find_bit(item.clbits[0]).index] = circuit.find_bit(item.qubits[0]).index
    return tuple(result[index] for index in range(3))


def compile_pilot(backend, patch, target, points, method):
    manager = generate_preset_pass_manager(
        target=target, optimization_level=3, seed_transpiler=SEED, initial_layout=[0, 1, 2],
        routing_method="sabre", approximation_degree=1.0,
    )
    results = []
    for point in points:
        count = 0

        def routing_callback(**event):
            nonlocal count
            if event["pass_"].name() == "SabreSwap":
                count += event["dag"].count_ops().get("swap", 0)

        circuit = logical(point, method)
        circuit.add_register(ClassicalRegister(3, "out"))
        circuit.measure(range(3), range(3))
        compact = manager.run(circuit, callback=routing_callback)
        physical = QuantumCircuit(
            QuantumRegister(backend.num_qubits, "q"), ClassicalRegister(3, "out"),
            name=circuit.name, metadata=circuit.metadata,
        )
        physical.compose(compact, qubits=patch, clbits=range(3), inplace=True)
        if measurements(physical) != tuple(patch[index] for index in measurements(compact)):
            raise ValueError("output bit order changed during physical embedding")
        gates = Counter()
        duration = 0.0
        missing = set()
        for item in physical.data:
            name = item.operation.name
            where = tuple(physical.find_bit(bit).index for bit in item.qubits)
            if not set(where).issubset(patch) or not backend.target.instruction_supported(
                operation_name=name, qargs=where,
            ):
                raise ValueError(f"{name} is not an ISA operation on the chosen patch")
            if len(where) == 2:
                gates[name] += 1
            entry = backend.target[name].get(where)
            if entry is not None and entry.duration is not None:
                duration += entry.duration
            elif name != "rz":
                missing.add(name)
        results.append((physical, {
            "depth": physical.depth(), "two_qubit_gates": sum(gates.values()),
            "two_qubit_operations": dict(gates), "routing_swaps_before_translation": count,
            "final_measurement_physical_xyz": measurements(physical),
            "serial_gate_measure_duration_s": duration, "missing_timing": sorted(missing),
        }))
    return results


def ideal_probabilities(circuits):
    bare = []
    for circuit in circuits:
        copy = circuit.remove_final_measurements(inplace=False)
        copy.save_probabilities(list(measurements(circuit)))
        bare.append(copy)
    result = AerSimulator(method="statevector", max_parallel_threads=2).run(
        bare, shots=1, seed_simulator=NOISE_SEED
    ).result()
    if not result.success:
        raise RuntimeError(f"Aer ideal simulation failed: {result.status}")
    return [np.asarray(result.data(index)["probabilities"]) for index in range(len(circuits))]
