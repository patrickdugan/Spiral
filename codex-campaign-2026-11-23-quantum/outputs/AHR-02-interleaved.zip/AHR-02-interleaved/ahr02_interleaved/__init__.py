"""Within-job comparison of legacy and matched gauge circuits."""
