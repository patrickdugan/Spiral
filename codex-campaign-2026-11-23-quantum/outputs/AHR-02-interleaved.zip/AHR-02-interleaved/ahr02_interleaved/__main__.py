"""Local simulation and opt-in IBM workflow."""

import argparse
import json
import logging
from pathlib import Path

from ahr01.hardware import Hold, allocation, open_service, select_backend
from ahr02.hardware import submit

from .design import validate
from .experiment import prepare
from .hardware import collect


def main(argv=None):
    parser = argparse.ArgumentParser(prog="python -m ahr02_interleaved")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("validate")
    prep = commands.add_parser("prepare")
    prep.add_argument("--out", type=Path, required=True)
    prep.add_argument("--live", action="store_true")
    send = commands.add_parser("submit")
    send.add_argument("--run", type=Path, required=True)
    send.add_argument("--confirm-free-qpu", action="store_true", required=True)
    receive = commands.add_parser("collect")
    receive.add_argument("--run", type=Path, required=True)
    receive.add_argument("--wait", type=int, choices=range(1, 61), metavar="1-60")
    for command in (prep, send, receive):
        command.add_argument("--token-file", type=Path)
        command.add_argument("--instance")
    args = parser.parse_args(argv)
    logging.getLogger("qiskit_ibm_runtime").setLevel(logging.CRITICAL)
    logging.getLogger("ibm_cloud_sdk_core").setLevel(logging.CRITICAL)
    try:
        if args.command == "validate":
            result = validate()
        elif args.command == "prepare":
            if args.out.exists() and any(args.out.iterdir()):
                parser.error("--out must be new or empty")
            quota = None
            if args.live:
                service = open_service(args.token_file, args.instance)
                quota = allocation(service)
                backend = select_backend(service, "ibm_kingston")
            else:
                from qiskit_ibm_runtime.fake_provider import FakeKingston

                backend = FakeKingston()
            result = prepare(backend, args.out, quota=quota)
        elif args.command == "submit":
            service = open_service(args.token_file, args.instance)
            result = submit(service, args.run, authorized=args.confirm_free_qpu)
        else:
            service = open_service(args.token_file, args.instance)
            result = collect(service, args.run, args.wait)
    except Hold as exc:
        print(f"HOLD — {exc}")
        return 2
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
