"""Freeze the crossed gauge/circuit design and enforce one readout mapping."""

from collections import Counter
from itertools import permutations

import numpy as np
from ahr02.circuits import compile_pilot, measurements, select_patch
from ahr02.model import PRIMARY_TIME, Point, exact
from ahr02_gauge.matched import (
    NEIGHBOR_CX,
    _cx,
    circuit_for,
    instruction_key,
    signature,
)
from qiskit import ClassicalRegister
from qiskit.quantum_info import Statevector

PHYSICAL_PATCH = (38, 49, 48)
ARMS = {
    "legacy_gradient": ("legacy", "gradient"),
    "legacy_copy": ("legacy", "gauge_copy"),
    "matched_gradient": ("matched", "gradient"),
    "matched_copy": ("matched", "gauge_copy"),
}
ORDERS = (
    ("legacy_gradient", "matched_gradient", "legacy_copy", "matched_copy"),
    ("matched_copy", "legacy_copy", "matched_gradient", "legacy_gradient"),
    ("legacy_copy", "matched_copy", "legacy_gradient", "matched_gradient"),
    ("matched_gradient", "legacy_gradient", "matched_copy", "legacy_copy"),
)
# Repeat the positional balance, reversing the sequence of the four block orders.
BLOCKS = ORDERS + ORDERS[::-1]
SHOTS = 2048
SIM_SHOTS = 65536
EQUIVALENCE_MARGIN = 0.02


def align_readout(circuit, desired, patch, cz_edges):
    """Bubble the measured logical wires along the line when routing permutes them."""
    current = list(measurements(circuit))
    if tuple(current) == desired:
        return circuit, 0
    aligned = circuit.remove_final_measurements(inplace=False)
    if aligned.num_clbits != 0:
        raise ValueError("the legacy circuit retained classical state after removing readout")
    target = [desired.index(wire) for wire in patch]
    residents = [current.index(wire) for wire in patch]
    swaps = 0
    for position, logical in enumerate(target):
        actual = residents.index(logical)
        while actual > position:
            left, right = patch[actual - 1], patch[actual]
            _cx(aligned, left, right, cz_edges)
            _cx(aligned, right, left, cz_edges)
            _cx(aligned, left, right, cz_edges)
            residents[actual - 1], residents[actual] = residents[actual], residents[actual - 1]
            swaps += 1
            actual -= 1
    aligned.add_register(ClassicalRegister(3, "out"))
    aligned.measure(desired, range(3))
    return aligned, swaps


def validate():
    assert len(BLOCKS) == 8
    assert all(set(block) == set(ARMS) for block in BLOCKS)
    for block in BLOCKS:
        assert all(ARMS[block[slot]][0] != ARMS[block[slot+1]][0] for slot in range(3))
    assert all(Counter(block[slot] for block in BLOCKS) == dict.fromkeys(ARMS, 2) for slot in range(4))
    patch = (0, 1, 2)
    highest_error = 0.0
    for readout in permutations(patch):
        for arm in ("gradient", "gauge_copy"):
            circuit, _ = circuit_for(arm, patch, 3, set(NEIGHBOR_CX), readout_xyz=readout)
            native_state = Statevector.from_instruction(circuit).data
            physical_indices = [sum(((site >> q) & 1) << readout[q] for q in range(3))
                                for site in range(8)]
            actual = native_state[physical_indices]
            expected = exact(Point(arm, PRIMARY_TIME))
            phase = np.vdot(expected, actual)
            residual = float(max(abs(actual - expected * phase/abs(phase))))
            highest_error = max(highest_error, residual)
            assert residual < 1e-10
    return {
        "checks": dict.fromkeys((
            "position_balanced_interleaved_blocks", "complex_matched_states_for_every_readout_permutation",
        ), "pass"),
        "max_complex_amplitude_residual": highest_error,
    }


def build_templates(backend):
    patch, compact, calibration = select_patch(backend, preferred=PHYSICAL_PATCH)
    cz_edges = {edge for edge in backend.target["cz"] if edge and set(edge).issubset(patch)}
    dataset = compile_pilot(
        backend, patch, compact, [Point(name, PRIMARY_TIME) for name in ("gradient", "gauge_copy")], "exact",
    )
    common_readout = measurements(dataset[0][0])
    templates = {}
    phase_starts = {}
    readout_swaps = {}
    for arm, (legacy, _) in zip(tuple(ARMS)[:2], dataset, strict=True):
        templates[arm], readout_swaps[arm] = align_readout(legacy, common_readout, patch, cz_edges)
    for arm in ("matched_gradient", "matched_copy"):
        circuit, start = circuit_for(
            ARMS[arm][1], patch, backend.num_qubits, cz_edges, block=1, readout_xyz=common_readout,
        )
        templates[arm], phase_starts[arm] = circuit, start
        readout_swaps[arm] = 0
    left, right = (templates[arm] for arm in ("matched_gradient", "matched_copy"))
    assert signature(left) == signature(right)
    a, b = instruction_key(left, parameters=True), instruction_key(right, parameters=True)
    assert a[:phase_starts["matched_gradient"]] == b[:phase_starts["matched_copy"]]
    differences = [index for index, (u, v) in enumerate(zip(a, b, strict=True)) if u != v]
    assert len(differences) == 7 and all(index >= phase_starts["matched_gradient"] and a[index][0] == "rz"
                                          for index in differences)
    assert all(measurements(circuit) == common_readout for circuit in templates.values())
    return templates, calibration, common_readout, readout_swaps
