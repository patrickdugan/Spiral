"""Simulate and analyze the within-job implementation-by-gauge comparison."""

from collections import Counter
from importlib.metadata import version
from math import sqrt
from statistics import NormalDist

import numpy as np
from ahr01.circuits import aer_noisy_counts
from ahr01.experiment import digest, read_json, resource_estimate, timestamp, write_json
from ahr01.statistics import difference, wilson
from ahr02.circuits import ideal_probabilities, measurements
from ahr02.model import PRIMARY_TIME, Point, exact
from ahr02_gauge.matched import instruction_key, signature
from qiskit import qpy
from scipy.stats import t

from .design import (
    ARMS,
    BLOCKS,
    EQUIVALENCE_MARGIN,
    PHYSICAL_PATCH,
    SHOTS,
    SIM_SHOTS,
    build_templates,
    validate,
)

WEIGHTS = {"matched_copy": 1, "matched_gradient": -1, "legacy_copy": -1, "legacy_gradient": 1}


def _p000(counts):
    n = sum(counts.values())
    k = counts.get("000", 0)
    return {"p00": k/n, "wilson_95": wilson(k, n), "shots": n, "zero_counts": k}


def comparisons(counts):
    p = {arm: _p000(counts[arm]) for arm in ARMS}
    legacy = difference(p["legacy_copy"], p["legacy_gradient"])
    matched = difference(p["matched_copy"], p["matched_gradient"])
    delta = sum(weight * p[arm]["p00"] for arm, weight in WEIGHTS.items())
    variance = sum(entry["p00"] * (1-entry["p00"]) / entry["shots"] for entry in p.values())
    half_width = NormalDist().inv_cdf(0.975) * sqrt(variance)
    return {
        "return_probabilities": p, "legacy_gauge_return": legacy, "matched_gauge_return": matched,
        "matched_minus_legacy_gauge_shift": {"delta": delta, "wald_95": [delta-half_width, delta+half_width]},
    }


def _metrics(circuit, backend, readout, swaps):
    if measurements(circuit) != readout:
        raise ValueError("a circuit did not preserve the common logical readout mapping")
    counts = Counter()
    duration = 0.0
    missing = set()
    for operation, qargs, _ in instruction_key(circuit):
        if not set(qargs).issubset(PHYSICAL_PATCH) or not backend.target.instruction_supported(
            operation_name=operation, qargs=qargs,
        ):
            raise ValueError(f"{operation} on {qargs} violates the locked patch or live ISA")
        counts[operation] += 1
        item = backend.target[operation].get(qargs)
        if item is not None and item.duration is not None:
            duration += item.duration
        elif operation != "rz":
            missing.add(operation)
    return {
        "native_counts": dict(counts), "depth": circuit.depth(), "readout_alignment_swaps": swaps,
        "serial_gate_measure_duration_s": duration, "missing_timing": sorted(missing),
        "logical_readout_physical_xyz": readout, "ordered_native_skeleton_sha256": signature(circuit),
    }


def prepare(backend, out, *, quota=None):
    validation = validate()
    templates, calibration, readout, swaps = build_templates(backend)
    metrics = {arm: _metrics(circuit, backend, readout, swaps[arm]) for arm, circuit in templates.items()}
    ideal = dict(zip(ARMS, ideal_probabilities(list(templates.values())), strict=True))
    errors = {
        arm: float(max(abs(values - abs(exact(Point(ARMS[arm][1], PRIMARY_TIME)))**2)))
        for arm, values in ideal.items()
    }
    error = max(errors.values())
    if not np.isfinite(error) or error > 1e-8:
        raise ValueError(f"common-readout Aer ideal gate failed: {error}")
    noisy_counts = dict(zip(ARMS, aer_noisy_counts(list(templates.values()), backend, SIM_SHOTS), strict=True))
    circuits, cost = [], []
    for block, order in enumerate(BLOCKS, 1):
        for arm in order:
            circuit = templates[arm].copy(name=f"{arm}_b{block}")
            circuit.metadata = {"case_id": circuit.name, "block": block, "arm": arm}
            circuits.append(circuit)
            cost.append(metrics[arm])
    out.mkdir(parents=True, exist_ok=True)
    qpy_file = out / "pilot.qpy"
    with qpy_file.open("wb") as stream:
        qpy.dump(circuits, stream)
    checks = validation["checks"]
    checks.update(dict.fromkeys((
        "every_arm_on_locked_patch_and_live_isa", "every_arm_same_logical_readout",
        "compiled_ideal_all_site_probabilities", "matched_gauge_same_prefix_and_native_skeleton",
    ), "pass"))
    manifest = {
        "experiment": "AHR-02-interleaved", "schema": 1, "prepared_utc": timestamp(),
        "target_type": "live" if quota else "archived_snapshot", "free_account_check_at_prepare": quota,
        "calibration": calibration, "validation": validation,
        "selection": {"selected": "legacy_and_matched_gauge", "methods": {"legacy_and_matched_gauge": {
            "eligible": True, "max_absolute_site_error": error,
        }}},
        "time": PRIMARY_TIME, "patch": PHYSICAL_PATCH, "logical_readout_physical_xyz": readout,
        "arms": ARMS, "block_orders": BLOCKS, "ordered_circuits": [c.name for c in circuits],
        "simulation_shots_per_arm": SIM_SHOTS, "matched_equivalence_margin": EQUIVALENCE_MARGIN,
        "resource_estimate": resource_estimate(cost, SHOTS),
        "qpy": {"file": qpy_file.name, "sha256": digest(qpy_file)},
        "packages": {name: version(name) for name in ("qiskit", "qiskit-aer", "qiskit-ibm-runtime", "numpy", "scipy")},
    }
    write_json(out / "manifest.json", manifest)
    write_json(out / "simulation.json", {
        "ideal_site_probabilities": {arm: values.tolist() for arm, values in ideal.items()},
        "ideal_max_site_error_by_arm": errors, "calibrated_aer_counts": noisy_counts,
        "calibrated_aer_comparisons": comparisons(noisy_counts), "arm_metrics": metrics,
    })
    return manifest


def analyze(out):
    job = read_json(out / "pilot_counts.json")
    pooled = {arm: Counter() for arm in ARMS}
    rows = []
    for block in range(1, len(BLOCKS) + 1):
        counts = {arm: job["counts"][f"{arm}_b{block}"] for arm in ARMS}
        for arm in ARMS:
            pooled[arm].update(counts[arm])
        rows.append(comparisons(counts))
    observed = comparisons(pooled)
    mean = observed["matched_minus_legacy_gauge_shift"]["delta"]
    values = np.array([row["matched_minus_legacy_gauge_shift"]["delta"] for row in rows])
    if abs(float(values.mean()) - mean) > 1e-12:
        raise ValueError("block and pooled estimates differ under the equal-shot design")
    half_width = float(t.ppf(0.975, len(rows)-1) * values.std(ddof=1) / sqrt(len(rows)))
    lo, hi = observed["matched_gauge_return"]["newcombe_95"]
    summary = {
        "pooled_counts": pooled, "pooled_comparisons": observed,
        "per_block_comparisons": dict(enumerate(rows, 1)),
        "block_t_95_for_matched_minus_legacy": [mean-half_width, mean+half_width],
        "matched_gauge_interval_inside_margin": lo >= -EQUIVALENCE_MARGIN and hi <= EQUIVALENCE_MARGIN,
    }
    write_json(out / "observations.json", summary)
    return summary
