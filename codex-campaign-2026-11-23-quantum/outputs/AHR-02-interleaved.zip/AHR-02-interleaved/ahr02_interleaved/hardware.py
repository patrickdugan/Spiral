"""Archive one Open Plan job and verify its calibration and PUB timing."""

from datetime import datetime

from ahr01.experiment import read_json, timestamp, write_json
from ahr01.hardware import Hold, allocation
from ahr02.experiment import OUTCOMES
from ahr02.hardware import _load
from qiskit.exceptions import QiskitError
from qiskit_ibm_runtime.api.exceptions import RequestsApiError
from qiskit_ibm_runtime.exceptions import RuntimeJobTimeoutError
from requests.exceptions import RequestException

from .experiment import analyze

LOOKUP_ERRORS = (QiskitError, RequestsApiError, RequestException, ValueError)


def _timing(result, case_ids):
    executor = result.metadata.get("executor")
    spans = getattr(executor, "chunk_timing", ()) or ()
    timing = []
    for span in spans:
        parts = []
        for part in span.parts:
            index = part.idx_item
            parts.append({
                "pub_index": index, "case_id": case_ids[index] if 0 <= index < len(case_ids) else None,
                "configurations": part.size,
            })
        timing.append({"start": span.start.isoformat(), "stop": span.stop.isoformat(), "parts": parts})
    return timing


def _calibration(job, prepared, timing):
    report = {"prepared_calibration": prepared, "job_start_calibration": None, "last_chunk_calibration": None}
    try:
        props = job.properties()
        if props is not None:
            report["job_start_calibration"] = props.last_update_date.isoformat()
    except LOOKUP_ERRORS as exc:
        report["job_start_lookup_error"] = type(exc).__name__
    if timing:
        try:
            job_backend = job.backend()
            last_stop = datetime.fromisoformat(max(chunk["stop"] for chunk in timing))
            props = job_backend.properties(datetime=last_stop) if job_backend is not None else None
            if props is not None:
                report["last_chunk_calibration"] = props.last_update_date.isoformat()
        except LOOKUP_ERRORS as exc:
            report["last_chunk_lookup_error"] = type(exc).__name__
    timestamps = (report["job_start_calibration"], report["last_chunk_calibration"])
    report["same_snapshot_verified_at_job_start_and_last_chunk"] = all(
        value is not None and datetime.fromisoformat(value) == datetime.fromisoformat(prepared)
        for value in timestamps
    )
    return report


def collect(service, out, wait_seconds=None):
    manifest = _load(out, allocation(service))
    path = out / "pilot_job.json"
    submitted = read_json(path)
    if submitted["qpy_sha256"] != manifest["qpy"]["sha256"]:
        raise Hold("the job checkpoint does not match the interleaved circuits")
    if not submitted["job_id"]:
        jobs = service.jobs(job_tags=[submitted["job_tag"]], instance=service.active_instance(), limit=2)
        if len(jobs) != 1:
            raise Hold("could not verify the existing submission; check its IBM job tag")
        submitted["job_id"] = jobs[0].job_id()
        write_json(path, submitted)
    job = service.job(submitted["job_id"])
    if wait_seconds and not job.in_final_state():
        try:
            job.wait_for_final_state(timeout=wait_seconds)
        except RuntimeJobTimeoutError:
            pass
    report = {"job_id": job.job_id(), "backend": submitted["backend"], "status": job.status()}
    if report["status"] != "DONE":
        return report

    record = out / "pilot_counts.json"
    evidence = out / "execution_evidence.json"
    if record.exists() and evidence.exists():
        previous = read_json(record)
        counts, received = previous["counts"], previous["retrieved_utc"]
    else:
        result = job.result()
        ids = manifest["ordered_circuits"]
        counts = {case_id: pub.data.out.get_counts() for case_id, pub in zip(ids, result, strict=True)}
        published_ids = [(pub.metadata.get("circuit_metadata") or {}).get("case_id") for pub in result]
        if any(published_ids) and published_ids != ids:
            raise Hold("IBM PUB identifiers do not match the interleaved submission")
        timing = _timing(result, ids)
        published_indices = [part["pub_index"] for chunk in timing for part in chunk["parts"]]
        write_json(evidence, {
            "job_id": report["job_id"], "chunks": timing,
            "provider_published_item_indices": published_indices,
            "all_submitted_pubs_covered_by_chunk_records": set(published_indices) == set(range(len(ids))),
            "provider_pub_case_ids_verified": published_ids == ids,
            "calibration": _calibration(job, manifest["calibration"]["calibration_timestamp"], timing),
        })
        received = timestamp()
    if set(counts) != set(manifest["ordered_circuits"]) or any(
        not set(counter).issubset(OUTCOMES) or sum(counter.values()) != submitted["shots_per_circuit"]
        for counter in counts.values()
    ):
        raise Hold("IBM counts differ from the submitted shot or outcome space")
    usage = job.usage()
    write_json(record, {
        **submitted, **report, "counts": counts, "retrieved_utc": received, "quantum_seconds": usage,
    })
    write_json(out / "post_run_allocation.json", allocation(service))
    analyze(out)
    return {**report, "quantum_seconds": usage}
