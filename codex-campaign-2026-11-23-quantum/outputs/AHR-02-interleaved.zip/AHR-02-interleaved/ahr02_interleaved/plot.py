"""Show each gauge shift and the within-job comparison."""

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

LABELS = (
    ("legacy_gauge_return", "Legacy gauge shift", "newcombe_95"),
    ("matched_gauge_return", "Matched gauge shift", "newcombe_95"),
    ("matched_minus_legacy_gauge_shift", "Matched minus legacy", "wald_95"),
)


def plot(path, simulated, observed, blocks):
    fig, axis = plt.subplots(figsize=(8.1, 3.7), layout="constrained")
    for at, (key, _, interval_key) in enumerate(LABELS):
        for series, color, marker, offset, label in (
            (simulated, "#376d88", "o", -0.14, "Calibrated Aer"),
            (observed, "#aa4728", "s", 0.14, "IBM QPU"),
        ):
            result = series[key]
            value = result["delta"]
            lower, upper = result[interval_key]
            axis.errorbar(value, at + offset, xerr=[[value-lower], [upper-value]],
                          fmt=marker, color=color, markersize=5, capsize=3,
                          label=label if at == 0 else None, zorder=3)
    axis.scatter(blocks, [2.34] * len(blocks), marker="|", color="#757b87", s=65,
                 alpha=0.65, label="Individual IBM blocks")
    axis.axvline(0, color="#555d68", linewidth=0.85, linestyle="--", zorder=1)
    axis.set(title="AHR-02 · Interleaved gauge comparison",
             xlabel="Difference in return probability with 95% interval",
             yticks=range(len(LABELS)), yticklabels=[row[1] for row in LABELS])
    axis.set_ylim(2.55, -0.5)
    axis.spines[["top", "right"]].set_visible(False)
    axis.grid(axis="x", alpha=0.25)
    handles, labels = axis.get_legend_handles_labels()
    by_label = dict(zip(labels, handles, strict=True))
    order = ("Calibrated Aer", "IBM QPU", "Individual IBM blocks")
    axis.legend([by_label[label] for label in order], order, loc="upper left", frameon=False)
    fig.savefig(path, dpi=200)
    plt.close(fig)
