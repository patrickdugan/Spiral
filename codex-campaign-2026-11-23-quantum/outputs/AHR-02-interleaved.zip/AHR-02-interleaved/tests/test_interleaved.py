import numpy as np
from ahr02.circuits import ideal_probabilities, measurements
from ahr02.model import PRIMARY_TIME, Point, exact
from ahr02_interleaved.design import ARMS, align_readout, build_templates, validate
from ahr02_interleaved.experiment import comparisons
from qiskit import QuantumCircuit
from qiskit_ibm_runtime.fake_provider import FakeKingston


def test_complex_states_and_interleaved_blocks():
    assert all(check == "pass" for check in validate()["checks"].values())


def test_readout_alignment_preserves_logical_outcome():
    circuit = QuantumCircuit(3, 3)
    circuit.x(0)
    circuit.h(2)
    circuit.measure(range(3), range(3))
    copy, swaps = align_readout(circuit, (1, 2, 0), (0, 1, 2), {(0, 1), (1, 2)})
    assert swaps == 2 and measurements(copy) == (1, 2, 0)
    expected, actual = ideal_probabilities([circuit, copy])
    np.testing.assert_allclose(actual, expected, atol=1e-12)


def test_archived_patch_has_common_readout():
    templates, _, readout, _ = build_templates(FakeKingston())
    assert all(measurements(circuit) == readout for circuit in templates.values())
    for arm, probabilities in zip(ARMS, ideal_probabilities(list(templates.values())), strict=True):
        np.testing.assert_allclose(
            probabilities, abs(exact(Point(ARMS[arm][1], PRIMARY_TIME)))**2, atol=1e-8,
        )


def test_implementation_interaction():
    def counts(k):
        return {"000": k, "111": 1000-k}

    result = comparisons({
        "legacy_gradient": counts(250), "legacy_copy": counts(280),
        "matched_gradient": counts(270), "matched_copy": counts(275),
    })
    np.testing.assert_allclose(result["legacy_gauge_return"]["delta"], 0.03, atol=1e-12)
    np.testing.assert_allclose(result["matched_gauge_return"]["delta"], 0.005, atol=1e-12)
    np.testing.assert_allclose(result["matched_minus_legacy_gauge_shift"]["delta"], -0.025, atol=1e-12)
