# AHR-02 · Three-prime arithmetic holonomy

AHR-02 extends the four-site rotor to the eight sites $n=2^x3^y5^z$ on $x=q_0$, $y=q_1$, and $z=q_2$. It compares the return and full site distributions of several flux assignments on the same cube. The experiment includes a gauge-equivalent copy of the flux-gradient cube and a common spanning tree retaining phased links.

- [Pilot outcome, device costs and resource use](REPORT.md)
- [Numerical validation and reproducibility manifest](results/manifest.json) · [All ideal spectra, site distributions and reduced states](results/exact_grid.json)
- [Return curves and paired controls](results/return_probabilities.png) · [All eight site probabilities](results/site_probabilities.csv) · [Contrast statistics](results/contrasts.json)
- [Compiled pilot circuits](results/pilot.qpy) · [Synthesis and routing comparison](results/compilation.json)

## Model and controls

The on-site energy is $x\ln 2+y\ln 3+z\ln 5$. A forward link in direction $i$ has matrix element $e^{i A_i(s)}$ in row $s+\hat i$, column $s$, with a conjugate reverse link. We use $\hbar=J_i=1$ and start in $|000\rangle$. The little-endian site order is $1,2,3,6,5,10,15,30$ in increasing integer bitstring order.

For $A_x=0$, $A_y=\alpha x$ and $A_z=\beta x+\gamma y+\kappa xy$, the oriented face phases are

$$
F_{xy}(z)=\alpha,\qquad F_{xz}(y)=\beta+\kappa y,\qquad F_{yz}(x)=\gamma+\kappa x.
$$

The oriented sum over the six cube faces is zero modulo $2\pi$. Each link occurs twice with opposite orientations. The cycle rank is $12-8+1=5$. Varying $\kappa$ shifts the XZ and YZ faces in a way that preserves the shared-edge constraint.

| Arm | $(\alpha,\beta,\gamma,\kappa)$ |
| --- | --- |
| Zero | $(0,0,0,0)$ |
| XY | $(\pi,0,0,0)$ |
| XY + XZ | $(\pi,\pi/2,0,0)$ |
| Flux gradient | $(\pi,\pi/2,0,\pi/2)$ |

The gauge copy adds $\chi(s+\hat i)-\chi(s)$ to each gradient link, with $\chi=0.37x-0.28y+0.23z+0.31xy-0.17xz+0.29yz+0.19xyz$. This conjugates the evolution by a diagonal unitary and preserves the probability of every site transition. The tree retains the edges $(1,2),(3,6),(5,10),(15,30),(2,6),(10,30),(6,30)$. Every tree link phase can be absorbed by assigning phases along the unique path from site 1. The two tree Hamiltonians therefore have identical site-transition probabilities.

The fixed primary endpoint is $P_{000}(\mathrm{gradient})-P_{000}(\mathrm{zero})$ at $t=1.5$, chosen outside the AHR-01 design grid before calculating its value. The four cube arms run at $t=0.8,1.2,1.5$. The gauge copy and tree pair run at $t=1.5$. A secondary comparison sums probability over the sites where the exact model predicts an increase for gradient versus XY + XZ. Membership is frozen by the exact model and recorded before submission. See [results/manifest.json](results/manifest.json).

The validator checks the six loop products and cube boundary, Hermiticity, projector Pauli ordering, the full zero-flux tensor factorization, both conjugations and all site-transition controls, the fourth-order corner-return coefficient, exact full-operator synthesis, controlled directional links, and second-order convergence. For the cube, the first flux-dependent coefficient of the return contrast is $t^4\sum_{f\ni000}(\cos F_f-1)/6$, from the three faces meeting at the starting corner.

## Reproduce

Use Python 3.12 and install the pinned requirements in a virtual environment. The ZIP includes the AHR-01 Python support for IBM authentication, resource checks and confidence intervals. In a source checkout, add the adjacent AHR-01 directory to the import path. On PowerShell, run this from the AHR-02 directory.

~~~powershell
$env:PYTHONPATH = (Resolve-Path ../AHR-01).Path
~~~

~~~shell
python -m pip install -r requirements.txt
python -m ahr02 validate
python -m pytest -q
python -m ahr02 prepare --out runs/archived
~~~

Preparation benchmarks exact full-unitary synthesis and directional second-order Suzuki–Trotter with 2, 4 and 8 repetitions. It selects the suite with the lowest total compiled depth that meets the absolute error limits of 0.015 on $P_{000}$ and 0.025 on every site. Exact synthesis uses known factorization in the zero and XY cases and dense unitary synthesis for the remaining cases. The compiler restricts routing to a calibrated three-qubit patch, records pre-translation SWAP counts, and checks the final measurement map and each physical instruction against the live ISA. [Qiskit transpiler stages](https://quantum.cloud.ibm.com/docs/en/guides/transpiler-stages)

For IBM runs, pass the path of a local IBM key file or use an existing default Qiskit account. The service verifies an existing Open Plan instance, checks the live calibration, and caps the workload using measured instruction durations plus a delay and overhead reserve. Submission requires the explicit option below. If the job ID is still pending in the checkpoint, collection looks it up by tag. [IBM job usage](https://quantum.cloud.ibm.com/docs/en/ibm-quantum-compute/estimate-job-run-time) · [IBM client-side Sampler](https://quantum.cloud.ibm.com/docs/en/api/qiskit-ibm-runtime/executor-sampler-sampler)

~~~shell
python -m ahr02 probe --token-file PATH_TO_KEY
python -m ahr02 prepare --live --out runs/live --token-file PATH_TO_KEY
python -m ahr02 submit --run runs/live --confirm-free-qpu --token-file PATH_TO_KEY
python -m ahr02 collect --run runs/live --wait 45 --token-file PATH_TO_KEY
~~~

Wilson intervals describe individual probabilities and Newcombe intervals describe independent shot differences. Each hardware circuit records all eight outcomes. The reported single-qubit reduced density matrices are ideal predictions. The pilot tests controlled interference in this circuit model. Arithmetic specificity, resonance, scaling and genuine tripartite entanglement require separate observables and controls.
