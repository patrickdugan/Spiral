# AHR-02 · IBM Quantum cube pilot

**DONE** on ibm_kingston, IBM job **dc1spods2omc738b34u0**, collected 2026-11-23 13:19:48 SGT.

At $t=1.5$, the primary gradient-minus-zero return contrast was **+0.22852** with 95% Newcombe interval **[+0.20944, +0.24803]**. The 95% interval lies above zero. The gauge-copy control interval excludes zero. Circuit-specific device effects can contribute to the measured contrasts.

| Comparison at $t=1.5$ | Exact | Compiled ideal | Calibrated Aer | IBM QPU | QPU 95% interval |
| --- | ---: | ---: | ---: | ---: | --- |
| Gradient − zero, return | +0.26099 | +0.26099 | +0.24542 | +0.22852 | [+0.20944, +0.24803] |
| Gradient − XY + XZ, return | +0.00015 | +0.00015 | +0.00262 | -0.01367 | [-0.04015, +0.01283] |
| Gradient − XY + XZ, fixed site mass | +0.08047 | +0.08047 | +0.07199 | +0.02051 | [-0.00664, +0.04762] |
| Gauge copy − gradient, return | 0.00000 | 0.00000 | +0.00781 | +0.03369 | [+0.00684, +0.06048] |
| Tree gradient − tree zero, return | 0.00000 | 0.00000 | +0.00189 | -0.00049 | [-0.01751, +0.01653] |

The calibrated Aer primary forecast (+0.24542) falls inside the hardware interval. The exact primary forecast (+0.26099) lies above it. The original gradient and its gauge copy each used 31 native two-qubit gates, with compiled depths 125 and 126. The control compares distinct native gate sequences at the same two-qubit gate count.

The secondary site-mass statistic sums the probabilities at sites 1, 3, 6, 5, 10, 15. The exact model selected those sites before submission. The hardware interval includes zero. Detailed data for all eight outcomes and all 15 conditions are in the site table. The primary and diagnostic intervals quantify shot uncertainty. Device and calibration effects can change the measured probabilities.

## Simulation and synthesis

All 12 mathematical checks passed. The largest ideal probability mismatch over all transitions and tested times was 1.39e-15 for the gauge copy and 1.89e-15 for the tree.

| Synthesis | Sum of depths | Max depth | Native 2Q gates | Routing SWAPs before translation | Worst return error | Worst all-site error |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| **exact** | 1198 | 128 | 284 | 54 | 4.482e-12 | 5.187e-12 |
| strang_2 | 1154 | 366 | 259 | 35 | 0.1634 | 0.1648 |
| strang_4 | 2136 | 725 | 477 | 67 | 0.04103 | 0.04103 |
| strang_8 | 4073 | 1450 | 919 | 131 | 0.01025 | 0.01025 |

The initial IBM patch was $x\mapsto 38$, $y\mapsto 49$, $z\mapsto 48$. All routing stayed on this patch. The per-circuit final measurement maps are in the compilation record. The target was dated 2026-11-23 12:51:40 SGT.

## Resource use

The workload was 15 circuits × 2,048 shots. The timing model estimated 15.66 s with gates, measurement and delays, plus a 60 s reserve. The verified free balance before submission was 577 s and the execution cap was 76 s. IBM reported **10 s** of job usage. The post-run free balance was **567 s**.

The hardware measured site populations in the specified eight-site model. The comparison supports claims about the engineered circulation phases and the measured contrasts. The site labels provide the arithmetic encoding. The exact reduced-state matrices in the numerical grid are predictions.

- [IBM counts and usage](results/pilot_counts.json) · [Submission checkpoint](results/pilot_job.json)
- [Return probability plot](results/return_probabilities.png) · [Eight-outcome table](results/site_probabilities.csv)
- [Exact grid and spectra](results/exact_grid.json) · [Calibrated manifest](results/manifest.json)
