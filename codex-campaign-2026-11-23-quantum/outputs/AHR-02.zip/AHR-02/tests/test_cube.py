import numpy as np
import pytest
from ahr01.hardware import Hold
from ahr02.circuits import compile_pilot, ideal_probabilities, select_patch
from ahr02.experiment import gradient_outcomes, sample_summary
from ahr02.hardware import submit
from ahr02.model import DESIGN_TIMES, PRIMARY_TIME, Point, exact, pilot
from ahr02.validate import validate
from qiskit_ibm_runtime.fake_provider import FakeMarrakesh


def test_cube_and_controls_independently():
    result = validate()
    assert all(value == "pass" for value in result["checks"].values())


def test_fixed_endpoint_and_all_controls():
    assert PRIMARY_TIME not in DESIGN_TIMES
    points = pilot()
    assert len(points) == len({point.id for point in points}) == 15
    assert [point.setting for point in points[-3:]] == ["gauge_copy", "tree_zero", "tree_gradient"]
    assert 0 < len(gradient_outcomes()) < 8


def test_routed_output_preserves_all_logical_bits():
    backend = FakeMarrakesh()
    patch, target, _ = select_patch(backend)
    point = Point("gauge_copy", PRIMARY_TIME)
    [(compiled, stats)] = compile_pilot(backend, patch, target, [point], "exact")
    assert set(stats["final_measurement_physical_xyz"]) == set(patch)
    assert stats["routing_swaps_before_translation"] > 0
    [probabilities] = ideal_probabilities([compiled])
    np.testing.assert_allclose(probabilities, abs(exact(point))**2, atol=1e-9)


def test_three_bit_counts_and_authorization(tmp_path):
    summary = sample_summary({"000": 7, "101": 3})
    assert summary["p00"] == 0.7
    assert summary["site_probabilities"][5] == 0.3
    with pytest.raises(ValueError, match="three-bit"):
        sample_summary({"00": 10})
    with pytest.raises(Hold, match="confirm-free-qpu"):
        submit(None, tmp_path)
