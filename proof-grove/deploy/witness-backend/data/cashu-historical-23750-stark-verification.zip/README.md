# Verify the historical 23,750-sat redemption

Use Python 3.11 or newer on x86-64 Linux or WSL. From the unpacked directory, run:

```sh
chmod +x bin/scarb-verify
python3 -B proof-grove/scripts/audit-exact-melt-stark.py \
  --case case --verifier bin/scarb-verify --profile profile.json \
  --existing-proof proof/redemption-proof.json --out verification-recheck
```

The command pins the original execution receipt, the case, the security profile and the stock Scarb binary. It verifies the STARK, matches the 24 public output words and reruns one mutation of each word. The existing verification directory contains the independent transcript. Prover evidence records the earlier generation timing and memory.

The proof binds the exact historical Cairo statement. The original Bitcoin regtest blocks and independently recorded active checkpoint remain unavailable. The paired issuance and 24,750-sat benchmark is included as a historical receipt. Its original proof bytes are unavailable in this archive.

The Bitcoin transaction audit independently checks the holder signature, exact outputs and fee, and eight mutations of the signature preimage or witness.
