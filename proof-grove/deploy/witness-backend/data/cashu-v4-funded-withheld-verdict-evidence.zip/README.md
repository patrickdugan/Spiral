# Funded Cashu refusal on Bitcoin regtest

This archive records what Bitcoin enforces when the collateral is funded and the setup supplies no verdict. The holder's already-signed exit paid 24,750 sats with a 250-sat fee. At the collateral's eight-block timeout, the challenger received 24,750 sats with a 500-sat fee. A second Bitcoin Core node replayed the resulting chain and checked both confirmed transactions and fees with all wallets unloaded.

Core rejected an early timeout and a mature timeout transaction with a substituted beneficiary. Invalidating the timeout block restored the collateral while the holder's reserve stayed spent. The test starts from the withdrawal prover's exact 109-block checkpoint. It uses archived synthetic setup commitments and exercises the holder signature and Bitcoin timelocks with no verdict opening.

## Reproduce

Verify the ZIP hash from the campaign evidence matrix, extract it, and run `sha256sum -c SHA256SUMS` from the extracted directory. Use Bitcoin Core 31.0 and Python with `cryptography` installed. Set `BITCOIND` to the Bitcoin Core executable, `PROOF_GROVE` to the absolute path of Spiral's `proof-grove` directory, and `M14_TOOLS` to the ZK Rusto `integrations/bitvm3-nova/m14/assertion-smoke` directory containing `joint_withdrawal_refusal.py`.

The original fixture used the public regtest-only holder scalar one. The two outputs have no value outside this fixture. Reproducing from the pinned checkpoint creates new collateral funding and block identifiers. The holder transaction ID stays the same.

```sh
python3 -c 'from pathlib import Path; Path("holder-regtest.key").open("xb").write((1).to_bytes(32, "big"))'
python3 -B "$M14_TOOLS/joint_withdrawal_refusal.py" --core "$BITCOIND" --proof-grove "$PROOF_GROVE" \
  --block-archive checkpoint-blocks.hex --archive-sha256 49408ac588247383d52b6b2b3adc549cd621fbde507bc42b60878f2a4c3977ed \
  --workload withdrawal --statement withdrawal/final-statement.json \
  --statement-sha256 86ce691d58ba7bc21c39221e0a64857b4750165eb58b1d770b408d86fc876085 \
  --record-sha256 e5a7bb50eaf1130f8823bdbf7dc3f232d71931633137b4428ce57781a9a7f270 \
  --holder-key-file holder-regtest.key --proof-input proof-input.json --setup synthetic-setup.json \
  --setup-sha256 51dc4668d2c1f5ba8dba0740c07caff217fcf5d4871fa10ef9fd08e5e359f9b4 \
  --input-blake3 d3b8ad799865dccbb7345598d8860ea36190fd3197d591dac20c219ccf070234 \
  --output reproduced-receipt.json --published-chain reproduced-blocks.hex
```

The archived result is in `refusal-receipt.json`. The alternative regtest chain ending at height 219 is in `refusal-blocks.hex`. Its hash, both transaction IDs and both inclusion proofs are in the receipt.
