# Proof Grove Cashu issuance and holder payout

This download contains the 25,000-sat CDK issuance and the compressed Nova proof for the same protected claim that paid the holder 24,750 sats on Bitcoin regtest. The holder paid a 250-sat fee after the six-block delay. The archived spend uses the holder-only path. The Cashu notes in this fixture are for a localhost test mint, and the associated test reserve has already been spent.

The verifier checks the six Cashu DLEQ proofs offline, reconstructs the first two Nova journal events from the issuance receipt, and verifies the exact three-event withdrawal journal against its pinned key. Separately, it checks the payout's BIP143 signature, BIP141 witness inclusion, and block linkage under the pinned regtest payout header. Proof-backed BitVM settlement requires its own proof and evidence.

## Verify the download

Check the ZIP SHA-256 against the campaign evidence matrix before extracting. From the extracted directory, run `sha256sum -c SHA256SUMS` to verify the files. The proof and the pinned journal are binary inputs to the verifier. Preserve the journal's exact bytes.

Use the Spiral checkout containing `audit-withdrawal-issuance` in `proof-grove/scripts/protected-fixture-evidence.py`. Install the locked wallet dependencies with `pnpm install --frozen-lockfile --ignore-scripts` in `proof-grove/wallet`, using Node.js 24 or later. Run `cargo +stable build --locked --release` in `proof-grove/integrations/cashu-nova` to build the verifier. The verifier computes and checks the identifier of its verification key during setup.

Use Python 3 and an OpenSSL build with secp256k1. Run this from the extracted directory, with `PROOF_GROVE` set to the absolute checkout path ending in `proof-grove` and `NOVA` set to the absolute path to the compiled Nova verifier.

```sh
RAYON_NUM_THREADS=1 python3 -B "$PROOF_GROVE/scripts/protected-fixture-evidence.py" \
  audit-withdrawal-issuance holder-receipt.json verification-local.json \
  --v3-receipt protected-issuance-receipt.json --v3-bundle protected-bundle.json \
  --v3-bundle-id 42fb52c2efd0649e3122a8e683cf6f0f7f894fefc079fbb4b968392342e7ed17 \
  --v3-mint-pin protected-mint-pin.json --candidate candidate.json \
  --candidate-journal candidate-journal.json --proof-dir proof --nova-verifier "$NOVA" \
  --journal-sha256 3292b20dc760cb46890384256ff31bef851663c353940c665943f1b61ea69d0a \
  --nova-key-sha256 e472ec73e400c2d88b4e398741596765024fab4ee22ed7b6c600e8753df1034d \
  --anchor-height 110 --anchor-hash 581bbe122433e9e2360850d9e34b6339a7550c97462a44bee810b21d60f9af98
```

The command should report `dleq_verified`, `batch_bound`, `verified`, `holder_signature_verified`, and `witness_inclusion_verified` as `true`, along with `payout_sats` of `24750` and zero final reserve and outstanding claims. The archived verifier output is `verification.json`. The active-chain observations in this download belong to the local regtest fixture. For consensus replay from the 109-block checkpoint, use the accompanying replayable withdrawal evidence archive described in the campaign evidence matrix.
