# Protected Cashu reserve registry evidence

The regtest registry covers two 25,000-sat reserves. The original reserve has archived independently checked CDK issuance evidence. The second reserve is awaiting issuance. The three-step Nova proof verifies the accounting journal. A fresh walletless Bitcoin Core node independently replayed 216 blocks and discovered both reserve enrollments, including the one omitted by the legacy control.

The evidence contains the proof, verifier key identifier, journal, catalog, registry root, block archive, mutation results and resource measurements. Verify using the independently pinned registry root and a trusted Nova verifier for the stated key. This result covers the registry namespace and its declared protected issuance.

To rerun the recorded independent audit, extract the scripts in the campaign workspace and use the two checked-out repositories and the Bitcoin Core 31.0 Windows binary. Run python -B work/verify-cashu-registry-nova.py EVIDENCE_DIR SCRATCH_DIR NOVA_VERIFIER, where EVIDENCE_DIR is the extracted evidence directory. The command writes a new receipt to that directory, so move the bundled receipt to a separate location before rerunning. The helper expects txospenderindex support. To build a fresh fixture, run python -B work/check-cashu-reserve-registry.py NEW_OUTPUT_DIR SCRATCH_DIR.
