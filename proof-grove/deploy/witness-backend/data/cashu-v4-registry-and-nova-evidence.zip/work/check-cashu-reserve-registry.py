"""Audit the archived V3 issuance and a second enrolled reserve on Bitcoin Core regtest."""

from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch


workspace = Path(__file__).resolve().parents[1]
work = workspace / "work"
outputs = workspace / "outputs"
sys.path[:0] = [
    str(work / "Spiral/proof-grove"),
    str(work / "zk-rusto-no-bitcoino/integrations/bitvm3-nova/m14/assertion-smoke"),
]

from proofdesk import protected_accounting as accounting, protected_registry as registry, protected_reserve as reserve
from proofdesk import protected_withdrawal as withdrawal
from proofdesk.domain import digest, Refused
from proofdesk.protected_chain_archive import capture, replay
from regtest import Core, initialize_wallet


def pinned(path, expected):
    raw = path.read_bytes()
    if sha256(raw).hexdigest() != expected:
        raise ValueError(f"incorrect fixture digest for {path.name}")
    return raw


def fixture_core(binary, directory, log):
    spawn = subprocess.Popen
    with patch("regtest.subprocess.Popen", side_effect=lambda args, **kw: spawn([*args, "-txospenderindex=1"], **kw)):
        return Core(binary, directory, log)


def refuse(code, call):
    try:
        call()
    except Refused as error:
        if error.code == code:
            return code
        raise
    raise AssertionError(f"expected {code}")


report = Path(sys.argv[1]).resolve()
scratch = Path(sys.argv[2]).resolve(strict=True)
if not scratch.is_dir():
    raise ValueError("a dedicated test scratch directory is required")
source = work / "Spiral/proof-grove/.runtime/regtest-stack-_ew6nfk7/protected-handoff/withdrawal-authorization"
base_catalog = json.loads(pinned(source / "confirmed-catalog.json",
                                 "b69b47a1367718fddf5bd12001619245e044e672c9fc3662044d9a67e2a0a1d8"))
journal = json.loads(pinned(source / "confirmed-journal.json",
                             "670e53af8233eca0ac7d9f67bd4847322d8fbb3460755261f7283638d6d12ee8"))
records = json.loads(pinned(source / "confirmed-records.json",
                             "e35b0e058500b005194de777546db6b36dbd0cc6d1aa18a4bff96833c6428a44"))
checkpoint = outputs / "cashu-v4-refusal-recipient/checkpoint-stage/prewithdrawal-blocks.hex"
checkpoint_pin = "49408ac588247383d52b6b2b3adc549cd621fbde507bc42b60878f2a4c3977ed"
issued, = base_catalog["bundles"]
assert records[-1]["real_cdk_issuance"] and records[-1]["independent_verifier"]["dleq_verified"]
bitcoin = work / "cashu-deps/bitcoin-31.0-win64/bitcoind.exe"
archive = report / "registry-blocks.hex"

with TemporaryDirectory(prefix="cashu-registry-", dir=scratch) as temporary, (report / "core.log").open("wb") as log:
    core = fixture_core(bitcoin, Path(temporary), log)
    try:
        core.wait()
        rpc = lambda method, params: core.rpc(method, *params)
        reader = SimpleNamespace(rpc=rpc)
        replay(rpc, checkpoint, checkpoint_pin, base_catalog["tip_height"], base_catalog["tip_hash"])
        miner = initialize_wallet(core)
        registry_addr = core.rpc("getnewaddress", "reserve registry", "bech32", wallet=True)
        registry_script = core.rpc("validateaddress", registry_addr)["scriptPubKey"]
        next_plan = {key: issued["plan"][key] for key in reserve.PLAN_FIELDS}
        next_plan["claim_commitment"] = "42" * 32
        plan = reserve.plan(reader, **next_plan, schema=reserve.V3_PLAN_SCHEMA)
        root_txid = core.rpc("sendtoaddress", registry_addr, 0.001, wallet=True)
        root_block, = core.rpc("generatetoaddress", 1, miner)
        root_tx = core.rpc("getrawtransaction", root_txid, True, root_block)
        root_index, = [item["n"] for item in root_tx["vout"] if item["scriptPubKey"]["hex"] == registry_script]
        registry_coin = [{"txid": root_txid, "vout": root_index}]
        core.rpc("lockunspent", False, registry_coin, wallet=True)
        pending_txid = core.rpc("sendtoaddress", plan["funding_address"], 0.00025, wallet=True)
        pending_block, *_ = core.rpc("generatetoaddress", plan["min_confirmations"], miner)
        core.rpc("lockunspent", True, registry_coin, wallet=True)
        pending_tx = core.rpc("getrawtransaction", pending_txid, True, pending_block)
        pending_index, = [item["n"] for item in pending_tx["vout"]
                          if item["scriptPubKey"]["hex"] == plan["funding_script"]]
        pending = reserve.attach(reader, plan, plan["plan_id"], {
            "txid": pending_txid, "vout": pending_index, "block": pending_block,
        })
        root = {"schema": registry.SCHEMA, "genesis": reserve.GENESIS, "mint": base_catalog["mint"],
                "txid": root_txid, "vout": root_index, "block": root_block,
                "height": core.rpc("getblockheader", root_block)["height"], "script": registry_script, "sats": 100_000}

        def note(point):
            return registry.registration_payload(point[0], [point[1]])

        def append(prev, target):
            inputs = [] if prev is None else [{"txid": prev[0], "vout": prev[1]}]
            txouts = [{"data": note(target)}]
            if prev is not None:
                txouts.insert(0, {registry_addr: 0.001})
            unsigned = core.rpc("createrawtransaction", inputs, txouts)
            funded = core.rpc("fundrawtransaction", unsigned, {"add_inputs": True}, wallet=True)["hex"]
            signed = core.rpc("signrawtransactionwithwallet", funded, wallet=True)
            assert signed["complete"]
            txid = core.rpc("sendrawtransaction", signed["hex"])
            block, = core.rpc("generatetoaddress", 1, miner)
            change = core.rpc("getrawtransaction", txid, True, block)
            index = next((item["n"] for item in change["vout"] if item["scriptPubKey"]["hex"] == registry_script), None)
            return (txid, index), block

        def current(base):
            tip = core.rpc("getblockchaininfo")
            return base | {"tip_hash": tip["bestblockhash"], "tip_height": tip["blocks"]}

        first, _ = append((root_txid, root_index), accounting.outpoint(issued["funding"]))
        assert first[1] is not None
        core.rpc("lockunspent", False, [{"txid": first[0], "vout": first[1]}], wallet=True)
        _, outsider = append(None, (pending_txid, pending_index))
        core.rpc("lockunspent", True, [{"txid": first[0], "vout": first[1]}], wallet=True)
        registered_catalog = base_catalog | {"schema": accounting.REGISTRY_CATALOG_SCHEMA, "registry_sha256": digest(root)}
        outsider_ignored = accounting.audit(reader, current(registered_catalog), journal, records, registry=root)
        assert outsider_ignored["registry"]["head_txid"] == first[0]
        funding = pending["funding"] | {"sats": pending["plan"]["reserve_sats"], "script": pending["plan"]["funding_script"]}
        event, admission = accounting.journal_entry(pending, {"kind": "register", "intent": "73" * 32},
                                                    {"kind": "observed-regtest-reserve", "funding": funding})
        full_catalog = registered_catalog | {"bundles": [issued, pending]}
        full_journal = journal | {"events": [*journal["events"], event]}
        full_records = [*records, admission]
        off_registry = refuse("protected_accounting_unregistered_reserve", lambda: accounting.audit(
            reader, current(full_catalog), full_journal, full_records, registry=root))
        second, enrollment = append(first, (pending_txid, pending_index))
        omitted = refuse("protected_accounting_registered_reserve_omitted", lambda: accounting.audit(
            reader, current(registered_catalog), journal, records, registry=root))
        legacy = accounting.audit(reader, current(base_catalog), journal, records)
        full_tip_catalog = current(full_catalog)
        totals = accounting.audit(reader, full_tip_catalog, full_journal, full_records, registry=root)
        assert totals["registry"]["head_txid"] == second[0] and totals["pending_issuance_sats"] == 25000
        direct = (source / "signed-payout.hex").read_text().strip()
        candidate_args = (reader, full_tip_catalog, full_journal, full_records, issued["bundle_id"], direct)
        candidate = withdrawal.prepare(*candidate_args, registry=root)
        assert withdrawal.verify_candidate(*candidate_args, candidate, registry=root) == candidate
        candidate_missing_registry = refuse("protected_accounting_registry_profile_mismatch",
                                            lambda: withdrawal.verify_candidate(*candidate_args, candidate))
        chain = capture(rpc, archive, full_tip_catalog["tip_height"], full_tip_catalog["tip_hash"])
        core.rpc("invalidateblock", enrollment)
        stale = refuse("protected_accounting_stale_catalog", lambda: accounting.audit(
            reader, full_tip_catalog, full_journal, full_records, registry=root))
        rolled = accounting.audit(reader, current(registered_catalog), journal, records, registry=root)
        assert rolled["registry"]["head_txid"] == first[0]
        core.rpc("reconsiderblock", enrollment)
        assert accounting.audit(reader, full_tip_catalog, full_journal, full_records, registry=root) == totals
        append(second, (pending_txid, pending_index))
        repeat = refuse("protected_registry_repeated_or_oversized_enrollment", lambda: accounting.audit(
            reader, current(full_catalog), full_journal, full_records, registry=root))
    finally:
        core.stop()

with TemporaryDirectory(prefix="cashu-registry-recipient-", dir=scratch) as temporary, (report / "recipient.log").open("wb") as log:
    core = fixture_core(bitcoin, Path(temporary), log)
    try:
        core.wait()
        rpc = lambda method, params: core.rpc(method, *params)
        reader = SimpleNamespace(rpc=rpc)
        independent = replay(rpc, archive, chain["archive_sha256"], chain["height"], chain["anchor"])
        assert not core.rpc("listwallets")
        assert accounting.audit(reader, full_tip_catalog, full_journal, full_records, registry=root) == totals
    finally:
        core.stop()

result = {"schema": registry.SCHEMA, "anchor": root, "reconciled": totals, "legacy_omission": legacy,
          "controls": {"outsider_marker_block": outsider, "outsider_marker_ignored": outsider_ignored["registry"],
                       "unregistered_reserve": off_registry, "omitted_from_catalog_and_journal": omitted,
                       "candidate_without_registry": candidate_missing_registry, "stale_tip": stale,
                       "after_reorg": rolled["registry"], "duplicate_enrollment": repeat},
          "previous_verified_issuance": {"journal_sha256": sha256((source / "confirmed-journal.json").read_bytes()).hexdigest(),
                                         "genuine_cdk_admission": True},
          "chain": chain, "walletless_replay": independent}
for name, document in (("registry-root.json", root), ("catalog.json", full_tip_catalog), ("journal.json", full_journal),
                       ("records.json", full_records), ("candidate.json", candidate), ("registry-audit.json", result)):
    with (report / name).open("x", encoding="utf-8") as stream:
        json.dump(document, stream, indent=2)
        stream.write("\n")
print(json.dumps({"reserves": totals["declared_reserve_sats"], "claims": totals["outstanding_claims_sats"],
                  "pending": totals["pending_issuance_sats"], "blocks": independent["blocks_submitted"],
                  "omission": omitted}))
