"""Independently replay and verify the registry accounting proof on a walletless node."""

from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch


workspace = Path(__file__).resolve().parents[1]
work = workspace / "work"
grove = work / "Spiral/proof-grove"
sys.path[:0] = [str(grove), str(work / "zk-rusto-no-bitcoino/integrations/bitvm3-nova/m14/assertion-smoke")]

from proofdesk.protected_chain_archive import replay
from regtest import Core


report = Path(sys.argv[1]).resolve()
scratch = Path(sys.argv[2]).resolve(strict=True)
verifier = Path(sys.argv[3]).resolve(strict=True)
native = json.loads((report / "registry-audit.json").read_bytes())
observed = native["walletless_replay"]
chain = report / "registry-blocks.hex"
bitcoin = work / "cashu-deps/bitcoin-31.0-win64/bitcoind.exe"

with TemporaryDirectory(prefix="cashu-registry-nova-", dir=scratch) as temporary, (report / "nova-recipient-core.log").open("wb") as log:
    directory = Path(temporary)
    spawn = subprocess.Popen
    with patch("regtest.subprocess.Popen", side_effect=lambda args, **kw: spawn([*args, "-txospenderindex=1"], **kw)):
        core = Core(bitcoin, directory, log)
    try:
        core.wait()
        restored = replay(lambda method, params: core.rpc(method, *params), chain, observed["archive_sha256"],
                          observed["height"], observed["anchor"])
        if restored != observed or core.rpc("listwallets"):
            raise RuntimeError("registry proof requires the exact walletless chain replay")
        config = directory / "core.json"
        config.write_text(json.dumps({"core": {"url": f"http://127.0.0.1:{core.port}",
                                              "cookie_file": str(directory / "regtest/.cookie")}}), encoding="utf-8")
        command = [
            sys.executable, "-B", "-m", "proofdesk.protected_accounting", "--config", str(config),
            "--proof-dir", str(report / "nova-proof"), "--nova-verifier", str(verifier),
            "--nova-key-sha256", "e472ec73e400c2d88b4e398741596765024fab4ee22ed7b6c600e8753df1034d",
            "--admission", str(report / "records.json"),
        ]
        for kind, name in (("registry", "registry-root"), ("catalog", "catalog"), ("journal", "journal")):
            artifact = report / f"{name}.json"
            command.extend((f"--{kind}", str(artifact), f"--{kind}-sha256", sha256(artifact.read_bytes()).hexdigest()))
        completed = subprocess.run(command, cwd=grove, capture_output=True, timeout=110)
        (report / "nova-recipient.stderr").write_bytes(completed.stderr)
        completed.check_returncode()
        audit = json.loads(completed.stdout)
        if (any(audit.get(key) != value for key, value in native["reconciled"].items())
                or audit["nova"]["verified"] is not True or core.rpc("listwallets")):
            raise RuntimeError("registry proof, Core balances and native discovery did not agree")
    finally:
        core.stop()

with (report / "nova-registry-verification.json").open("xb") as stream:
    stream.write(completed.stdout)
print(json.dumps({"proof_sha256": audit["nova"]["proof_sha256"], "verified": audit["nova"]["verified"],
                  "reserves": audit["declared_reserve_sats"], "claims": audit["outstanding_claims_sats"],
                  "pending": audit["pending_issuance_sats"], "registered": audit["registry"]["registered_reserves"]}))
